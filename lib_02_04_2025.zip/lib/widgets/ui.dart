
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';

import '../Product_widget/Product_widget.dart';
import '../cores/math_utils.dart';
import '../main.dart';
import '../models/HomeData.dart';
import '../utils/ShColors.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class Ui {
  static GetBar ErrorSnackBar({String? title = 'Error', String? message}) {
    Get.log("[$title] $message", isError: true);
    return GetBar(
      titleText: Text(title!.tr,
          style: Get.textTheme.titleLarge!.merge(
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      messageText: Text(message!,
          style: Get.textTheme.bodySmall!.merge(
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(20),
      backgroundColor: Colors.redAccent,
      icon: const Icon(Icons.remove_circle_outline, size: 32, color: Colors.white),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      borderRadius: 8,
      dismissDirection: DismissDirection.horizontal,
      duration: const Duration(milliseconds: 3000),
    );
  }
  static GetBar successSnackBar({String? title = 'Success', String? message}) {
    Get.log("[$title] $message", isError: false);
    return GetBar(
      titleText: Text(title!.tr,
          style: Get.textTheme.titleLarge!.merge(
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      messageText: Text(message!,
          style: Get.textTheme.bodySmall!.merge(
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(20),
      backgroundColor: ColorConstant.logoFirstColorConstant,
      icon: const Icon(Icons.remove_circle_outline, size: 32, color: Colors.white),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      borderRadius: 8,
      dismissDirection: DismissDirection.horizontal,
      duration: const Duration(milliseconds: 3000),
    );
  }

  static String progImages(String image, fromKey)  {
    List<String> newImageList = [];

    String newImage = "";
    if(fromKey=="blur"){
      newImageList =image.split("/");
      newImageList.insert(newImageList.length - 1, "blures");
    }
    else if(fromKey== "thumbnails"){
      newImageList =image.split("/");
      newImageList.insert(newImageList.length - 1, "thumbnails");
    }

    for (int i = 0; i < newImageList.length; i++) {
      if (newImage != "") {
        newImage += "/${newImageList[i]}";
      } else {
        newImage += newImageList[i];
      }


    }
    return newImage;

  }

  static BoxDecoration getBoxDecoration({Color? color, double? radius, Border? border, Gradient? gradient}) {
    return BoxDecoration(
      color: color ?? Get.theme.primaryColor,
      borderRadius: BorderRadius.all(Radius.circular(radius ?? 10)),
      boxShadow: [
        BoxShadow(color: Get.theme.focusColor.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 5)),
      ],
      border: border ?? Border.all(color: Get.theme.focusColor.withOpacity(0.05)),
      gradient: gradient,
    );
  }


  static flutterToast(msg, toast, backgroundColor, textColor) {
    Fluttertoast.showToast(
        msg: msg,
        toastLength: toast,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: backgroundColor,
        textColor: textColor,
        fontSize: 16.0);
  }
  static onTapWhatsapp(Product product, String? phoneNumber) {
    var unescape = HtmlUnescape();
    String description = unescape.convert(product.description ?? '');
    String productUrl = "https://cms.lebanonjewelry.net/product/${product.product_id}";

    makeWhatsappContact(
      phoneNumber ?? '+96171069164',
      text: "I want to ask about this product: ${product.product_name}\n$productUrl\n$description",
    );
  }

  static Future<void> onTapWhatsappSupport(Product product) async {
    var unescape = HtmlUnescape();
    String description = unescape.convert(product.description ?? '');

    // Replace with your support number
    String supportNumber = '+96176600252';

    String productUrl = "https://cms.lebanonjewelry.net/product/${product.product_id}";
    String imageUrl = product.main_image.toString().replaceAll(" ", "%20");

    String message = '''
I want to ask about this product: ${product.product_name}

$description

$productUrl

Image: $imageUrl
''';

    String whatsappUrl =
        "https://wa.me/$supportNumber?text=${Uri.encodeComponent(message)}";

    try {
      await launchUrl(Uri.parse(whatsappUrl), mode: LaunchMode.externalApplication);
    } catch (e) {
      print("Failed to open WhatsApp: $e");
    }
  }



  static launchWhatsApp(String phoneNumber, String storeName) async {
    final link = WhatsAppUnilink(
      phoneNumber:phoneNumber,
      text: "Hey! I'm a user of $storeName",
    );
    await launch('$link');
  }

 static Widget backArrowIcon({Color iconColor= Colors.grey,String fromKey="", void Function()? onTap}){
    return
      InkWell(
        onTap: onTap?? () {
          Get.back();
        },
        child: Padding(
          padding: getPadding(left: 8),
          child: SizedBox(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),

            child:Icon(

              Icons.arrow_back_ios,
              color: iconColor,
              size: getSize(25),

            ),
          ),
        ),
      );
  }


  static String convertTo12HourFormat(String time24) {
    try {
      // Validate input format (HH:mm)
      final timeParts = time24.split(':');
      if (timeParts.length != 2) {
        throw FormatException('Invalid time format');
      }

      int hour = int.parse(timeParts[0]);
      int minute = int.parse(timeParts[1]);

      if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
        throw FormatException('Invalid time range');
      }

      // Convert to 12-hour format
      final period = hour >= 12 ? 'PM' : 'AM';
      if (hour > 12) hour -= 12;
      if (hour == 0) hour = 12;

      return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')} $period';
    } catch (e) {
      print('Error in convertTo12HourFormat: $e');
      return 'Invalid Time';
    }
  }
  static Widget circularIndicator({
    double height = 20,
    double width = 20,
    double strokeWidth = 3,
    double size = 20,
    Color color = ColorConstant.white,
  }) {
    return Center(
        child: SizedBox(
            height: height,
            width: width,
            child:  LoadingAnimationWidget.inkDrop(color: color, size: size,)));
  }

  static Widget circularIndicatorDefault({
    double height = 20,
    double width = 20,
    double strokeWidth = 3,
    Color color = ColorConstant.white,
  }) {
    return Center(
        child: SizedBox(
            height: height,
            width: width,
            child:  CircularProgressIndicator(color: color,strokeWidth: strokeWidth,)));
  }


// static Widget circularIndicatorRive({
  //   String riveFileName = 'assets/images/loader.riv',
  //   String animationName = 'Animation',
  //   BoxFit fit = BoxFit.contain,
  //   Alignment alignment = Alignment.center,
  //   double height = 100,
  //   double width = 100,
  // }) {
  //   return Center(
  //     child: SizedBox(
  //       height: height,
  //       width: width,
  //       child: RiveAnimation.asset(
  //         riveFileName,
  //         animations: [animationName],
  //         alignment: alignment,
  //         fit: fit,
  //       ),
  //     ),
  //   );
  // }

}
