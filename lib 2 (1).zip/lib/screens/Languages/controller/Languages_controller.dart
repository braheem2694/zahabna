import 'package:get/get.dart';
class LanguagesController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }



}


