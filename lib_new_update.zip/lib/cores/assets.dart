import 'package:intl/intl.dart';
import 'package:iq_mall/main.dart';

String? con = "https://cms.lebanonjewelry.net/v1_0_0-";
String? conVersion = "https://cms.lebanonjewelry.net/";
var formatter =  NumberFormat('#,###,###.##');

final datefromater = new DateFormat('dd-MM-yyyy hh:mm');
