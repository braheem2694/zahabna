import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:animated_react_button/animated_react_button.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:file/src/interface/file.dart';
import 'package:flutter_avif/flutter_avif.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:html/parser.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:iq_mall/widgets/LikeButton.dart';
import 'package:iq_mall/utils/ShImages.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/widgets/ShWidget.dart';
import 'package:get/get.dart';
import 'dart:async';
import 'package:iq_mall/main.dart';
import 'package:iq_mall/widgets/ui.dart';
import 'package:progressive_image/progressive_image.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:visibility_detector/visibility_detector.dart';
import '../models/HomeData.dart';
import '../screens/Cart_List_screen/controller/Cart_List_controller.dart';
import '../screens/Filter_Products_screen/controller/Filter_Products_controller.dart';
import '../screens/ProductDetails_screen/ProductDetails_screen.dart';
import '../screens/ProductDetails_screen/controller/ProductDetails_screen_controller.dart';
import '../screens/Stores_screen/widgets/item_widget.dart';
import '../screens/Wishlist_screen/controller/Wishlist_controller.dart';
import '../widgets/add_to_cart.dart';
import '../widgets/custom_image_view.dart';
import '../widgets/image_new_widget.dart';
import '../widgets/image_widget.dart';
import 'package:iq_mall/models/functions.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:path_provider/path_provider.dart' as path_provider;

RxBool recheck = false.obs;

class ProductWidget extends StatefulWidget {
  static String? tag = '/ShProductDetail';
  final Product product;
  final String? fromKey;

  ProductWidget({required this.product, this.fromKey});

  @override
  ProductWidgetState createState() => ProductWidgetState();
}

class ProductWidgetState extends State<ProductWidget> with TickerProviderStateMixin {
  final random = Random();
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  late ProductWidgetController productWidgetController;
  RxBool refreshing = false.obs;
  RxBool isReallyLiked = false.obs;
  RxBool isLiked = false.obs;
  RxInt imageCount = 0.obs;
  int count = 0;
  RxBool _loadImage = false.obs;

  List<CachedNetworkImageProvider> images = <CachedNetworkImageProvider>[];

  var key = UniqueKey();

  @override
  void initState() {
    // TODO: implement initState
    // if(widget.fromKey=="filter"){
    //   _getBytesFromCachedImage(CachedNetworkImageProvider(widget.product.main_image!));
    //
    // }

    productWidgetController = Get.put(ProductWidgetController(), tag: widget.product.product_id.toString());
    super.initState();
  }

  // updateFetchedImages(){
  //   final CountService countService = Get.put(CountService());
  //   int newCount = countService.getCount() + 1;
  //   print("currentCount: ${newCount}");
  //   countService.updateCount(newCount);
  // }

  // Future<Uint8List> _getBytesFromCachedImage(CachedNetworkImageProvider imageProvider) async {
  //   final imageStream = imageProvider.resolve(ImageConfiguration());
  //   final Completer<Uint8List> completer = Completer();
  //   ImageStreamListener? listener;
  //
  //   try {
  //     listener = ImageStreamListener((ImageInfo image, bool synchronousCall) {
  //       if (!completer.isCompleted) {
  //         updateFetchedImages();
  //
  //         image.image.toByteData().then((ByteData? byteData) {
  //           if (byteData != null) {
  //             completer.complete(byteData.buffer.asUint8List());
  //
  //             globalController.updateImageFetchingNumber();
  //           } else {
  //             completer.completeError(Exception("ByteData is null"));
  //           }
  //         });
  //         imageStream.removeListener(listener!); // Remove the listener after completion
  //       }
  //     }, onError: (Object exception, StackTrace? stackTrace) {
  //
  //       completer.completeError(exception, stackTrace);
  //       imageStream.removeListener(listener!);
  //
  //       // Remove the listener in case of an error
  //     });
  //     imageStream.addListener(listener);
  //   } catch (e) {}
  //   return completer.future;
  // }

  void startAnimation() {
    productWidgetController.borderWidth.value = 2.0; // Fully fill the border
  }

  void _showBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isDismissible: true,

      enableDrag: true,

      isScrollControlled: true,
      transitionAnimationController: AnimationController(vsync: this, duration: Duration(milliseconds: 250)),
      // Set this to true to make the sheet full-screen.
      builder: (BuildContext context) {
        // Return the screen you want to show as a bottom sheet
        return ProductDetails_screen();
      },
    ).then((product) {
      refreshing.value = true;
      // globalController.productDetails_screenController.dispose();
      // GetInstance().delete(tag: globalController.productDetails_screenController);
      Get.delete<ProductDetails_screenController>(tag: "${widget.product.product_id}");
      Future.delayed(const Duration(milliseconds: 350)).then((value) {
        globalController.isLiked.value;

        refreshing.value = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    isLiked.value = widget.product.is_liked == 0 ? false : true;
    isReallyLiked.value = widget.product.is_liked == 0 ? false : true;
    imageCount.value =
        (widget.product.more_images?.length ?? 0 + (widget.product.main_image != null ? 1 : 0)) < 4 ? (widget.product.more_images?.length ?? 0 + (widget.product.main_image != null ? 1 : 0)) : 4;
    return InkWell(
      key: scaffoldKey,
      focusColor: Colors.transparent,
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      onTap: () async {
        // Assuming you have a controller named MyController
        if (Get.isRegistered<ProductDetails_screenController>()) {
          await Get.delete<ProductDetails_screenController>();
          print("MyController is initialized");
        }
        // images.clear();
        // images.add(CachedNetworkImageProvider(widget.product.main_image!));
        //
        // for(int i=0; i<widget.product.more_images!.length;i++){
        //
        //   images.add(CachedNetworkImageProvider(widget.product.more_images![i].file_path));
        //
        // }
        globalController.updateProductLike(widget.product.is_liked == 1 ? true : false);

        // if (Platform.isAndroid) {
        // await  Get.delete<ProductDetails_screenController>(tag: "${widget.product.product_id}").then((value) {
        //     globalController.detailsTag.value= "${widget.product.product_id}";
        //     globalController.productDetails_screenController = Get.put(ProductDetails_screenController(), tag: "${widget.product.product_id}");
        //     globalController.productDetails_screenController.arguments = {
        //       "product": widget.product,
        //       "fromCart": false,
        //       "productSlug": null,
        //       "tag": "${widget.product.product_id}",
        //     };
        //
        //   });
        //
        //   _showBottomSheet(context);
        // }
        // else {
        Get.toNamed(AppRoutes.Productdetails_screen, arguments: {
          'product': widget.product,
          'fromCart': false,
          'productSlug': null,
        }, parameters: {
          'tag': "${widget.product.product_id}"
        })?.then((value) {
          refreshing.value = true;
          globalController.updateCurrentRout(AppRoutes.tabsRoute);
          globalController.cartCount = 0;
          // Get.delete<ProductDetails_screenController>();

          Future.delayed(const Duration(milliseconds: 200)).then((value) {
            widget.product.is_liked = globalController.isLiked.value ? 1 : 0;
            globalController.updateFavoriteProduct(widget.product.product_id, globalController.isLiked.value ? 1 : 0);
            refreshing.value = false;
          });
        });

        // Get.to(
        //   () => ProductDetails_screen(
        //     product: widget.product,
        //     fromCart: false,
        //     productSlug: null,
        //   ),
        // )?.then((product) {
        //   refreshing.value = true;
        //
        //   // Get.delete<ProductDetails_screenController>();
        //
        //   Future.delayed(const Duration(milliseconds: 200)).then((value) {
        //     isLiked.value = globalController.isLiked.value;
        //
        //     refreshing.value = false;
        //   });
        // });
        // }
      },
      child: Obx(() {
        return AnimatedContainer(
          duration: Duration(milliseconds: 800),
          onEnd: () {
            productWidgetController.borderWidth.value = 0.0;
          },
          height: getScreenRatio() > 1 ? (Get.height / getScreenRatio()) / 1.3 : (Get.height / getScreenRatio()) / 2,
          width: getHorizontalSize(187),
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(8.0),
              topRight: Radius.circular(8.0),
              bottomRight: Radius.circular(8.0),
              bottomLeft: Radius.circular(8.0),
            ),
            border: Border.all(color: productWidgetController.borderWidth.value != 0.0 ? ColorConstant.logoSecondColor : Colors.transparent, width: productWidgetController.borderWidth.value),
            color: Colors.transparent,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                        color: Colors.grey[200],
                      ),
                      alignment: Alignment.topCenter,
                      height: getScreenRatio() > 1 ? (Get.height / getScreenRatio()) / 1.7 : (Get.height / getScreenRatio()) / 2.5,

                      // set height

                      child: widget.fromKey == "filter"
                          ? ClipRRect(
                              borderRadius: const BorderRadius.only(topLeft: Radius.circular(8), topRight: Radius.circular(8), bottomLeft: Radius.circular(0), bottomRight: Radius.circular(0)),
                              child: (widget.product.main_image?.toLowerCase().endsWith('avif') ?? false)
                                  ? Container(
                                      height: (Get.height / getScreenRatio()) / 1.3,
                                      width: Get.width,
                                      decoration: const BoxDecoration(image: DecorationImage(image: AssetImage(AssetPaths.placeholder))),
                                      child: VisibilityDetector(
                                        key: Key(widget.product.main_image!), // Unique key for VisibilityDetector
                                        onVisibilityChanged: (VisibilityInfo info) {
                                          final visible = info.visibleFraction > 0;

                                          if (visible && !_loadImage.value) {
                                            _loadImage.value = true; // Trigger image loading
                                          }
                                        },
                                        child: Obx(() => _loadImage.value
                                            ? AvifImage.network(
                                                widget.product.main_image!,
                                                fit: BoxFit.cover,
                                                height: (Get.height / getScreenRatio()) / 1.3,
                                                width: Get.width,
                                              )
                                            : Container(
                                                height: (Get.height / getScreenRatio()) / 1.3,
                                                width: Get.width,
                                                color: Colors.transparent,
                                                child: Image.asset(
                                                  AssetPaths.placeholder,
                                                  height: (Get.height / getScreenRatio()) / 1.3,
                                                  width: Get.width,
                                                  fit: BoxFit.cover,
                                                ),
                                              )),
                                      ),
                                    )
                                  : VisibilityDetector(
                                      key: Key(widget.product.main_image!), // Unique key for VisibilityDetector
                                      onVisibilityChanged: (VisibilityInfo info) {
                                        final visible = info.visibleFraction > 0;

                                        if (visible && !_loadImage.value) {
                                          _loadImage.value = true; // Trigger image loading
                                        }
                                      },
                                      child: Obx(() {
                                        return _loadImage.value
                                            ? ProgressiveImage(
                                                placeholder: const AssetImage(AssetPaths.placeholder),
                                                // size: 1.87KB
                                                thumbnail: CachedNetworkImageProvider(
                                                  convertToThumbnailUrl(widget.product.main_image ?? '', isBlurred: true),
                                                  scale: 1,
                                                  cacheManager: CacheManager(
                                                    Config(
                                                      widget.product.product_id.toString(),
                                                      stalePeriod: Duration(seconds: 10), // Adjust based on how long you want items to stay in the cache
                                                      maxNrOfCacheObjects: 50,

                                                      // Maximum number of images to keep in cache
                                                      // You can add other configurations like fileService or repo here
                                                    ),
                                                  ),
                                                ),
                                                blur: 1,
                                                // size: 1.29MB
                                                image: CachedNetworkImageProvider(
                                                  convertToThumbnailUrl(widget.product.main_image ?? "", isBlurred: false) ?? '',
                                                  scale: 1,

                                                  cacheManager: CacheManager(
                                                    Config(
                                                      widget.product.product_id.toString(),
                                                      stalePeriod: Duration(seconds: 10), // Adjust based on how long you want items to stay in the cache
                                                      maxNrOfCacheObjects: 50,

                                                      // Maximum number of images to keep in cache
                                                      // You can add other configurations like fileService or repo here
                                                    ),
                                                  ),
                                                  errorListener: (p0) {},
                                                  // maxWidth: int.parse(getHorizontalSize(180).round().toString()),
                                                  // maxHeight: int.parse(getVerticalSize(220).round().toString()),
                                                ),
                                                height: (Get.height / getScreenRatio()) / 1.3,

                                                width: Get.width,
                                                fit: BoxFit.cover,
                                                fadeDuration: const Duration(milliseconds: 200),
                                                key: Key(widget.product.product_id.toString()),
                                              )
                                            : Container(
                                                height: (Get.height / getScreenRatio()) / 1.3,
                                                width: Get.width,
                                                color: Colors.transparent,
                                                child: Image.asset(
                                                  AssetPaths.placeholder,
                                                  height: (Get.height / getScreenRatio()) / 1.3,
                                                  width: Get.width,
                                                  fit: BoxFit.cover,
                                                ),
                                              );
                                      }),
                                    ),
                            )
                          : ClipRRect(
                              borderRadius: const BorderRadius.only(topLeft: Radius.circular(8), topRight: Radius.circular(8), bottomLeft: Radius.circular(0), bottomRight: Radius.circular(0)),
                              child: (widget.product.main_image?.toLowerCase().endsWith('avif') ?? false)
                                  ? Container(
                                      height: (Get.height / getScreenRatio()) / 1.3,
                                      width: Get.width,
                                      decoration: const BoxDecoration(image: DecorationImage(image: AssetImage(AssetPaths.placeholder))),
                                      child: AvifImage.network(
                                        widget.product.main_image!,
                                        fit: BoxFit.cover,
                                        height: (Get.height / getScreenRatio()) / 1.3,
                                        width: Get.width,
                                      ),
                                    )
                                  : ProgressiveImage(
                                      placeholder: const AssetImage(AssetPaths.placeholder),
                                      // size: 1.87KB
                                      thumbnail: CachedNetworkImageProvider(
                                        convertToThumbnailUrl(widget.product.main_image ?? '', isBlurred: true),
                                        scale: 1,
                                        cacheManager: CacheManager(
                                          Config(
                                            widget.product.product_id.toString(),
                                            stalePeriod: Duration(seconds: 10), // Adjust based on how long you want items to stay in the cache
                                            maxNrOfCacheObjects: 50,

                                            // Maximum number of images to keep in cache
                                            // You can add other configurations like fileService or repo here
                                          ),
                                        ),
                                      ),
                                      blur: 1,
                                      // size: 1.29MB
                                      image: CachedNetworkImageProvider(
                                        convertToThumbnailUrl(widget.product.main_image ?? "", isBlurred: false) ?? '',
                                        scale: 1,

                                        cacheManager: CacheManager(
                                          Config(
                                            widget.product.product_id.toString(),
                                            stalePeriod: Duration(seconds: 10), // Adjust based on how long you want items to stay in the cache
                                            maxNrOfCacheObjects: 50,

                                            // Maximum number of images to keep in cache
                                            // You can add other configurations like fileService or repo here
                                          ),
                                        ),
                                        errorListener: (p0) {},
                                        // maxWidth: int.parse(getHorizontalSize(180).round().toString()),
                                        // maxHeight: int.parse(getVerticalSize(220).round().toString()),
                                      ),
                                      height: (Get.height / getScreenRatio()) / 1.3,

                                      width: Get.width,
                                      fit: BoxFit.cover,
                                      fadeDuration: const Duration(milliseconds: 200),
                                      key: Key(widget.product.product_id.toString()),
                                    ),
                            )

                      // : SizedBox(
                      //     child: Swiper(
                      //       key: UniqueKey(),
                      //       pagination: imageCount.value > 1
                      //           ? imageCount.value > 4
                      //               ? SwiperPagination(
                      //                   alignment: Alignment.bottomCenter,
                      //                   margin: getMargin(bottom: 3),
                      //                   builder: DotSwiperPaginationBuilder(
                      //                     activeColor: MainColor,
                      //
                      //                     space: 4,
                      //
                      //                     activeSize: getSize(7),
                      //                     size: getSize(7),
                      //                     // Color for the active dot
                      //                     color: Colors.grey, // Color for the inactive dots
                      //                   ),
                      //                 )
                      //               : SwiperPagination(
                      //                   alignment: Alignment.bottomCenter,
                      //                   margin: getMargin(bottom: 3),
                      //                   builder: DotSwiperPaginationBuilder(
                      //                     activeColor: MainColor,
                      //                     space: 4,
                      //
                      //                     activeSize: getSize(7),
                      //                     size: getSize(7),
                      //                     // Color for the active dot
                      //                     color: Colors.grey, // Color for the inactive dots
                      //                   ),
                      //                 )
                      //           : null,
                      //       loop: true,
                      //       itemCount: imageCount.value.abs(),
                      //       itemBuilder: (BuildContext context, int index) {
                      //         String? imageUrl;
                      //         if (index == 0) {
                      //           imageUrl = widget.product.main_image;
                      //         } else {
                      //           imageUrl = widget.product.more_images?[index].file_path;
                      //         }
                      //
                      //         return
                      //             //   CustomImageWidget(
                      //             //   blurImageUrl: convertToThumbnailUrl(imageUrl.toString(), isBlurred: true),
                      //             //   thumbImageUrl: convertToThumbnailUrl(imageUrl.toString(), isBlurred: false),
                      //             //   cacheThumb: true,
                      //             //   height: getVerticalSize(180),
                      //             //   width: getSize(240),
                      //             //   fit: BoxFit.cover,
                      //             // );
                      //
                      //             ClipRRect(
                      //           borderRadius: BorderRadius.only(topLeft: Radius.circular(5), topRight: Radius.circular(5), bottomLeft: Radius.circular(0), bottomRight: Radius.circular(0)),
                      //           child:
                      //
                      //               // CachedNetworkImage(
                      //               //   height: getVerticalSize(180),
                      //               //   width: getSize(240),
                      //               //   fit: BoxFit.cover,
                      //               //   imageUrl: convertToThumbnailUrl(imageUrl ?? '', isBlurred: false),
                      //               //   placeholder: (context, url) {
                      //               //     return CachedNetworkImage(
                      //               //         imageUrl: convertToThumbnailUrl(imageUrl ?? '', isBlurred: true),
                      //               //         placeholderFadeInDuration: const Duration(milliseconds: 100),
                      //               //         placeholder: (context, url) {
                      //               //           return Image.asset(
                      //               //             AssetPaths.placeholder,
                      //               //             width: Get.size.width,
                      //               //             height: Get.size.height,
                      //               //             fit: BoxFit.cover,
                      //               //           );
                      //               //         });
                      //               //   },
                      //               //   errorWidget: (context, s, a) {
                      //               //     return Center(
                      //               //       child: Image.asset(
                      //               //         AssetPaths.placeholder,
                      //               //         width: Get.size.width,
                      //               //         height: Get.size.height,
                      //               //         fit: BoxFit.cover,
                      //               //       ),
                      //               //     );
                      //               //   },
                      //               // )
                      //
                      //               ProgressiveImage(
                      //             key: Key(widget.product.product_id.toString()),
                      //
                      //             placeholder: const AssetImage(AssetPaths.placeholder),
                      //             // size: 1.87KB
                      //             thumbnail: CachedNetworkImageProvider(convertToThumbnailUrl(imageUrl ?? '', isBlurred: true),
                      //                 cacheManager: CacheManager(
                      //                   Config(
                      //                     widget.product.product_id.toString(),
                      //                     stalePeriod: const Duration(days: 5),
                      //                     maxNrOfCacheObjects: 100,
                      //                   ),
                      //                 )),
                      //             blur: 0,
                      //             // size: 1.29MB
                      //             image: CachedNetworkImageProvider(
                      //               convertToThumbnailUrl(imageUrl ?? '', isBlurred: false),
                      //               cacheManager: CacheManager(
                      //                 Config(
                      //                   widget.product.product_id.toString(),
                      //                   stalePeriod: const Duration(days: 5),
                      //                   maxNrOfCacheObjects: 100,
                      //                 ),
                      //               ),
                      //             ),
                      //             height: getVerticalSize(220),
                      //             width: getHorizontalSize(200),
                      //
                      //             fit: BoxFit.cover,
                      //             fadeDuration: Duration(milliseconds: 200),
                      //           ),
                      //         );
                      //         //   mediaWidget(
                      //         //     convertToThumbnailUrl(imageUrl ?? '', isBlurred: false),
                      //         //   AssetPaths.placeholder,
                      //         //   height: getVerticalSize(180),
                      //         //   isProduct: true,
                      //         //   width: getSize(240),
                      //         //   fit: BoxFit.cover,
                      //         // );
                      //
                      //         //   CachedNetworkImage(
                      //         //   height: 160,
                      //         //   width: MediaQuery.of(context).size.width,
                      //         //   fit: BoxFit.cover,
                      //         //   imageUrl: convertToThumbnailUrl(imageUrl, isBlurred: false),
                      //         //   placeholder: (context, url) {
                      //         //     return CachedNetworkImage(
                      //         //       imageUrl: convertToThumbnailUrl(imageUrl, isBlurred: true),
                      //         //       placeholderFadeInDuration: const Duration(milliseconds: 100),
                      //         //     );
                      //         //   },
                      //         //   errorWidget: (context, s, a) {
                      //         //     return CachedNetworkImage(
                      //         //       height: 160,
                      //         //       width: MediaQuery.of(context).size.width,
                      //         //       fit: BoxFit.cover,
                      //         //       imageUrl: imageUrl,
                      //         //       errorWidget: (context, s, a) {
                      //         //         return Center(
                      //         //           child: Image.asset(
                      //         //             AssetPaths.placeholder,
                      //         //             width: Get.size.width,
                      //         //             height: Get.size.height,
                      //         //             fit: BoxFit.cover,
                      //         //           ),
                      //         //         );
                      //         //       },
                      //         //     );
                      //         //   },
                      //         // );
                      //       },
                      //     ),
                      //   ),
                      ),
                  widget.product.product_qty_left.toInt() < 1
                      ? Container()
                      :
                  Positioned(
                          top: -10, // Adjust the value as needed for spacing from the top
                          right: 0,
                          child:
                              widget.fromKey=="my_store"?
                              GestureDetector(
                                onTap: () {
                                  globalController.updateIsNav(false);
                                  prefs?.setString("is_nav", "0");
                                  Get.to(()=>AddNewItemScreen(fromKey: "edit",product: widget.product,));

                                },
                                behavior: HitTestBehavior.translucent,
                                child: Container(
                                    padding: getPadding( top: 14, right: 10,left: 10,bottom: 10),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          Colors.blue.withOpacity(0.3), // Lighter black at the top left
                                          Colors.blue.withOpacity(0.4), // Darker black at the bottom right
                                          Colors.blue.withOpacity(0.5), // Darker black at the bottom right
                                          Colors.blue.withOpacity(0.6), // Darker black at the bottom right
                                        ],
                                      ),
                                      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10)),
                                      boxShadow: [
                                        BoxShadow(color: Colors.black12.withOpacity(0.1), blurRadius: 3, offset: const Offset(0, 2)),
                                      ],
                                    ),
                                    child:
                                    Icon(FontAwesomeIcons.edit,color: Colors.white,size: getFontSize(20),)
                                  // CustomImageView(
                                  //   imagePath: AssetPaths.whatsapp,
                                  //   height: getSize(30.00),
                                  //   width: getSize(30.00),
                                  //   fit: BoxFit.cover,
                                  //   radius: BorderRadius.circular(5),
                                  // ),
                                ),
                              ):
                          GestureDetector(
                            onTap: () {
                              onTapWhatsapp( widget.product);
                            },
                            behavior: HitTestBehavior.translucent,
                            child: Container(
                              padding: getPadding( top: 14, right: 10,left: 10,bottom: 10),
                                decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors:

                                      [
                                        Colors.green.withOpacity(0.3), // Lighter black at the top left
                                        Colors.green.withOpacity(0.4), // Darker black at the bottom right
                                        Colors.green.withOpacity(0.5), // Darker black at the bottom right
                                        Colors.green.withOpacity(0.6), // Darker black at the bottom right
                                      ],
                                    ),
                                    borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10)),
                                    boxShadow: [
                                      BoxShadow(color: Colors.black12.withOpacity(0.1), blurRadius: 3, offset: const Offset(0, 2)),
                                    ],
                                   ),
                              child:
                              Icon(FontAwesomeIcons.whatsapp,color: Colors.white,size: getFontSize(20),)
                              // CustomImageView(
                              //   imagePath: AssetPaths.whatsapp,
                              //   height: getSize(30.00),
                              //   width: getSize(30.00),
                              //   fit: BoxFit.cover,
                              //   radius: BorderRadius.circular(5),
                              // ),
                            ),
                          ),
                          // AddToCartButton(product: widget.product)

                  ),
                ],
              ),
              Padding(
                padding: getPadding(left: 0.0, right: 0, top: 0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      width: getHorizontalSize(120),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 4.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            widget.product.price_after_discount != null
                                ? Text(
                                    sign.toString() + widget.product.price_after_discount.toString(),
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: price_color,
                                      fontSize: getFontSize(15),
                                      decoration: TextDecoration.none,
                                    ),
                                  )
                                : Container(),
                            Padding(
                              padding: getPadding(left: 4.0),
                              child: Text(
                                sign.toString() + widget.product.product_price.toString(),
                                style: TextStyle(
                                  fontWeight: widget.product.price_after_discount == null || widget.product.price_after_discount.toString() == 'null' ? FontWeight.bold : FontWeight.normal,
                                  color: widget.product.price_after_discount != null ? discount_price_color : price_color,
                                  fontSize: widget.product.price_after_discount != null || widget.product.price_after_discount.toString() == 'null' ? getFontSize(14) : getFontSize(12),
                                  decoration: widget.product.price_after_discount != null ? TextDecoration.lineThrough : TextDecoration.none,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Expanded(child: SizedBox()),
                    prefs!.getString("token").toString() == 'null'
                        ? Container()
                        : Padding(
                            padding: getPadding(right: 3, left: 0,top: 3),
                            child: Obx(() => GestureDetector(
                              onTap: () {
                                isLiked.value = !isLiked.value;

                                function.setFavorite(widget.product, false, isLiked.value).then((value) {
                                  widget.product.is_liked = isLiked.value ? 1 : 0;
                                  WishlistController _controller = Get.find();
                                  _controller.GetFavorite();
                                });
                              },
                              child: AnimatedSwitcher(
                                duration: const Duration(milliseconds: 300),
                                transitionBuilder: (Widget child, Animation<double> animation) {
                                  return ScaleTransition(scale: animation, child: child);
                                },
                                child: Icon(
                                  isLiked.value ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                  key: ValueKey<bool>(isLiked.value),
                                  color: ColorConstant.logoSecondColor,
                                  size: getSize(27),
                                ),
                              ),
                            )


                              // IconButton(
                                //   iconSize: getSize(30),
                                //   icon: Obx(() =>
                                //       Icon(
                                //         isLiked.value ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                //         size: getSize(30),
                                //       )),
                                //   color: ColorConstant.logoSecondColor,
                                //   onPressed: () {
                                //     isLiked.value = !isLiked.value;
                                //
                                //     function.setFavorite(widget.product, false, isLiked.value).then((value) {
                                //       widget.product.is_liked = isLiked.value ? 1 : 0;
                                //       WishlistController _controller = Get.find();
                                //       _controller.GetFavorite().then((value) {
                                //         if (!value) {
                                //           isLiked.value = !isLiked.value;
                                //         }
                                //       });
                                //     });
                                //   },
                                // ),
                                ),
                          )
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8, top: 0),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      widget.product.product_name,
                      style: TextStyle(color: Colors.black, fontSize: getFontSize(12)),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  onTapWhatsapp(Product product) {
    makeWhatsappContact('+96176600252',text: "I want to ask about this product: ${product.product_name}\n${Uri.parse(product.main_image.toString().replaceAll(" ", "%20"))}\n${product.description}" );
  }
}
makeWhatsappContact(String phoneNumber, {String? text}) async {
  final Uri launchUri = Uri.parse("whatsapp://send?phone=$phoneNumber${text != null ? "&text=$text" : ""}");
  try {
    await launchUrl(launchUri);
  } catch (e) {
    Ui.ErrorSnackBar(title: "error_occurred".tr,message:  "could_not_launch".tr);

  }
}

String? progImages(String? image, fromKey) {
  List<String> newImageList = [];

  String? newImage = "";
  if (fromKey == "blur") {
    newImageList = image!.split("/");
    newImageList.insert(newImageList.length - 1, "blures");
  } else if (fromKey == "thumbnails") {
    newImageList = image!.split("/");
    newImageList.insert(newImageList.length - 1, "thumbnails");
  }

  for (int i = 0; i < newImageList.length; i++) {
    newImage ??= newImageList[i];
    newImage += "/${newImageList[i]}";
  }
  return newImage;
}

String convertToThumbnailUrl(String originalUrl, {bool isBlurred = false}) {
  // Find the last dot to get the file extension
  int lastDot = originalUrl.lastIndexOf('.');

  if (lastDot != -1) {
    // Get the URL without the extension and the extension separately
    String urlWithoutExtension = originalUrl.substring(0, lastDot);
    String extension = originalUrl.substring(lastDot);

    // Choose the appropriate suffix based on whether it's a blurred thumbnail or not
    String suffix = isBlurred ? '_blr' : '_tmb';
    return '${urlWithoutExtension}$suffix$extension';
  } else {
    // Handle URLs without an extension, if needed
    return originalUrl;
  }
}

class ProductWidgetController extends GetxController {
  RxDouble borderWidth = 0.0.obs;
}
