import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:iq_mall/screens/OrderSummaryScreen/widgets/PaymentMethodsWidets/PaymentMethodsWidget.dart';
import 'package:iq_mall/screens/Stores_screen/controller/Stores_screen_controller.dart';
import 'package:iq_mall/widgets/CommonWidget.dart';
import 'package:iq_mall/widgets/custom_image_view.dart';
import 'package:package_info/package_info.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/models/HomeData.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:iq_mall/screens/Cart_List_screen/controller/Cart_List_controller.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/utils/ShConstant.dart';
import 'package:iq_mall/utils/ShImages.dart';
import 'package:iq_mall/widgets/ShWidget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'API.dart';
import 'cores/app_localization.dart';
import 'cores/assets.dart';
import 'getxController.dart';
import 'initialBinding.dart';
import 'models/Stores.dart';
import 'models/firebase.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shrink_sidemenu/shrink_sidemenu.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/services.dart';

GlobalController globalController = Get.put(GlobalController());
RxString sign = '\$'.obs;
RxDouble drawerSize = 200.0.obs;
RxDouble? balance = 0.0.obs;
RxInt mainCurrentIndex = 0.obs;
API api = Get.put(API());
var idselected = 1;
newsLetter? news;
Counter notificationState = new Counter();
SharedPreferences? prefs;
String? deviceId;
int newCounter = 0;
RxBool LoadingDrawer = true.obs;
final List<Locale> supportedLocales = [const Locale("en", "US")];
AppLocalization appLocalization = AppLocalization();
String? country_currency_id = '1';
RxDouble? total = 0.0.obs;
RxInt index2 = 0.obs;
List addressesInfo = [];
List SingleproductInfo = [];
RxDouble? amount2 = 0.0.obs;
FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;
FirebaseInitialize firebaseInitialize = new FirebaseInitialize();

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {}

AndroidNotificationChannel? channel;

/// Initialize the [FlutterLocalNotificationsPlugin] package.
FlutterLocalNotificationsPlugin? flutterLocalNotificationsPlugin;
var subscription;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();


  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge, overlays: [SystemUiOverlay.top, SystemUiOverlay.bottom]);

  // * set status bar and nav bar colors
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.light,
    systemNavigationBarContrastEnforced: false,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));

  await Firebase.initializeApp();




  RxBool loading = true.obs;
  setUrlStrategy(PathUrlStrategy());


  HttpOverrides.global = MyHttpOverrides();

  prefs = await SharedPreferences.getInstance();
  flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  PaintingBinding.instance.imageCache.maximumSizeBytes = 100 * 1024 * 1024; // 100MB

  // var categoriesFragment = CategoriesScreen().obs;
  // var wishlistFragment = Wishlistscreen().obs;
  // var CartFragment = Cart_Listscreen().obs;
  // WidgetsBinding.instance.addPostFrameCallback((_) {
  //   Get.lazyPut(() => WishlistController());
  //   fragments.value = [
  //     homeFragment.value,
  //     categoriesFragment.value,
  //     wishlistFragment.value,
  //     CartFragment.value,
  //   ];
  // });
  ChangeStroredStore(store, newsLetterChoosen) async {
    try {
      prefs!.setString('id', store.id);
      if (newsLetterChoosen != null) {
        List<newsLetter> newsLetters = List<newsLetter>.from(newsLetterChoosen.map((x) => newsLetter.fromJson(x)));

        // news = newsLetters.firstWhere(
        //   (n) => n.r_store_id.toString() == prefs!.getString('id'),
        // );
      }
      prefs!.setString('show_add_to_cart', store.show_add_to_cart.toString());
      prefs!.setString('store_name', store.store_name);
      prefs!.setString('delivery_cost', store.delivery_amount);
      prefs!.setString('store_type', store.store_type);
      prefs!.setString('phone_number', store.phone_number);
      prefs!.setString('whatsapp_number', store.whatsapp_number);
      prefs!.setString('email', store.email);
      prefs!.setString('address', store.address);
      prefs!.setString('slug', store.slug);
      prefs!.setString('description', store.description);
      prefs!.setString('longitude', store.longitude);
      prefs!.setString('latitude', store.latitude);
      prefs!.setString('main_image', store.main_image);
      prefs!.setString('country_name', store.country_name);
      prefs!.setString('button_background_color', store.button_background_color);
      prefs!.setString('button_color', store.button_color);
      prefs!.setString('price_color', store.price_color);
      prefs!.setString('discount_price_color', store.dicount_price_color);
      prefs!.setString('grid_type', store.grid_type);
      prefs!.setString('main_color', store.main_color);
      prefs!.setString('icon_color', store.icon_color);
      prefs!.setString('slider_type', store.slider_type);
      prefs!.setString('setting_image', store.setting_image);
      prefs!.setString('privacy_policy', store.privacy_policy);
      prefs!.setString('terms_conditions', store.terms_conditions);

      changeColorsAndDisplay(store.button_color, store.main_color, store.dicount_price_color);
    } on Exception catch (_) {}
  }

  Future<bool> CheckAutoLogin() async {
    bool success = false;

    Map<String, dynamic> response = await api.getData({
      'token': prefs?.getString("token") ?? "",
    }, "users/auto-login");

    if (response.isNotEmpty) {
      success = response["succeeded"];
      loading.value = false;
    }
    if (success) {
    } else {}
    return success;
  }

  CheckAutoLogin();
  Future<bool> FetchStores() async {
    bool success = false;

    Map<String, dynamic> response = await api.getData({
      'token': prefs!.getString("token") ?? "",
    }, "stores/get-stores");

    if (response.isNotEmpty) {
      List StoresInfo = response["stores"];
      success = response["succeeded"];
      if (success) {
        prefs!.setString('stp_key', response["stp_key"].toString());
        //Stripe.publishableKey = prefs!.getString('stp_key')!;
        // if (response["multi_store"].toString() == '1') {
        //   branches_countries = response["branches_countries"];
        //   prefs!.setString('Stores_page_background', response['section'][0]['main_image']);
        //   prefs!.setString('welcome_text', response['section'][0]['welcome_text']);
        //   prefs!.setString('brief_text', response['section'][0]['brief_text']);
        //   if (response['section'] != null && response['section'].length > 0 && response['section'][0]['gif_image'] != null) {
        //     prefs!.setString('gif_image', response['section'][0]['gif_image'] ?? 'default_value');
        //   }
        //
        //   payment_methods = response["payment_types"];
        //   prefs!.setBool('multi_store', false);
        //   prefs!.setString('cart_btn', response['cart_btn'].toString());
        //   prefs!.setString('has_gift_card', response['has_gift_card'].toString());
        //   prefs!.setString('has_shipping', response['has_shipping'].toString());
        //   prefs!.setString('express_delivery_img', response['express_delivery_img'].toString());
        //   storeList.clear();
        //   for (int i = 0; i < StoresInfo.length; i++) {
        //     StoreClass.fromJson(StoresInfo[i]);
        //   }
        //   loading.value = false;
        //
        prefs!.setBool('multi_store', true);
        // } else {
        branches_countries = response["branches_countries"];
        prefs!.setString('Stores_page_background', response['section'][0]['main_image']);
        prefs!.setString('welcome_text', response['section'][0]['welcome_text'].toString());
        prefs!.setString('brief_text', response['section'][0]['brief_text'].toString());
        prefs!.setString('gif_image', response['section'][0]['gif_image'].toString());

        payment_methods = response["payment_types"];
        GiftCards_payment_methods = response["gift_cards_payment_types"];
        storeList.clear();
        StoresInfo = response["stores"];
        for (int i = 0; i < StoresInfo.length; i++) {
          StoreClass.fromJson(StoresInfo[i]);
        }

        prefs!.setBool('multi_store', true);
        prefs!.setString('cart_btn', response['cart_btn'].toString());
        prefs!.setString('has_gift_card', response['has_gift_card'].toString());
        prefs!.setString('has_shipping', response['has_shipping'].toString());
        prefs!.setString('express_delivery_img', response['express_delivery_img'].toString());

        ChangeStroredStore(storeList[0], response["newsLetters"]);
        loading.value = false;
        //  }
      }
    } else {}
    return success;
  }

  await FetchStores();
  await api.getDataaa({'date': getTranslationPref() ?? "1970-01-01 00:00:00"}, "master/get-translations", true).then((value) async {
    Map<String, Map<String, String>> x = {};
    try {
      appLocalization = AppLocalization()..loadTranslations(value);
    } catch (e) {}
  });



  await firebaseInitialize.initializeFirebase();
  initPackageInfo();

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  if (!kIsWeb) {
    channel = const AndroidNotificationChannel(
        'high_importance_channel', // id
        'High Importance Notifications', // title// description
        importance: Importance.high,
        showBadge: true);
    await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => notificationState),
      ],
      child: MyApp(),
    ),
  );
}

final GlobalKey<SideMenuState> sideMenuKey = GlobalKey<SideMenuState>();

Widget buildMenu(context) {
  String? version = '';

  PackageInfo.fromPlatform().then((PackageInfo packageInfo) {
    version = packageInfo.version;
  });
  return Obx(() => !LoadingDrawer.value
      ? Container(
    color: Colors.white10,
          key: UniqueKey(),
          height: MediaQuery.of(context).size.height - (AppBar().preferredSize.height + getSize(40)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: getPadding(left: 24.0, right: 10.0),
                    child: Row(
                      children: <Widget>[
                        CustomImageView(
                            url: prefs!.getString('Profile_image'),
                            // svgUrl: prefs!.getString('Profile_image') ?? null,
                            imagePath: AssetPaths.placeholder,
                            height: getSize(60),
                            width: getSize(60),
                            notOpen: false,
                            onTap: () {
                              state?.closeSideMenu();
                              Get.toNamed(AppRoutes.AccountsScreen);
                            },
                            fit: BoxFit.cover,
                            radius: BorderRadius.circular(getSize(20))),

                        Padding(
                          padding: getPadding(left: 8.0),
                          child: Column(
                            children: [
                              Text(
                                "${prefs?.getString('first_name') ?? ''} ${prefs?.getString('last_name') ?? ''}",
                                style: TextStyle(fontSize: getFontSize(15)),
                              ),
                              if (prefs != null && prefs!.getString('logged_in') == 'true' && prefs!.getString('has_gift_card') == '1') ...[
                                Obx(
                                  () => Text(
                                    '${'Balance: '.tr}${balance!.value} \$',
                                    style: TextStyle(color: MainColor, fontSize: getFontSize(15), fontWeight: FontWeight.w400),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),

                        // Check for logged_in
                      ],
                    ),
                  ),

                  prefs?.getString('logged_in') == 'true'
                      ? getDrawerItem(AssetPaths.account_image, 'Account'.tr, callback: () {
                          state?.closeSideMenu();
                          Get.toNamed(AppRoutes.AccountsScreen)?.then((value) => {});
                        })
                      : const SizedBox(),
                  prefs!.getBool('multi_store') == true
                      ? getDrawerItem(AssetPaths.stores, 'Stores'.tr, callback: () {
                          state?.closeSideMenu();
                          Get.toNamed(AppRoutes.Stores, arguments: false);
                        })
                      : const SizedBox(),
                  // getDrawerItem(AssetPaths.brand_image, 'Brands'.tr, callback: () {
                  //   state?.closeSideMenu();
                  //   Get.toNamed('/brandsscreen'); // This should match the name in GetPage
                  // }),
                  prefs?.getString('logged_in') == 'true'
                      ? getDrawerItem(AssetPaths.notification_image, 'Notifications'.tr, callback: () {
                          state?.closeSideMenu();
                          Get.toNamed(AppRoutes.NotificationsScreen, arguments: false);
                        })
                      : const SizedBox(),
                  // prefs?.getString('logged_in') == 'true' && prefs!.getString('has_gift_card') == '1'
                  //     ? getDrawerItem(AssetPaths.wallet, 'Gift Cards'.tr, callback: () {
                  //         state?.closeSideMenu();
                  //         Get.toNamed(AppRoutes.wallet);
                  //       })
                  //     : const SizedBox(),
                  getDrawerItem(AssetPaths.contactus_image, 'Contact us'.tr, callback: () {
                    state?.closeSideMenu();
                    Get.toNamed(
                      AppRoutes.ContactusScreen,
                    );
                  }),
                  getDrawerItem(AssetPaths.language, 'Languages'.tr, callback: () {
                    state?.closeSideMenu();
                    Get.toNamed(AppRoutes.settings);
                  }),
                  Padding(
                    padding: const EdgeInsets.only(left: 4.0),
                    child: Container(
                      color: Colors.white,
                      child: prefs?.getString('logged_in') != 'true'
                          ? getDrawerItem(AssetPaths.logout, "Login".tr, callback: () {
                              state?.closeSideMenu();

                              Get.toNamed(AppRoutes.SignIn);
                            })
                          : getDrawerItem(AssetPaths.logout, "Logout".tr, callback: () {
                              state?.closeSideMenu();
                              prefs?.setString('logged_in', 'false');
                              prefs!.remove("first_name");
                              prefs!.remove("last_name");
                              prefs!.remove("user_name");
                              prefs!.remove("country_code");
                              prefs!.remove("user_id");
                              prefs!.remove("user_role");
                              prefs!.remove("phone_number");
                              prefs!.remove("login_method");
                              prefs!.remove("token");
                              prefs!.remove("Profile_image");
                              firebaseMessaging.deleteToken();
                              prefs?.setString('seen', 'true');
                              favoritelist?.clear();
                              cartlist?.clear();
                              Get.offAllNamed(AppRoutes.SignIn);
                            }),
                    ),
                  ),
                  SizedBox(),
                ],
              ),
              Padding(
                padding: getPadding(bottom: getTopPadding() +8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: getPadding(top: 8.0),
                      child: InkWell(
                        onTap: () async {
                          const String url = "https://brainkets.com";
                          final Uri uri = Uri.parse(url);
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri, mode: LaunchMode.externalApplication);
                          } else {
                            throw 'Could not launch $url';
                          }
                        },
                        child: SvgPicture.asset(
                          AssetPaths.powered_v,
                        ),
                      ),
                    ),
                    Padding(
                      padding: getPadding(top: 8.0),
                      child: Text("Version ${globalController.appVersion.value}", style: TextStyle(fontSize: getFontSize(12))),
                    )
                  ],
                ),
              )
            ],
          ),
        )
      : SizedBox());
}

Widget getDrawerItem(String? icon, String? name, {VoidCallback? callback}) {
  return Padding(
    padding: getPadding(top: 12.0),
    child: InkWell(
      onTap: () {
        callback!();
      },
      child: Container(
        color: sh_white,
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Row(
          children: <Widget>[
            icon != null ? SVG(icon, 27, 27, Button_color) : Container(width: 20),
            const SizedBox(width: 20),
            text(
              name,
              textColor: sh_textColorPrimary,
              fontSize: textSizeSMedium,
              fontFamily: 'Poppins',
            )
          ],
        ),
      ),
    ),
  );
}

Future<void> initPackageInfo() async {
  final info = await PackageInfo.fromPlatform();
  globalController.appVersion.value = info.version;
}

class SideMenuObserver extends NavigatorObserver {
  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);

    // Check if the SideMenu is open, and if yes, close it.
    if (sideMenuKey.currentState?.isOpened ?? false) {
      state?.closeSideMenu();
    }
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
        navigatorKey: Get.key,
        scrollBehavior: const MaterialScrollBehavior(),
        theme: ThemeData(
          primarySwatch: Colors.grey,
          scaffoldBackgroundColor: sh_light_grey,
          pageTransitionsTheme: const PageTransitionsTheme(builders: {
            TargetPlatform.android: CupertinoPageTransitionsBuilder(),
            TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          }),
        ),
        navigatorObservers: [SideMenuObserver()],
        getPages: AppRoutes.routes,
        initialRoute: AppRoutes.tabsRoute,


        debugShowCheckedModeBanner: false,
        textDirection: TextDirection.ltr,
        translations: appLocalization,
        locale: Get.locale,
        fallbackLocale: Locale('en', 'US'),
        initialBinding: InitialBindings(),
        defaultTransition: Transition.cupertino,
        transitionDuration: const Duration(milliseconds: 200),
        builder: (context, child) {
          return Directionality(
             textDirection: TextDirection.ltr,
            child: Stack(
              children: [
                // GestureDetector to detect taps outside the menu
                GestureDetector(
                  onTap: () {
                    if (sideMenuKey.currentState?.isOpened ?? false) {
                      state?.closeSideMenu();
                    }
                  },
                  child: Container(color: Colors.transparent), // full screen transparent container
                ),
                Builder(
                    builder: (context) => SideMenu(
                          background: Colors.white,
                          closeIcon: Icon(
                            Icons.close,
                            color: MainColor,
                          ),
                          onChange: (isOpened) {
                            globalController.updateSideMenuStatus(isOpened);
                          },
                          key: sideMenuKey,
                          menu: buildMenu(context),
                          type: SideMenuType.slide,
                          maxMenuWidth: getHorizontalSize(230.0),
                          child: child!,
                        )),
              ],
            ),
          );
        });
  }
}

class Counter with ChangeNotifier, DiagnosticableTreeMixin {
  int _counter = prefs?.getInt('counter') ?? 0;
  int _unreadednotifications = 0;
  String? _srtingprice = 'RAND';
  int _value = 0;

  int get counter => _counter;

  RxList<Product>? get cartliststate => cartlist;

  String? get sortingprice => _srtingprice;

  int get value => _value;

  int get unreadednotifications => _unreadednotifications;

  unreadednotification() async {
    try {
      prefs = await SharedPreferences.getInstance();
      var url = con! + "notification/get-count";
      final http.Response response = await http.post(
        Uri.parse(url),
        body: {
          'user_id': prefs?.getString('user_id'),
        },
      );
      var count = json.decode(response.body) as List;
      _unreadednotifications = int.parse(count[0]['unreaded']);
      notifyListeners();
    } catch (ex) {}
  }


  double calculateTotal(double couponPercentage) {
    double totalAmount = 0.0;

    for (int i = 0; i < cartlist!.length; i++) {
      if (cartlist![i].price_after_discount == null || cartlist![i].price_after_discount.toString() == 'null') {
        totalAmount += (double.parse(cartlist![i].product_price.toString()) * int.parse(cartlist![i].quantity!));
      } else {
        totalAmount += (double.parse(cartlist![i].price_after_discount.toString()) * int.parse(cartlist![i].quantity!));
      }
    }

    double discount = totalAmount * (couponPercentage / 100.0);
    if (prefs != null) {
      String? deliveryCostString = prefs!.getString('delivery_cost');
      if (deliveryCostString != null) {
        totalAmount = ((totalAmount - discount) + double.parse(deliveryCostString));
      }
    }
    // globalController.updateCartPrice(totalAmount);


    return double.parse(totalAmount.toStringAsFixed(2));
  }

  incrementIndex(int index) {
    _value = index;
    notifyListeners();
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)..badCertificateCallback = (X509Certificate cert, String? host, int port) => true;
  }
}

void computeAdditionalCostSum() {
  if (prefs!.getString('has_shipping') == '1' && cartlist != null) {
    Set<String> flatRateProductsProcessed = {}; // to track items with flat rate already added

    for (var product in cartlist!) {
      // If the product has free shipping
      if (product.free_shipping == 1) continue;

      // If the product has multi shipping
      if (product.multi_shipping != null && product.multi_shipping == 1) {
        int? quantity;
        try {
          quantity = int.parse(product.quantity!);
        } catch (e) {
          quantity = null; // or provide a default value if you want, e.g., quantity = 1;
        }

        globalController.updateAdditionalPrice(globalController.sum.value+(product.shipping_cost ?? 0.0) * (quantity ?? 1));
      }

      // If the product has a flat rate and has not been processed yet
      else if (product.flat_rate == 1 && !flatRateProductsProcessed.contains(product.product_id)) {
        globalController.updateAdditionalPrice(globalController.sum.value+(product.shipping_cost??0.0) );

        flatRateProductsProcessed.add(product.product_id.toString()); // mark the product as processed
      }
    }

  }
}
void calculateTotalWithoutDelivery() {
  // Initialize total to 0
  RxDouble totalAmounnt = RxDouble(0);

  for (int i = 0; i < cartlist!.length; i++) {
    if (cartlist![i].price_after_discount == null || cartlist![i].price_after_discount.toString() == 'null') {
      totalAmounnt.value += (double.parse(cartlist![i].product_price.toString()) * int.parse(cartlist![i].quantity!));
    } else {
      totalAmounnt.value += (double.parse(cartlist![i].price_after_discount.toString()) * int.parse(cartlist![i].quantity.toString()));
    }
  }

  double discount = totalAmounnt * (0 / 100);

  if (prefs != null) {
    String? deliveryCostString = prefs!.getString('delivery_cost');
    if (deliveryCostString != null) {
      globalController.result.value = (totalAmounnt.value - discount);
    }
  }

  // Round to 2 decimal places
  double roundedResult = (double.parse((globalController.result.value + 0.004).toStringAsFixed(3)) * 100 / 100).toDouble();

  totalAmounnt.value = double.parse(roundedResult.toStringAsFixed(2));
  total!.value = totalAmounnt.value;

  globalController.updateCartPrice(total!.value);

}
