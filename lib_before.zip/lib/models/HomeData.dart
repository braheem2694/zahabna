// To parse this JSON data, do
//
//     final HomeData = HomeDataFromJson(jsonString);

import 'dart:convert';
import 'dart:ffi';

import 'package:get/get.dart';

HomeData HomeDataFromJson(String str) => HomeData.fromJson(json.decode(str));

String HomeDataToJson(HomeData data) => json.encode(data.toJson());

class HomeData {
  bool? succeeded;
  String? message;
  bool? isRetail;
  List<Category>? categories;
  RxList<ProductSection>? productSections;
  List<Product>? products;
  List<Brand>? brands;
  List<FlashSale>? flashSales;
  List<Product>? flashProducts;
  List<Hour>? hours;
  List<GridElement>? gridElements;
  List<Social>? socials;

  HomeData({
    this.succeeded,
    this.message,
    this.isRetail,
    this.categories,
    this.productSections,
    this.products,
    this.brands,
    this.flashSales,
    this.flashProducts,
    this.hours,
    this.gridElements,
    this.socials,
  });

  factory HomeData.fromJson(Map<dynamic, dynamic> json) => HomeData(
        succeeded: json["succeeded"],
        message: json["message"],
        isRetail: json["is_retail"],
        categories: List<Category>.from(json["categories"]?.map((x) => Category.fromJson(x)) ?? []),
        productSections: List<ProductSection>.from(json["product_sections"]?.map((x) => ProductSection.fromJson(x)) ?? []).obs,
        products: List<Product>.from(json["products"]?.map((x) => Product.fromJson(x)) ?? []),
        brands: List<Brand>.from(json["brands"]?.map((x) => Brand.fromJson(x)) ?? []),
        flashSales: List<FlashSale>.from(json["flash_sales"]?.map((x) => FlashSale.fromJson(x)) ?? []),
        flashProducts: List<Product>.from(json["flash_products"]?.map((x) => Product.fromJson(x)) ?? []),
        hours: List<Hour>.from(json["hours"]?.map((x) => Hour.fromJson(x)) ?? []),
        gridElements: List<GridElement>.from(json["grid_elements"]?.map((x) => GridElement.fromJson(x)) ?? []),
        socials: List<Social>.from(json["socials"]?.map((x) => Social.fromJson(x)) ?? []),
      );

  Map<String, dynamic> toJson() => {
        "succeeded": succeeded,
        "message": message,
        "is_retail": isRetail,
        "categories": List<dynamic>.from(categories!.map((x) => x.toJson())),
        "product_sections": List<dynamic>.from(productSections!.map((x) => x.toJson())),
        "products": List<dynamic>.from(products!.map((x) => x.toJson())),
        "brands": List<dynamic>.from(brands!.map((x) => x.toJson())),
        "flash_sales": List<dynamic>.from(flashSales!.map((x) => x.toJson())),
        "flash_products": List<dynamic>.from(flashProducts!.map((x) => x.toJson())),
        "hours": List<dynamic>.from(hours!.map((x) => x.toJson())),
        "grid_elements": List<dynamic>.from(gridElements!.map((x) => x.toJson())),
        "socials": List<dynamic>.from(socials!.map((x) => x.toJson())),
      };
}

class Brand {
  int id;
  String brandName;
  String slug;
  String main_image;
  int productCount;
  String backgroundImg;
  bool isSelected;

  Brand({
    required this.brandName,
    required this.id,
    required this.isSelected,
    required this.slug,
    required this.main_image,
    required this.productCount,
    required this.backgroundImg,
  });

  factory Brand.fromJson(Map<String, dynamic> json) => Brand(
        id: json["id"],
        brandName: json["brand_name"],
        isSelected: false,
        slug: json["slug"],
        main_image: json["background_img"].toString(),
        productCount: json["product_count"],
        backgroundImg: json["background_img"].toString(),
      );

  Map<String, dynamic> toJson() => {
        "brand_name": brandName,
        "slug": slug,
        "main_image": main_image,
        "product_count": productCount,
        "background_img": backgroundImg,
      };
}

class Category {
  int id;
  String categoryName;
  String slug;
  int? parent;
  String? main_image;
  int showInNavbar;
  int productCount;
  bool isSelected;

  Category({
    required this.id,
    required this.categoryName,
    required this.slug,
    required this.parent,
    required this.main_image,
    required this.showInNavbar,
    required this.productCount,
    required this.isSelected,
  });

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        isSelected: false,
        id: json["id"],
        categoryName: json["category_name"],
        slug: json["slug"],
        parent: json["parent"],
        main_image: json["main_image"],
        showInNavbar: json["show_in_navbar"],
        productCount: json["product_count"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "category_name": categoryName,
        "slug": slug,
        "parent": parent,
        "main_image": main_image,
        "show_in_navbar": showInNavbar,
        "product_count": productCount,
      };
}

class Variation {
  final int? variation_id;
  final int? option_id;
  final int? value_id;
  double? price;
  final int? default_option;
  final String? type;
  final int? is_color;
  final String? name;
  final String? color;
  final double? price_after_discount;

  Variation.fromJson(Map<String, dynamic> json)
      : variation_id = json['variation_id'],
        option_id = json['option_id'],
        value_id = json['value_id'],
        price = json['price']?.toDouble(),
        default_option = json['default_option'],
        type = json['type'],
        is_color = json['is_color'],
        name = json['name'],
        color = json['color'],
        price_after_discount = json['price_after_discount']?.toDouble();

  Map<String, dynamic> toJson() => {
        'variation_id': variation_id,
        'option_id': option_id,
        'value_id': value_id,
        'price': price,
        'default_option': default_option,
        'type': type,
        'is_color': is_color,
        'name': name,
        'color': color,
        'price_after_discount': price_after_discount,
      };
}

class Product {
  final int product_id;
  int? r_flash_id;
  final String product_name;
  final String product_section;
  final String? description;
  double product_price;
  final String slug;
  final int has_option;
  String? join;
  double? price_after_discount;
  final String? main_image;
  int? is_liked;
  Store store;
  final List<MoreImage>? more_images;
  final String? product_code;
  final int? is_ordered_before;
  final int? opening_qty;
  int product_qty_left;
  final int? vat;
  final double? product_weight;
  final int? boolean_percent_discount;
  final int? sales_discount;
  final int? free_shipping;
  final int? flat_rate;
  final int? multi_shipping;
  final double? shipping_cost;
   int? rate;
  final int? reviews_count;
  int? orders_count;
  final int? cart_btn;
  final int? outOfStock;
  final int? express_delivery;
  int? in_cart;
  bool? loading;
  String? quantity;
  String? cart_id;
  String? removing;
  String? options;
  String? variationfound;
  String? variant_id;
  List<Variation>? variations;

  Product.fromJson(Map<String, dynamic> json)
      : product_id = json["id"] ?? json["product_id"],
        product_name = json["product_name"],
        variations = (json["variations"] != null && (json["variations"] as List).isNotEmpty) ? (json["variations"] as List).map((v) => Variation.fromJson(v)).toList() : null,
        join = json['in_cart'].toString() == '0' ? '0' : '1',
        quantity = json['quantity'].toString(),
        cart_btn = json['cart_btn'],
        express_delivery = json['express_delivery'],
        product_section = json['product_section'].toString(),
        cart_id = json['cart_id'].toString(),
        outOfStock = json['out_of_stock'],
        removing = "0",
        variant_id = json['variant_id'].toString(),
        variationfound = json['variationfound'].toString(),
        options = json['options'].toString(),
        is_ordered_before = json["is_ordered_before"] == null ? 0 : 1,
        r_flash_id = json["r_flash_id"],
        description = json["description"],
        product_price = double.parse(json["product_price"].toString()),
        slug = json["slug"].toString(),
        has_option = json["has_option"] ?? 0,
        price_after_discount = json["price_after_discount"]?.toDouble(),
        main_image = json["main_image"],
        is_liked = json["is_liked"] ?? 0,
        more_images = json["more_images"] != null ? List<MoreImage>.from(json["more_images"].map((x) => MoreImage.fromJson(x))) : [],
        store = Store.fromJson({
          "store_id": json["store_id"],
          "store_name": json["store_name"],
          "store_image": json["store_image"],
          "store_whatsapp_number": json["store_whatsapp_number"],
        }),
        product_code = json["product_code"],
        opening_qty = json["opening_qty"],
        product_qty_left = int.tryParse(json["product_qty_left"].toString())?? 0,
        vat = json["vat"],
        product_weight = json["product_weight"] == null ? null : double.parse(json["product_weight"].toString()),
        boolean_percent_discount = json["boolean_percent_discount"],
        sales_discount = json["sales_discount"] != null ? json["sales_discount"].toInt() : null,
        free_shipping = json["free_shipping"],
        loading = false,
        flat_rate = json["flat_rate"],
        multi_shipping = json["multi_shipping"],
        shipping_cost = json["shipping_cost"] == null ? null : double.parse(json["shipping_cost"].toString()),
        rate = json["rating"] == null ? 0 : int.parse(double.parse(json["rating"]).toStringAsFixed(0)),
        reviews_count = json["reviews_count"],
        in_cart = json["in_cart"],
        orders_count = json["orders_count"];

  Map<String, dynamic> toJson() => {
        "quantity": quantity,
        "cart_id": cart_id,
        "cart_btn": cart_btn,
        "removing": "0",
        "variant_id": variant_id,
        "express_delivery": express_delivery,
        "product_section": product_section,
        "variationfound": variationfound,
        "options": options,
        "id": product_id,
        "in_cart": in_cart,
        "product_name": product_name,
        "r_flash_id": r_flash_id,
        "description": description,
        "product_price": product_price,
        "slug": slug,
        "has_option": has_option,
        "price_after_discount": price_after_discount,
        "main_image": main_image,
        "is_liked": is_liked,
        "more_images": more_images == null ? [] : List<dynamic>.from(more_images!.map((x) => x)),
        // New fields
        "product_code": product_code,
        "opening_qty": opening_qty,
        "product_qty_left": product_qty_left,
        "vat": vat,
        "product_weight": product_weight,
        "boolean_percent_discount": boolean_percent_discount,
        "sales_discount": sales_discount,
        "free_shipping": free_shipping,
        "flat_rate": flat_rate,
        "multi_shipping": multi_shipping,
        "shipping_cost": shipping_cost,
        "rating": rate,
        "reviews_count": reviews_count,
        "orders_count": orders_count,
      };
}

class FlashSale {
  int id;
  String title;
  int sliderType;
  String color1;
  String color2;
  String color3;
  DateTime endTime;

  FlashSale({
    required this.id,
    required this.title,
    required this.sliderType,
    required this.color1,
    required this.color2,
    required this.color3,
    required this.endTime,
  });

  factory FlashSale.fromJson(Map<String, dynamic> json) => FlashSale(
        id: json["id"],
        title: json["title"],
        sliderType: json["slider_type"],
        color1: json["color_1"],
        color2: json["color_2"],
        color3: json["color_3"],
        endTime: DateTime.parse(json["end_time"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "slider_type": sliderType,
        "color_1": color1,
        "color_2": color2,
        "color_3": color3,
        "end_time": endTime.toIso8601String(),
      };
}

class GridElement {
  int id;
  String x;
  String y;
  String w;
  String h;
  String main_image;
  List<Actions> actions;
  List<MoreImage> more_images;

  GridElement({
    required this.id,
    required this.x,
    required this.y,
    required this.w,
    required this.h,
    required this.main_image,
    required this.actions,
    required this.more_images,
  });

  factory GridElement.fromJson(Map<String, dynamic> json) {
    List<dynamic> actionsList = [];

    if (json["actions"] is String) {
      actionsList = jsonDecode(json["actions"]);
    } else if (json["actions"] is List) {
      actionsList = json["actions"];
    }

    return GridElement(
      id: json["id"],
      x: json["x"],
      y: json["y"],
      w: json["w"],
      h: json["h"],
      main_image: json["main_image"].toString(),
      actions: actionsList.map<Actions>((x) => Actions.fromJson(x)).toList(),
      more_images: json["more_images"] == null ? [] : List<MoreImage>.from(json["more_images"].map((x) => MoreImage.fromJson(x))),
    );
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "x": x,
        "y": y,
        "w": w,
        "h": h,
        "main_image": main_image,
        "actions": List<dynamic>.from(actions.map((x) => x.toJson())),
        "more_images": List<dynamic>.from(more_images.map((x) => x.toJson())),
      };
}

class Actions {
  int id;
  String target_type;
  String slug;

  Actions({
    required this.id,
    required this.target_type,
    required this.slug,
  });

  factory Actions.fromJson(Map<String, dynamic> json) => Actions(
        id: json["id"],
        target_type: json["target_type"],
        slug: json["slug"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "target_type": target_type,
        "slug": slug,
      };
}

class MoreImage {
  int id;
  String file_path;
  int? type;
  int? isVideo;

  MoreImage({
    required this.id,
    required this.file_path,
    required this.type,
    required this.isVideo,
  });

  factory MoreImage.fromJson(Map<String, dynamic> json) => MoreImage(
        id: json["id"],
        file_path: json["file_path"],
        type: json["type"],
        isVideo: json["is_video"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "file_path": file_path,
      };
}

class Hour {
  String day;
  String openTime;
  String closeTime;

  Hour({
    required this.day,
    required this.openTime,
    required this.closeTime,
  });

  factory Hour.fromJson(Map<String, dynamic> json) => Hour(
        day: json["day"],
        openTime: json["open_time"],
        closeTime: json["close_time"],
      );

  Map<String, dynamic> toJson() => {
        "day": day,
        "open_time": openTime,
        "close_time": closeTime,
      };
}

class ProductSection {
  int id;
  String slug;
  String sectionName;
  int slider_type;
  int? rGridId;
  List<GridElement>? gridElements;

  ProductSection({
    required this.id,
    required this.slug,
    required this.sectionName,
    required this.slider_type,
    required this.rGridId,
    required this.gridElements,
  });

  factory ProductSection.fromJson(Map<String, dynamic> json) => ProductSection(
        id: json["id"],
        slug: json["slug"],
        sectionName: json["section_name"],
        slider_type: json["slider_type"],
        rGridId: json["r_grid_id"],
        gridElements: json["grid_elements"] == null ? [] : List<GridElement>.from(json["grid_elements"]!.map((x) => GridElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "slug": slug,
        "section_name": sectionName,
        "slider_type": slider_type,
        "r_grid_id": rGridId,
        "grid_elements": gridElements == null ? [] : List<dynamic>.from(gridElements!.map((x) => x.toJson())),
      };
}

class Social {
  int id;
  String icon;
  String link;

  Social({
    required this.id,
    required this.icon,
    required this.link,
  });

  factory Social.fromJson(Map<String, dynamic> json) => Social(
        id: json["id"],
        icon: json["icon"],
        link: json["link"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "icon": icon,
        "link": link,
      };
}

class Store {
  int? id;
  String? name;
  String? image;
  String? storeWhatsappNumber;

  Store({
    required this.id,
    required this.name,
    required this.image,
    required this.storeWhatsappNumber,
  });

  factory Store.fromJson(Map<String, dynamic> json) => Store(
        id: json["store_id"],
        name: json["store_name"],
        image: json["store_image"],
        storeWhatsappNumber: json["store_whatsapp_number"],
      );
}
class ProductCategories {
  int? id;
  String? categoryImage;
  String? categoryName;

  ProductCategories({
    required this.id,
    required this.categoryImage,
    required this.categoryName,
  });

  factory ProductCategories.fromJson(Map<String, dynamic> json) => ProductCategories(
    id: json["id"],
    categoryImage: json["main_image"],
    categoryName: json["category_name"],
  );
}

