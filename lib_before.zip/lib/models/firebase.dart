import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';

import '../main.dart';

class FirebaseInitialize {
  Future<void> initializeFirebase() async {
    await FirebaseMessaging.instance.getInitialMessage().then((RemoteMessage? message) {
      if (message != null) {
        // Handle the initial message if needed
      }
    });

    var initializationSettingsAndroid = const AndroidInitializationSettings('@mipmap/ic_launcher');

    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      if (notification != null && android != null && !kIsWeb) {
        createNotification(message);
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      Get.toNamed('/notification', arguments: {'reload': true});
    });
  }


  Future onSelectNotification(String? payload) async {
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      Get.toNamed('/notification', arguments: {'reload': true});
    });
  }

  Future<void> onActionSelected(String? value) async {
    switch (value) {
      case 'subscribe':
        {
          await FirebaseMessaging.instance.subscribeToTopic('fcm_test');
        }
        break;
      case 'unsubscribe':
        {
          await FirebaseMessaging.instance.unsubscribeFromTopic('fcm_test');
        }
        break;
      case 'get_apns_token':
        {
          if (defaultTargetPlatform == TargetPlatform.iOS ||
              defaultTargetPlatform == TargetPlatform.macOS) {
            String? token = await FirebaseMessaging.instance.getAPNSToken();
          } else {}
        }
        break;
      default:
        break;
    }
  }

  setActionCodeSettings() {
    ActionCodeSettings actionCodeSettings = ActionCodeSettings(
      url: 'http://myurl.io/join',
      androidInstallApp: false,
      androidMinimumVersion: "23",
      androidPackageName: "com.smartersvision.doctors_appointments",
      handleCodeInApp: true,
    );
  }

  deleteFireBaseInstance() async {
    FirebaseMessaging.instance.deleteToken();
  }

  Future<void> sendPasswordResetEmail(String? email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email!);
    } catch (error) {
      
    }
  }

  Future createNotification(RemoteMessage message) async {
    notificationState.unreadednotification();
    // AwesomeNotifications().initialize("resource://drawable/ic_launcher.png", [
    //   NotificationChannel(
    //       channelKey: 'basic_channel',
    //       channelName: 'Basic notifications',
    //       channelDescription: 'Notification channel for basic tests',
    //       defaultColor: Color(0xFF9D50DD),
    //       vibrationPattern: lowVibrationPattern,
    //       importance: NotificationImportance.High,
    //       ledColor: Colors.white)
    // ]);
    //
    // AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
    //   if (!isAllowed) {
    //     AwesomeNotifications().requestPermissionToSendNotifications();
    //   }
    // });
    //
    // AwesomeNotifications().createNotification(
    //     content: NotificationContent(
    //         id: 10,
    //         channelKey: 'basic_channel',
    //         notificationLayout: NotificationLayout.BigPicture,
    //         largeIcon: "resource://drawable/ic_launcher",
    //         color: Colors.blueAccent,
    //         backgroundColor: Color(0xff281a55),
    //         displayOnBackground: true,
    //         displayOnForeground: true,
    //         progress: 5,
    //         ticker: "hello brainkets",
    //         showWhen: true,
    //         icon: "resource://drawable/ic_stat_notifications_none",
    //         title: message.notification?.title,
    //         body: message.notification?.body));
  }
}
