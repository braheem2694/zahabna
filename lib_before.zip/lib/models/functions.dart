import 'dart:convert';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:image_pickers/image_pickers.dart';
import 'package:get/get.dart';
import 'package:iq_mall/widgets/ShWidget.dart';
import 'package:iq_mall/main.dart';
import 'package:permission_handler/permission_handler.dart';
import '../Product_widget/Product_widget.dart';
import '../screens/Home_screen_fragment/controller/Home_screen_fragment_controller.dart';
import '../utils/ShColors.dart';

class function {
  static Future<bool?> setFavorite(product, reload,bool isLiked) async {
    if (reload) recheck.value = true;
    bool success = false;
    Map<String, dynamic> response = await api.getData({
      'storeId': prefs!.getString("id") ?? "",
      'product_id': product.product_id,
      'token': prefs!.getString("token") ?? "",
      'is_liked': isLiked,
    }, "products/set-favorite");

    if (response.isNotEmpty) {
      success = response["succeeded"];

      // Get.lazyPut(() => WishlistController());
      // var wishlistController = Get.find<WishlistController>();
      // wishlistController.GetFavorite();
      if (success) {
        if (product!.is_liked == 0) {
          product!.is_liked = 1;
          for (var productSample in globalController.homeDataList.value.products!) {
            if (productSample.product_id == product.product_id) {
              productSample.is_liked = 1;
            }
          }
          for (var productSample in globalController.homeDataList.value.flashProducts!) {
            if (productSample.product_id == product.product_id) {
              productSample.is_liked = 1;
            }
          }
        } else {
          for (var productSample in globalController.homeDataList.value.products!) {
            if (productSample.product_id == product.product_id) {
              productSample.is_liked = 0;
            }
          }
          for (var productSample in globalController.homeDataList.value.flashProducts!) {
            if (productSample.product_id == product.product_id) {
              productSample.is_liked = 0;
            }
          }
          product!.is_liked = 0;
        }
        recheck.value = false;
        return success;
      } else {
        toaster(Get.context!, response["message"]);
      }
    } else {
      toaster(Get.context!, 'Failed');
    }
    return null;
  }

  static List currencyExInfo = [];

 static Future<List<Media>> multiImagePicker(GalleryMode mode, int count) async {
    List<Media> _listImagePaths = <Media>[];

    if (Platform.isAndroid) {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      if (androidInfo.version.sdkInt >= 33) {
        Map<Permission, PermissionStatus> status = await [
          Permission.storage,
          Permission.photos,
          Permission.mediaLibrary,
        ].request();
        if (status[Permission.storage] != PermissionStatus.granted ||
            status[Permission.photos] != PermissionStatus.granted ||
            status[Permission.mediaLibrary] != PermissionStatus.granted) {}
      } else {
        await Permission.storage.status.isGranted;
      }
    }

    _listImagePaths = await ImagePickers.pickerPaths(
        galleryMode: mode,

        selectCount: count,
        showGif: false,
        showCamera: true,

        uiConfig: UIConfig(uiThemeColor:MainColor),
        cropConfig: CropConfig(enableCrop: true,)
    );

    /// 或者 or
    // ImagePickers.pickerPaths().then((List medias){
    //   /// medias 照片路径信息 Photo path information
    // });

    return _listImagePaths;
  }

  static RemoveFromCart(products) async {
    bool success = false;
    List<Map<String, dynamic>> productsList = [];

    for (var product in products) {
      Map<String, dynamic> productMap = {
        'product_id': int.parse(product.product_id.toString()),
        'variant_id': product.variant_id != 'null' ? int.parse(product.variant_id) : null,
      };
      productsList.add(productMap);
    }
    var data2 = json.encode(productsList);
    print(data2.toString());
    Map<String, dynamic> data = {
      'token': prefs!.getString("token") ?? "",
      'products': data2.toString(),
    };

    final sessionId = prefs!.getString("session_id");
    if (sessionId != null && sessionId.isNotEmpty && prefs!.getString("token") == null) {
      data['session_id'] = sessionId;
    }
    Map<String, dynamic> response = await api.getData(data, "cart/remove-from-cart");

    if (response.isNotEmpty) {
      success = response["succeeded"];
    }
    if (success) {
    } else {}

    return success;
  }
}
