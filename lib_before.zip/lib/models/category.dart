import 'dart:convert';

Categories categoriesFromJson(String str) => Categories.fromJson(json.decode(str));

String categoriesToJson(Categories data) => json.encode(data.toJson());

class Categories {
  bool? succeeded;
  List<Category>? categories;
  String? message;
  bool? isEnd;

  Categories({
    this.succeeded,
    this.categories,
    this.message,
    this.isEnd,
  });

  factory Categories.fromJson(Map<dynamic, dynamic> json) => Categories(
        succeeded: json["succeeded"],
        categories: List<Category>.from(json["categories"].map((x) => Category.fromJson(x))),
        message: json["message"],
        isEnd: json["is_end"],
      );

  Map<String, dynamic> toJson() => {
        "succeeded": succeeded,
        "categories": List<dynamic>.from(categories!.map((x) => x.toJson())),
        "message": message,
        "is_end": isEnd,
      };
}

class Category {
  int? id;
  String? categoryName;
  String? slug;
  dynamic parent;
  String? mainImage;
  int? showInNavbar;

  Category({
    required this.id,
    required this.categoryName,
    required this.slug,
    required this.parent,
    required this.mainImage,
    required this.showInNavbar,
  });

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        id: json["id"],
        categoryName: json["category_name"],
        slug: json["slug"],
        parent: json["parent"],
        mainImage: json["main_image"].toString(),
        showInNavbar: json["show_in_navbar"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "category_name": categoryName,
        "slug": slug,
        "parent": parent,
        "main_image": mainImage,
        "show_in_navbar": showInNavbar,
      };
}
class WorkDay {
  int? id;
  String? name;
  String? startingTime;
  String? endingTime;

  WorkDay({
    required this.id,
    required this.startingTime,
    required this.name,
    required this.endingTime,

  });

  factory WorkDay.fromJson(Map<String, dynamic> json) => WorkDay(
    id: json["id"],
    startingTime: json["starting_time"],
    endingTime: json["starting_time"],
    name: json["name"],
  );


}
