import 'package:intl/intl.dart';
import 'package:iq_mall/main.dart';

String? con = "https://jewelrycms.beeflex.net/v1_0_0-";
String? conVersion = "https://jewelrycms.beeflex.net/";
var formatter =  NumberFormat('#,###,###.##');

final datefromater = new DateFormat('dd-MM-yyyy hh:mm');
