
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';

import '../cores/math_utils.dart';
import '../main.dart';
import '../utils/ShColors.dart';

class Ui {
  static GetBar ErrorSnackBar({String? title = 'Error', String? message}) {
    Get.log("[$title] $message", isError: true);
    return GetBar(
      titleText: Text(title!.tr,
          style: Get.textTheme.titleLarge!.merge(
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      messageText: Text(message!,
          style: Get.textTheme.bodySmall!.merge(
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(20),
      backgroundColor: Colors.redAccent,
      icon: const Icon(Icons.remove_circle_outline, size: 32, color: Colors.white),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      borderRadius: 8,
      dismissDirection: DismissDirection.horizontal,
      duration: const Duration(milliseconds: 3000),
    );
  }
  static String progImages(String image, fromKey)  {
    List<String> newImageList = [];

    String newImage = "";
    if(fromKey=="blur"){
      newImageList =image.split("/");
      newImageList.insert(newImageList.length - 1, "blures");
    }
    else if(fromKey== "thumbnails"){
      newImageList =image.split("/");
      newImageList.insert(newImageList.length - 1, "thumbnails");
    }

    for (int i = 0; i < newImageList.length; i++) {
      if (newImage != "") {
        newImage += "/${newImageList[i]}";
      } else {
        newImage += newImageList[i];
      }


    }
    return newImage;

  }

  static BoxDecoration getBoxDecoration({Color? color, double? radius, Border? border, Gradient? gradient}) {
    return BoxDecoration(
      color: color ?? Get.theme.primaryColor,
      borderRadius: BorderRadius.all(Radius.circular(radius ?? 10)),
      boxShadow: [
        BoxShadow(color: Get.theme.focusColor.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 5)),
      ],
      border: border ?? Border.all(color: Get.theme.focusColor.withOpacity(0.05)),
      gradient: gradient,
    );
  }


  static flutterToast(msg, toast, backgroundColor, textColor) {
    Fluttertoast.showToast(
        msg: msg,
        toastLength: toast,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: backgroundColor,
        textColor: textColor,
        fontSize: 16.0);
  }

  static launchWhatsApp(String phoneNumber, String storeName) async {
    final link = WhatsAppUnilink(
      phoneNumber:phoneNumber,
      text: "Hey! I'm a user of $storeName",
    );
    await launch('$link');
  }

 static Widget backArrowIcon({Color iconColor= Colors.grey,String fromKey=""}){
    return
      InkWell(
        onTap: () {
          Get.back();
        },
        child: Padding(
          padding: getPadding(left: 8),
          child: SizedBox(
            height: getSize(
              25,
            ),
            width: getSize(
              25,
            ),

            child:Icon(
              Platform.isIOS?
              Icons.arrow_back_ios:Icons.arrow_back,
              color: iconColor,
              size: getSize(25),

            ),
          ),
        ),
      );
  }
  static Widget circularIndicator({
    double height = 20,
    double width = 20,
    double strokeWidth = 3,
    Color color = ColorConstant.white,
  }) {
    return Center(
        child: SizedBox(
            height: height,
            width: width,
            child:  LoadingAnimationWidget.inkDrop(color: color, size: 20,)));
  }

  static Widget circularIndicatorDefault({
    double height = 20,
    double width = 20,
    double strokeWidth = 3,
    Color color = ColorConstant.white,
  }) {
    return Center(
        child: SizedBox(
            height: height,
            width: width,
            child:  CircularProgressIndicator(color: color,strokeWidth: strokeWidth,)));
  }


// static Widget circularIndicatorRive({
  //   String riveFileName = 'assets/images/loader.riv',
  //   String animationName = 'Animation',
  //   BoxFit fit = BoxFit.contain,
  //   Alignment alignment = Alignment.center,
  //   double height = 100,
  //   double width = 100,
  // }) {
  //   return Center(
  //     child: SizedBox(
  //       height: height,
  //       width: width,
  //       child: RiveAnimation.asset(
  //         riveFileName,
  //         animations: [animationName],
  //         alignment: alignment,
  //         fit: fit,
  //       ),
  //     ),
  //   );
  // }

}
