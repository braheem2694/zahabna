import 'dart:typed_data';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/models/GiftCards.dart';
import 'package:iq_mall/screens/ProductDetails_screen/controller/ProductDetails_screen_controller.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/widgets/ui.dart';
import 'package:photo_view/photo_view.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import '../Product_widget/Product_widget.dart';
import '../models/HomeData.dart';
import '../screens/ProductDetails_screen/widgets/better_player.dart';
import '../utils/ShImages.dart';


//ignore @immutable;
class slider extends StatefulWidget {
  static String? tag = '/slider';
  final List<MoreImage>? list;
  var product;
  int index;

  slider({this.list, this.product, required this.index});

  @override
  _sliderState createState() => _sliderState();
}

class _sliderState extends State<slider> with SingleTickerProviderStateMixin {
  int currentIndex = 0;
  SwiperController swiperController = SwiperController(); // SwiperController added

  @override
  void initState() {
    super.initState();
    currentIndex = widget.index;
    swiperController = SwiperController();
    swiperController.index= widget.index;// Initialize SwiperController
  }

  TabController? tabController;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        shadowColor: Colors.white,
        elevation: 0.0,
        leading: GestureDetector(
          onTap: () {
            Get.back();
          },
          child: const Icon(Icons.cancel, color: Colors.black),
        ),
      ),
      body: Column(

        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Container(
                 color: Colors.transparent,

                  height: MediaQuery.of(context).size.height * 0.6,
                  child: Swiper(
                    controller: swiperController, // Assign the controller to Swiper
                    itemHeight: MediaQuery.of(context).size.height * 0.6,
                    viewportFraction: 1,
                    onIndexChanged: (value) {
                      setState(() {
                        currentIndex = value;
                      });
                    },
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: getPadding(right: 8.0),
                        child: buildMediaContent(widget.list![index]),
                      );
                    },
                    indicatorLayout: PageIndicatorLayout.COLOR,
                    autoplayDelay: 3000,
                    itemCount: widget.list!.length,
                  ),
                ),
                Padding(
                  padding: getPadding(bottom: 25.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(15.0),

                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(top: 3.0,bottom: 3,right: 8,left: 8),
                      child: Text(
                        '${currentIndex + 1} / ${widget.list!.length}',
                        style:  TextStyle(fontWeight: FontWeight.bold,color: Colors.white,fontSize: getFontSize(12)),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 30),
                  child: GridView.builder(
                    shrinkWrap: true,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisSpacing: 0,
                      mainAxisSpacing: 0,
                      crossAxisCount: 4,
                    ),
                    itemCount: widget.list!.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            currentIndex = index;
                            swiperController.move(index); // Update the Swiper index
                          });
                        },
                        child: buildThumbnail(widget.list![index], index),
                      );
                    },
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget buildMediaContent( MoreImage item) {
    if (isVideo(item.file_path)) {
      return
        CustomVideoPlayer(
        videoUrl: item.file_path,
        isAutoPlay: true,
        isMuted: false,
        imageUrl: "https://schooltube.online/schooltube/web/img/default.png",
      );
    } else {
      return PhotoView(
        
        backgroundDecoration: const BoxDecoration(color: Colors.transparent),
        loadingBuilder: (context, event) {
          return Stack(
            alignment: Alignment.center,
            children: [
              Image.asset(AssetPaths.placeholder),
              Ui.circularIndicator(color: MainColor)
            ],
          );
        },
        imageProvider: CachedNetworkImageProvider(item.file_path,),
      );
    }
  }

  Widget buildThumbnail( MoreImage item, int index) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
          border: Border.all(
            width: 1,
            color: currentIndex == index ? MainColor : Colors.grey[200]!,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10.0),
          child: isVideo(item.file_path)
              ? videoThumb(item)
              : CachedNetworkImage(

            imageUrl: item.file_path,
            placeholder: (context, url) => Image.network(
              convertToThumbnailUrl(item.file_path,isBlurred: true),
              fit: BoxFit.cover,
            ),
            errorWidget: (context, url, error) => Image.asset(AssetPaths.placeholder),
          )
        ),
      ),
    );
  }

  videoThumb( MoreImage video) async {
    Uint8List? thumbnailData = await VideoThumbnail.thumbnailData(
      video: video.file_path,
      imageFormat: ImageFormat.JPEG,
      maxHeight: 128,
      maxWidth: 128,
      timeMs: 0,
    );
    if (thumbnailData == null) {
      return Container();
    }

    return Container(
      width: 128,
      height: 128,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: MemoryImage(thumbnailData),
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
