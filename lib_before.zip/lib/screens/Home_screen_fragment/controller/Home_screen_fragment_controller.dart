import 'package:flutter/foundation.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:iq_mall/main.dart';
import 'package:iq_mall/models/HomeData.dart';
import 'package:iq_mall/screens/Address_manager_screen/controller/Address_manager_controller.dart';
import 'package:iq_mall/widgets/CommonFunctions.dart';
import 'package:iq_mall/models/online_adds.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../models/Address.dart';
import '../widgets/NewsLetter.dart';

// Rx<HomeData> globalController.homeDataList = HomeData().obs;

class Home_screen_fragmentController extends GetxController {
  RxBool load = true.obs;
  RxBool loading = true.obs;
  RxBool errorOccurred = false.obs;
  RxBool Expandedlist = false.obs;
  int limit = 5;
  int offset = 0;
  int page = 1;
  ScrollController ScrollListenerHOME = new ScrollController();
  RxBool loadingMore = false.obs;

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    LoadingDrawer.value = false;
    GetHomeData();
    Future.delayed(const Duration(seconds: 15), () {
      if (news?.show_hide == 1 && prefs!.getString('seen').toString() != 'true') {
        prefs?.setString('seen', 'true');
        showNewsLetterDetails(Get.context!, news!);
      }
    });

    ScrollListenerHOME.addListener(() async {
      if (ScrollListenerHOME.position.pixels > (ScrollListenerHOME.position.maxScrollExtent-450) && !loadingMore.value ) {
        getProductSections();
      }
    });

    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  Future<bool> GetHomeData() async {
    bool success = false;
    errorOccurred.value = false;

    // Get.lazyPut(() => Address_managerController());
    // var controller = Get.find<Address_managerController>();
    // controller.GetAddresses();
    try {
      Map<String, dynamic> response = await api.getData({
        'token': prefs!.getString("token") ?? "",
        'store_id': prefs!.getString("id") ?? "",
      }, "stores/home-store-data");

      if (response.isNotEmpty) {
        success = response["succeeded"];
        loading.value = true;
        await globalController.refreshHomeScreen(false, response: response);

        // globalController.homeDataList = (HomeData.fromJson(response)).obs;
        onlineaddslist.clear();

        loading.value = false;
      }
      if (success) {

      }
      else {

      }
      Map<String, dynamic> addressesResponse = await api.getData({
        'token': prefs!.getString("token") ?? "",
      }, "addresses/get-addresses");

      if (addressesResponse.isNotEmpty) {
        success = addressesResponse["succeeded"];
        if (success) {
          List productsInfo = addressesResponse["addresses"];
          addresseslist.clear();
          for (int i = 0; i < productsInfo.length; i++) {
            addressesclass.fromJson(productsInfo[i]);
          }
        }
        loading.value = false;
        return success;
      }
    } catch (e) {
      errorOccurred.value = true;
      loading.value = false;
      load.value = false;
    }
    loading.value = false;
    load.value = false;
    return success;
  }

  Future<bool> getProductSections() async {
    bool success = false;
    page++;
    loadingMore.value=true;
    // globalController.loadMoreSections(true);
    // await Future.delayed(const Duration(milliseconds: 50)).then((value) {
    //   ScrollListenerHOME.animateTo(
    //     ScrollListenerHOME.position.maxScrollExtent,
    //     duration: Duration(milliseconds: 300),
    //     curve: Curves.easeInOut,
    //   );
    // });

    try {
       api.getData({
        'token': prefs!.getString("token") ?? "",
        'store_id': prefs!.getString("id") ?? "",
        'page': page,
      }, "stores/get-products-sections").then((response) {
        if (response.isNotEmpty) {
          success = response["succeeded"];
          loadingMore.value=false;

          globalController.loadMoreSections(false, response: response);
        } else {
          page--;
          // globalController.loadMoreSections(false);
          loadingMore.value=false;

        }
      });
    } catch (e) {
      page--;
      // globalController.loadMoreSections(false);
      loadingMore.value=false;

      if (kDebugMode) {
        print(e);
      }
    }
    return success;
  }

  // Future<String> getCountryDialCode() async {
  //   // Get current location
  //   Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  //
  //   // Get country code from location
  //   List<Placemark> placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);
  //   String? countryCode = placemarks[0].isoCountryCode;
  //
  //   // Get dial code for country
  //  // RegionInfo regionInfo = await PhoneNumberUtil.getRegionInfo(regionCode: countryCode);
  //  // String dialCode = regionInfo.dialCode;
  //
  //   return dialCode;
  // }

  Future<void> refreshFunctions() async {
    try {
      globalController.refreshHomeScreen(true);
      await GetHomeData();
      await Get.context!.read<Counter>().unreadednotification();
      await seen2();
      globalController.refreshHomeScreen(false);
    } catch (ex) {
      // Handle the exception
      print('An error occurred: $ex');
    }
  }
}
