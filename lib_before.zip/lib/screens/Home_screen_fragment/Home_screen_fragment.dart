import 'package:flutter/material.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/screens/FlashSales_screen/FlashSales_screen.dart';
import 'package:iq_mall/screens/Home_screen_fragment/widgets/BrandsScreen.dart';
import 'package:iq_mall/screens/Home_screen_fragment/widgets/CategoriesWidget.dart';
import 'package:iq_mall/screens/Home_screen_fragment/widgets/Specialitems.dart';
import 'package:iq_mall/screens/Home_screen_fragment/widgets/TopStores.dart';
import 'package:get/get.dart';
import 'package:iq_mall/widgets/CommonWidget.dart';
import 'package:iq_mall/widgets/ui.dart';
import '../../utils/ShColors.dart';
import '../../cores/language_model.dart';
import '../../getxController.dart';
import '../../main.dart';
import '../../utils/ShImages.dart';
import '../../widgets/CommonFunctions.dart';
import '../../widgets/Grid_Widget.dart';
import '../HomeScreenPage/ShHomeScreen.dart';
import '../tabs_screen/controller/tabs_controller.dart';
import 'controller/Home_screen_fragment_controller.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
// ignore_for_file: must_be_immutable

class Home_screen_fragmentscreen extends StatelessWidget {
  Home_screen_fragmentController controller = Get.put(Home_screen_fragmentController());

  Home_screen_fragmentscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: missing_return
      onWillPop: () {
        TabsController _controller = Get.find();

        if (_controller.currentIndex.value != 0) {
          _controller.currentIndex.value = 0;
        }
        return Future.value(true);
      },
      child: Scaffold(
          body: GestureDetector(
            onTap: () {
              if (sideMenuKey.currentState?.isOpened ?? false) {
                state?.closeSideMenu();
              }
            },
            child: Obx(() =>
            controller.errorOccurred.value ?
            Center(child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Image.asset(AssetPaths.noresultsfound),
            )) :
            controller.loading.value
                ? Center(child: Progressor_indecator())
                : RefreshIndicator(
                color: MainColor,

                onRefresh: controller.refreshFunctions,
                child:

                CustomScrollView(
                  controller: controller.ScrollListenerHOME,
                  shrinkWrap: true,

                  slivers: <Widget>[
                    SliverPadding(
                      padding: EdgeInsets.only(top: getSize(50) + getTopPadding()),

                      sliver: SliverToBoxAdapter(
                        child: Obx(() {
                          return BannerWidget(
                            gridElements: globalController.homeDataList.value.gridElements ?? [],
                          );
                        }),
                      ),
                    ),
                    const SliverPadding(
                      padding: EdgeInsets.only(top: 16.0),
                      sliver: SliverToBoxAdapter(
                        child: CategoriesWidget(),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: SizedBox(),
                    ),

                    SliverToBoxAdapter(
                        child:

                        SpecialList(
                          loading: controller.loading,
                        )
                      // Obx(() {
                      //   return
                      //
                      //     Padding(
                      //     padding:  EdgeInsets.only(bottom:  globalController.loadingMore.value ?0:getSize(45) + getBottomPadding()),
                      //     child: SpecialList(
                      //       loading: controller.loading,
                      //     ),
                      //   );
                      // }),
                    ),

                    SliverToBoxAdapter(

                      child: Obx(
                            () =>
                        controller.loadingMore.value ?
                        Container(
                            padding: getPadding(top: 10),
                            height: getSize(90) + getBottomPadding(), child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Ui.circularIndicator(color: ColorConstant.logoFirstColor),
                          ],
                        )) : const SizedBox(),
                      ),
                    ),
                    // Add your other widgets as SliverToBoxAdapter or SliverList
                    // based on their content (static or dynamic)
                  ],
                )


              // ListView(
              //         controller: controller.ScrollListenerHOME,
              //         shrinkWrap: true,
              //         physics: AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
              //         children: [
              //           SingleChildScrollView(
              //             child: Column(
              //               crossAxisAlignment: CrossAxisAlignment.center,
              //               children: <Widget>[
              //                 if (globalController.homeDataList.value.gridElements != null) BannerWidget(gridElements: globalController.homeDataList.value.gridElements!),
              //                 const Padding(
              //                   padding: EdgeInsets.only(top: 16.0),
              //                   child: CategoriesWidget(),
              //                 ),
              //                 Padding(
              //                   padding: getPadding(top: 8.0),
              //                   child: FlashSalesscreen(),
              //                 ),
              //                 SpecialList(),
              //                 Obx(
              //                   () =>
              //                   globalController.loadingMore.value?
              //                   SizedBox(height: getSize(55), child: Ui.circularIndicator(color: MainColor)):SizedBox(),
              //                 )
              //                 // const BrandsWidget(),
              //                 // TopStores(),
              //               ],
              //             ),
              //           ),
              //         ],
              //       )

            )),
          )),
    );
  }
}

// class LanguageController extends GetxController {
//   var selectedLanguage = (languages.isNotEmpty) ? languages[0].obs : Language().obs;
//
//   void changeLanguage(Language newLang) {
//     selectedLanguage.value = newLang;
//     update();
//     // Here you can call OnLanguageChanged function to perform any action when language is changed.
//     // OnLanguageChanged(newLang.shortcut);
//   }
// }
