import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:provider/provider.dart';

import '../../../models/HomeData.dart';
import '../../../widgets/custom_button.dart';
import '../../Home_screen_fragment/controller/Home_screen_fragment_controller.dart';
import '../controller/Filter_Products_controller.dart';
import 'SelectedItems.dart';

// This is just a basic scaffold. You'll need to implement state management, HTTP requests, etc.

class FilterMenu extends StatefulWidget {
  final Filter_ProductsController controller;

  const FilterMenu({super.key, required this.controller});

  @override
  _FilterMenuState createState() => _FilterMenuState();
}

class _FilterMenuState extends State<FilterMenu> {
  int? selectedCategoryIds;
  int? selectedBrandIds;
  RxString tempCategory = ''.obs;
  var f;
  RxList<Category> categories = <Category>[].obs;
  RxList<Brand> brands = <Brand>[].obs;
  Rx<Category> selectedCategory = Category(id: 0, categoryName: "categoryName", slug: "slug", parent: 0, main_image: "main_image", showInNavbar: 0, productCount: 0, isSelected: false).obs;
  var unescape = HtmlUnescape();

  @override
  void initState() {

    widget.controller.categories.forEach((cat) {
      if (cat.id == widget.controller.selectedCategory?.value.id) {
        cat.isSelected = true; // Deselect all categories
      } else {
        cat.isSelected = false; // Deselect all categories
      }
    });
    if (widget.controller.selectedCategory != null) {
      selectedCategory.value = widget.controller.selectedCategory!.value;
    }
    super.initState();

    fetchData(); // You'll need to implement this
  }

  void fetchData() {
    print(widget.controller.categories[0].categoryName);

    // TODO: Fetch data here
  }

  @override
  void dispose() {
    widget.controller.categories.forEach((cat) {
      if (cat.id == widget.controller.selectedCategory?.value.id) {
        cat.isSelected = true; // Deselect all categories
      } else {
        cat.isSelected = false; // Deselect all categories
      }
    });

    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding:  EdgeInsets.only(top: getTopPadding(), left: 18, right: 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Filter'.tr,
                style: TextStyle(fontSize: getFontSize(25),color: Colors.black),
              ),
              TextButton(
                  onPressed: () {
                    widget.controller.categories.forEach((category) {
                      category.isSelected = false;
                    });
                    widget.controller.categories.refresh();
                    widget.controller.brands.forEach((brand) {
                      brand.isSelected = false;
                    });
                    widget.controller.brands.refresh();
                  },
                  child: Obx(() => MyCustomButton(
                        height: 40,
                        text: "Save".tr,
                        fontSize: getFontSize(20),
                        circularIndicatorColor: Colors.white,
                        buttonColor: ColorConstant.logoSecondColor,
                        borderColor: Colors.transparent,
                        width: getSize(80),
                        isExpanded: widget.controller.loader.value,
                        onTap: () {
                          widget.controller.selectedCategoryIds = selectedCategoryIds;
                          widget.controller.category.value = tempCategory.value;
                          widget.controller.selectedCategory = selectedCategory.value.obs;
                          widget.controller.loading.value = true;
                          widget.controller.Products?.clear();
                          f = {
                            "categories": [
                              widget.controller.selectedCategoryIds.toString(),
                            ],
                            "Brands": [
                              widget.controller.selectedBrandIds.toString(),
                            ],
                          };
                          if (selectedCategory != null) {
                            widget.controller.selectedCategory?.value = selectedCategory!.value;
                          }
                          widget.controller.title.value= widget.controller.selectedCategory!.value.categoryName;
                          widget.controller.type = jsonEncode(f);
                          widget.controller.loader.value = true;
                          widget.controller.getProducts(widget.controller.page.value).then((value) => Get.back());
                        },
                      ))), // Implement handleClearAll
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5, bottom: 5),
          child: SizedBox(height: getSize(30), child: SelectedItemsWidget(categories: widget.controller.categories, brands: widget.controller.brands, controller: widget.controller)),
        ),
        const Divider(),
        Expanded(
          child: Obx(() => ListView(
                shrinkWrap: true,
                physics: AlwaysScrollableScrollPhysics(),
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 14.0),
                    child: Text(
                      'Category'.tr,
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
                  ...widget.controller.categories.map((category) {
                    return InkWell(onTap: () {
                      // If this category is being selected
                      widget.controller.categories.forEach((cat) {
                        cat.isSelected = false; // Deselect all categories
                      });
                      setState(() {
                        category.isSelected = true;
                      }); // Select this specific category
                      selectedCategory.value = category;
                      selectedCategoryIds = category.id;
                      tempCategory.value = category.id.toString();
                    }, child: Obx(() {
                      return Container(
                        padding: const EdgeInsets.all(8), // Add padding around the text
                        decoration: BoxDecoration(
                          color: selectedCategory.value.id == category.id ? ColorConstant.logoSecondColor : Colors.transparent, // Change the color based on selection
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            unescape.convert(category.categoryName),
                            style: TextStyle(color: selectedCategory.value.id == category.id ? Colors.white : Colors.black), // Change text color based on selection
                          ),
                        ),
                      );
                    }));

                    // CheckboxListTile(
                    //   dense: true,
                    //   title: Text(category.categoryName),
                    //   value: category.isSelected,
                    //   onChanged: (bool? value) {
                    //     if (value == true) {
                    //       // If this category is being selected
                    //       widget.controller.categories.forEach((cat) {
                    //         cat.isSelected = false; // Deselect all categories
                    //       });
                    //       category.isSelected = true; // Select this specific category
                    //     } else {
                    //       category.isSelected = false; // If this category is being deselected, just update its value
                    //     }
                    //     widget.controller.loading.value = true;
                    //     widget.controller.Products?.clear();
                    //     widget.controller.selectedCategoryIds = category.id;
                    //     widget.controller.category.value = category.id.toString();
                    //     var f = {
                    //       "categories": [
                    //         widget.controller.selectedCategoryIds.toString(),
                    //       ],
                    //       "Brands": [
                    //         widget.controller.selectedBrandIds.toString(),
                    //       ],
                    //     };
                    //     widget.controller.type = jsonEncode(f);
                    //   },
                    // );
                  }),
                  const Divider(),
                  Padding(
                    padding: EdgeInsets.only(left: 14.0),
                    child: Text(
                      'Brands'.tr,
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
                  ...widget.controller.brands.map((brand) {
                    return CheckboxListTile(
                      title: Text(brand.brandName),
                      value: brand.isSelected,
                      onChanged: (bool? value) {
                        if (value == true) {
                          widget.controller.brands.forEach((bran) {
                            bran.isSelected = false;
                          });
                          brand.isSelected = true;
                        } else {
                          brand.isSelected = false;
                        }

                        widget.controller.loading.value = true;
                        widget.controller.Products?.clear();
                        widget.controller.selectedBrandIds = brand.id;
                        var f = {
                          "categories": [
                            widget.controller.selectedCategoryIds.toString(),
                          ],
                          "Brands": [
                            widget.controller.selectedBrandIds.toString(),
                          ],
                        };
                        widget.controller.type = jsonEncode(f);
                        widget.controller.page.value = 1;
                        widget.controller.getProducts(widget.controller.page.value);
                      },
                    );
                  }),
                  Container(
                    height: 30,
                  )
                ],
              )),
        ),
      ],
    );
  }
}
