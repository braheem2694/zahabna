import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:get/get.dart';
import 'package:iq_mall/screens/ProductDetails_screen/ProductDetails_screen.dart';
import 'package:package_info/package_info.dart';
import 'package:persistent_bottom_nav_bar/persistent_tab_view.dart';
import 'package:uuid/uuid.dart';

import '../../../main.dart';
import '../../../models/CurrencyEx.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/ShColors.dart';
import '../../Cart_List_screen/Cart_List_screen.dart';
import '../../Cart_List_screen/controller/Cart_List_controller.dart';
import '../../HomeScreenPage/ShHomeScreen.dart';
import '../../Home_screen_fragment/Home_screen_fragment.dart';
import '../../Home_screen_fragment/controller/Home_screen_fragment_controller.dart';
import '../../Stores_screen/Stores_screen.dart';
import '../../Stores_screen/controller/my_store_controller.dart';
import '../../Stores_screen/widgets/item_widget.dart';
import '../../Wishlist_screen/controller/Wishlist_controller.dart';
import '../../Wishlist_screen/wish_list_screen.dart';
import '../../categories_screen/categories_screen.dart';
import '../binding/tabs_binding.dart';

String uuidForCartList = "";

class TabsController extends GetxController {
  RxInt currentIndex = 0.obs;
  RxInt countHomeClicks = 0.obs;
  RxInt countMyLearningClicks = 0.obs;
  RxInt countAllGradesClicks = 0.obs;
  int connectionRetryCount = 0;
  int maxRetryAttempts = 5;
  late PageController pageController;
  RxBool colorful = true.obs;

  void onButtonPressed(int index) {
    currentIndex.value = index;
  }

  final iconList = <IconData>[
    Icons.brightness_5,
    Icons.brightness_4,
    Icons.brightness_6,
    Icons.brightness_7,
  ];

  late RxList<Map<String, Object?>>? downloadListFinal = <Map<String, Object?>>[].obs;
  RxList<Widget> pages = <Widget>[].obs;
  RxBool load = false.obs;
  String? version = '';
  bool balanceloading = true;
  int drawercount = 10;
  var subscription;
  List cartInfo = [];

  // late final PersistentTabController _controller = PersistentTabController(initialIndex: 0);

  @override
  void onInit() async {
    uuidForCartList = uuid.v4().toString();

    if (prefs?.getString("is_store") != "1") {
      pages.value = [
        Home_screen_fragmentscreen(),
        CategoriesScreen(),
        AddNewItemScreen(),
        Wishlistscreen(),
        Storesscreen(),
        // Cart_Listscreen(),
      ];
    } else {
      pages.value = [
        Home_screen_fragmentscreen(),
        CategoriesScreen(),
        Wishlistscreen(),
        Storesscreen(),
        // Cart_Listscreen(),
      ];
    }

    super.onInit();
  }

  getsettings() async {
    PackageInfo.fromPlatform().then((PackageInfo packageInfo) {
      version = packageInfo.version;
    });
  }

  InitStateFucntion() {
    currentIndex.value = mainCurrentIndex.value;
    mainCurrentIndex.value = 0;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      LoadingDrawer.value = false;
    });
    changeColorsAndDisplay(prefs!.getString('button_color').toString(), prefs!.getString('main_color').toString(), prefs!.getString('discount_price_color').toString());
    load.value = true;
    // Future.delayed(Duration.zero, () {
    //   Get.to(() => ShHomeScreen(), routeName: '/ShHomeScreen');
    // });
    getsettings();

    if (prefs?.getString('currency').toString() == 'null') {
      prefs?.setString('currency', 'Lebanese Lira');
      prefs?.setString('idselected', country_currency_id!);
      idselected = int.parse(prefs?.getString('idselected') ?? "");
      prefs?.setString('sign', sign.value.toString() ?? "");
      for (int i = 0; i < currencyExlist.length; i++) {
        if (currencyExlist[i].from_currency == country_currency_id && currencyExlist[i].to_currency == idselected.toString()) {
          prefs?.setString('currency_rate', currencyExlist[i].Rate);
        }
      }
    } else {
      idselected = int.parse(prefs?.getString('idselected') ?? "");
      prefs?.setString('sign', sign.value.toString() ?? "");
      Future.delayed(Duration.zero, () {});
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.context!.read<Counter>().unreadednotification();
      LoadingDrawer.value = false;
    });
    Future.delayed(Duration.zero, () async {
      drawerSize.value = Get.size.height - 200;
      // globalController.selectedTab.value = 0;
    });
  }

  OnBottomNavTapPress(index) {
    if (currentIndex.value != index) {
      currentIndex.value = index;
    } else {
      if (currentIndex.value == 2) {
        WishlistController _controller = Get.find();
        Gototop(_controller.ScrollListenerFAVORITE.value);
      } else if (currentIndex.value == 0) {
        Home_screen_fragmentController _controller = Get.find();

        Gototop(_controller.ScrollListenerHOME);
      } else if (currentIndex.value == 1) {
        WishlistController _controller = Get.find();
        Gototop(_controller.ScrollListenerFAVORITE.value);
      } else if (currentIndex.value == 3) {
        // MyStoreController _controller = Get.find();
        //
        // Gototop(_controller.ScrollListenerCART);
      }
    }
  }

  @override
  void onReady() async {
    InitStateFucntion();
    LoadingDrawer.value = false;

    super.onReady();
    globalController.updateCurrentRout(Get.currentRoute);
  }

  Gototop(ScrollController s) {
    try {
      if (s.hasClients) {
        s.animateTo(
          s.position.minScrollExtent,
          duration: const Duration(milliseconds: 750),
          curve: Curves.fastLinearToSlowEaseIn,
        );
      }
    } catch (ex) {}
  }

  // void showRestartAppAlert(BuildContext context) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: Text("Connection Error"),
  //         content: Text("Failed to establish a connection to the server."),
  //         actions: [
  //           TextButton(
  //             onPressed: () {
  //               exit(0); // Close the alert
  //               // You can add any additional actions here if needed
  //             },
  //             child: Text("OK"),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  Widget get currentPage => pages[currentIndex.value];

  /// change page in route

  Future<int> changePageInRoot(int _index) async {
    int index = _index;
    // isTab="tab";
    currentIndex.value = _index;
    return index;
  }

  void changePageOutRoot(int _index) {
    currentIndex.value = _index;
    Get.offNamedUntil("/tab", (Route route) {
      if (route.settings.name == "/tab") {
        return true;
      }
      return false;
    }, arguments: _index);
  }

  void changePage(int _index) {
    TabsBinding().dependencies();

    if (Get.currentRoute == "/tab") {
      changePageInRoot(_index);
    } else {
      changePageOutRoot(_index);
    }
  }
}
