import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:get/get.dart';
import 'package:iq_mall/main.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:iq_mall/screens/ProductDetails_screen/controller/ProductDetails_screen_controller.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    var controller = Get.find<ProductDetails_screenController>();
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.white,
      leading: GestureDetector(
        onTap: () {
          Get.back();
        },
        child: const Icon(
          Icons.arrow_back,
          color: Colors.black,
        ),
      ),
      title:  Text(
        'Product Details'.tr,
        style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
      ),
      actions: [
        IconButton(
          icon: const Icon(
            Icons.share,
            color: Colors.black,
          ),
          onPressed: () async {
            await FlutterShare.share(
              title: prefs!.getString('store_name').toString(),
              text:
                  'Amazing ${controller.product!.value?.product_name}https://play.google.com/store/apps/details?id=com.jewelry.app  or The website on https://www.brainkets.com/panama_website/web/',
              linkUrl: 'https://play.google.com/store/apps/details?id=com.jewelry.app',
              chooserTitle: prefs!.getString('store_name').toString(),
            );
          },
        ),
      ],
    );
  }
}
