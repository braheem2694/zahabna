import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:iq_mall/screens/Stores_screen/widgets/my_store_widget.dart';
import 'package:iq_mall/widgets/custom_image_view.dart';
import 'package:iq_mall/widgets/ui.dart';
import 'package:photo_view/photo_view.dart';

import '../../cores/math_utils.dart';
import '../../main.dart';
import '../../models/Stores.dart';
import '../../utils/ShColors.dart';
import '../../utils/ShImages.dart';
import '../../widgets/ShWidget.dart';
import '../../widgets/image_widget.dart';
import 'controller/Stores_screen_controller.dart';
import 'widgets/item_widget.dart';

class Storesscreen extends StatelessWidget {

  StoreController controller = Get.put(StoreController());


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFf5f5f5),
      body: Obx(
        () => controller.loading.value
            ? const Center(child: CircularProgressIndicator())
            : Stack(
                children: [
                  // IgnorePointer(
                  //   ignoring: true,
                  //   child: Container(
                  //    color: Colors.grey[100],
                  //     height: Get.height,
                  //     width: Get.width,
                  //   ),
                  // ),


                  SingleChildScrollView(
                    padding:  EdgeInsets.only(top: getSize(50)+ getTopPadding(),bottom: getBottomPadding()+getSize(45)),

                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // SizedBox(
                        //   width: getSize(100),
                        //   height: getSize(100),
                        //   child: CustomImageView(
                        //     url: prefs!.getString('gif_image') ?? "",
                        //   ),
                        // ),
                        Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // Text(
                              //   prefs!.getString('welcome_text')!,
                              //   style: const TextStyle(
                              //     color: Color(0xffE8A78A),
                              //     fontSize: 25,
                              //   ),
                              // ),
                              const SizedBox(height: 10),
                              Text(
                                // prefs!.getString('store_name')?.toUpperCase() ?? 'Zalzali',
                                "All Stores".tr,
                                style: const TextStyle(
                                  color: Color(0xff494C57),
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 10),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 12.0, right: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              GetBuilder<StoreController>(
                                builder: (controller2) {
                                  final stores = storeList;
                                  return GridView.builder(
                                    padding: EdgeInsets.zero,
                                    physics: const NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                                        mainAxisExtent: getVerticalSize(270.00),
                                        crossAxisCount: 2,
                                        mainAxisSpacing: getHorizontalSize(7.50),
                                        crossAxisSpacing: getHorizontalSize(7.50)),
                                    // Adjust this ratio if needed
                                    itemCount: stores.length,
                                    itemBuilder: (context, index) {
                                      final store = stores[index];
                                      final storeName = store.store_name;
                                      final mainImage = store.main_image;
                                      final storeImage = store.store_image;



                                      return GestureDetector(
                                        onTap: () {
                                          // Ui.flutterToast("Coming soon :)".tr, Toast.LENGTH_LONG, MainColor, whiteA700);

                                          // Get.to(()=>MyStore());

                                          prefs?.setString("id", store.id.toString());
                                          Get.offAllNamed(AppRoutes.tabsRoute);


                                          // Get.toNamed(AppRoutes.myStore,arguments: {"store":store});

                                          // controller.ChangeStroredStore(store, 'a');
                                          // Handle onTap event
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(8.0),
                                            border: Border.all(color: Colors.grey[200]!),
                                            color: Colors.white,
                                            boxShadow: [
                                              BoxShadow(
                                                color: ColorConstant.black900.withOpacity(0.15),
                                                blurRadius: 4.0,
                                                spreadRadius: 0.0,
                                                offset: const Offset(0, 3.0),
                                              ),
                                            ],
                                          ),
                                          width: getHorizontalSize(175),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    begin: Alignment.bottomLeft,
                                                    end: Alignment.bottomRight,
                                                    colors: [
                                                      ColorConstant.logoSecondColor.withOpacity(0.4),
                                                      ColorConstant.logoSecondColor.withOpacity(0.6),
                                                      ColorConstant.logoSecondColor.withOpacity(0.9),
                                                    ],
                                                  ),
                                                  borderRadius: const BorderRadius.only(
                                                    topLeft: Radius.circular(7),
                                                    topRight: Radius.circular(7),
                                                  ),
                                                ),
                                                child: Center(
                                                  child: Padding(
                                                    padding: const EdgeInsets.symmetric(vertical: 3),
                                                    child: Text(
                                                      storeName ?? 'No Name',
                                                      style:  TextStyle(color: ColorConstant.logoFirstColor.withOpacity(0.7),fontWeight: FontWeight.w700,fontSize: getFontSize(18)),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Spacer(),

                                              CustomImageView(
                                                svgUrl: mainImage!.toLowerCase().endsWith('svg')?mainImage:null,
                                                url: mainImage,
                                                image: mainImage,
                                                placeHolder: AssetPaths.iqMallBackgroundPng,
                                                height: getSize(130),
                                                width: getHorizontalSize(175),
                                                fit: BoxFit.cover,
                                              ),
                                              Spacer(),
                                              Container(
                                                width: getHorizontalSize(190),
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    begin: Alignment.bottomLeft,
                                                    end: Alignment.bottomRight,
                                                    colors: [
                                                      ColorConstant.logoSecondColor.withOpacity(0.4),
                                                      ColorConstant.logoSecondColor.withOpacity(0.6),
                                                      ColorConstant.logoSecondColor.withOpacity(0.9),
                                                    ],
                                                  ),
                                                    borderRadius: const BorderRadius.only(
                                                    bottomRight: Radius.circular(7),
                                                    bottomLeft: Radius.circular(7),
                                                  ),
                                                ),

                                                padding: getPadding(top: 8,left: 10,right: 10,bottom: 8),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Padding(
                                                      padding: const EdgeInsets.symmetric(vertical: 3),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: fromHex('#996c22'),
                                                          borderRadius: BorderRadius.circular(5)

                                                        ),
                                                        width: getHorizontalSize(140),
                                                        alignment: Alignment.center,
                                                        padding: getPadding(top: 8,left: 15,right: 15,bottom: 8),
                                                        child:  Text(
                                                          "Shop",
                                                          style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600,fontSize: getFontSize(16)),

                                                        ),
                                                      ),

                                                    ),
                                                    GestureDetector(
                                                      onTap: () {
                                                        Get.toNamed(AppRoutes.soreDetails,arguments: {"store":store});
                                                      },
                                                      child: Padding(
                                                        padding: const EdgeInsets.symmetric(vertical: 3),

                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                              color: ColorConstant.logoFirstColor.withOpacity(0.5),
                                                              borderRadius: BorderRadius.circular(5)

                                                          ),
                                                          width: getHorizontalSize(140),
                                                          alignment: Alignment.center,
                                                          padding: getPadding(top: 8,left: 15,right: 15,bottom: 8),

                                                          child:  Text(
                                                            "Info",
                                                            style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600,fontSize: getFontSize(16)),
                                                          ),
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ),

                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: getPadding(top: 50.0, left: 16),
                    child: Ui.backArrowIcon(),
                  )
                ],
              ),
      ),
    );
  }
}
