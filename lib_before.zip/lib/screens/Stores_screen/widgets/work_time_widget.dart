import 'package:cached_network_image/cached_network_image.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:iq_mall/models/category.dart';
import 'package:iq_mall/utils/ShImages.dart';
import 'package:iq_mall/widgets/custom_image_view.dart';
import '../../../cores/math_utils.dart';
import '../../../main.dart';
import 'package:flutter/material.dart';

import '../../../utils/ShColors.dart';
import '../../Stores_details/controller/store_detail_controller.dart';

// ignore: must_be_immutable
class storeWorkTime extends StatelessWidget {
  final WorkDay? model;

  var controller = Get.find<StoreDetailController>();

   storeWorkTime({super.key, this.model});


  @override
  Widget build(BuildContext context) {
    return Container(
      width: getHorizontalSize(
        90.00,
      ),

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: ColorConstant.logoFirstColor,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
           ColorConstant.logoFirstColor,
            ColorConstant.logoFirstColor.withOpacity(0.9),
            ColorConstant.logoFirstColor.withOpacity(0.8),
            ColorConstant.logoFirstColor.withOpacity(0.7),

          ],
        ),

      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          Center(
            child: Padding(
              padding: getPadding(left: 4,right: 4),

              child: Text(model?.name??"",
                maxLines: 3,
                textDirection: TextDirection.rtl,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: getFontSize(14),color: Colors.white),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: getPadding(left: 4,right: 4),

              child: Text(model?.startingTime??"",
                maxLines: 3,
                textDirection: TextDirection.rtl,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: getFontSize(14),color: Colors.white),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: getPadding(left: 4,right: 4),

              child: Text(model?.startingTime??"",
                maxLines: 3,
                textDirection: TextDirection.rtl,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: getFontSize(14),color: Colors.white),
              ),
            ),
          )


          // Text(model.title??"",
          //   maxLines: 2,
          // )

        ],
      ),
    );
  }
}
