import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:html_editor_enhanced/html_editor.dart';
import 'package:image_picker/image_picker.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/main.dart';
import 'dart:io';

import 'package:iq_mall/utils/ShColors.dart';

import '../../../models/HomeData.dart';
import '../../../widgets/html_widget.dart';

class AddNewItemScreen extends StatefulWidget {

  final String? fromKey;
  final Product? product;

  const AddNewItemScreen({super.key, this.fromKey, this.product});


  @override
  _AddNewItemScreenState createState() => _AddNewItemScreenState();
}

class _AddNewItemScreenState extends State<AddNewItemScreen> {
  final _formKey = GlobalKey<FormState>();

  // Define controllers for text fields
  final TextEditingController productNameController = TextEditingController();
  final TextEditingController productPriceController = TextEditingController();
  final TextEditingController priceAfterDiscountController = TextEditingController();
  final TextEditingController productCodeController = TextEditingController();
  final TextEditingController openingQtyController = TextEditingController();
  final TextEditingController vatController = TextEditingController();
  final TextEditingController productWeightController = TextEditingController();
  final TextEditingController salesDiscountController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  final TextEditingController optionsController = TextEditingController();
  final TextEditingController variationFoundController = TextEditingController();
  final TextEditingController variantIdController = TextEditingController();
  final Rx<HtmlEditorController> descriptionController = HtmlEditorController().obs;

  File? mainImage;
  List<File> moreImages = [];

  final ImagePicker _picker = ImagePicker();

  Future<void> _pickMainImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        mainImage = File(pickedFile.path);
      });
    }
  }

  Future<void> _changeMainImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        mainImage = File(pickedFile.path);
      });
    }
  }


  Future<void> _removeMainImage() async {
    setState(() {
      mainImage = null;
    });
  }

  Future<void> _pickMoreImages() async {
    final pickedFiles = await _picker.pickMultiImage();

    if (pickedFiles != null) {
      setState(() {
        moreImages.addAll(pickedFiles.map((pickedFile) => File(pickedFile.path)).toList());
      });
    }
  }

  void _removeImage(int index) {
    setState(() {
      moreImages.removeAt(index);
    });
  }

  void _changeImage(int index) async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        moreImages[index] = File(pickedFile.path);
      });
    }
  }

  @override
  void initState() {

    if(widget.product!=null){
      Future.delayed(Duration(seconds: 1)).then((value) {
        descriptionController.value.insertHtml( widget.product!.description!.trimLeft()??'');

      });

    }
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar:
        !globalController.isNav.value ?
        AppBar(
          title: const Text('Add New Item'),
          elevation: 1,
          backgroundColor: Colors.white,
          shadowColor: Colors.transparent,
          leading: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: () => Get.back(),
              child: Icon(Icons.arrow_back_ios, color: Colors.black,)),
        ) : null,

        body: Padding(
          padding: EdgeInsets.only(left: 16.0, right: 16),
          child: Form(
            key: _formKey,
            child: ListView(
              padding: getPadding(top: getTopPadding()+ getSize(50)),
              children: [
                _buildTextField(productNameController, 'Product Name', 'Enter product name', required: true,initialValue: widget.product?.product_name),

                HtmlEditor(
                  controller: descriptionController.value, //required
                  htmlEditorOptions: HtmlEditorOptions(
                      hint: "Description".tr,
                      inputType: HtmlInputType.text,
                      adjustHeightForKeyboard: true,
                      autoAdjustHeight: true,
                      androidUseHybridComposition: true,





                    //initalText: "text content initial, if any",
                  ),

                  otherOptions: OtherOptions(
                    height: getVerticalSize(200),
                  ),
                  htmlToolbarOptions: HtmlToolbarOptions(
                    toolbarItemHeight: getSize(25),
                    textStyle: TextStyle(color: ColorConstant.black900,),
                  ),
                ),
              // HtmlWidget( data:widget.product?.description.toString(),),
                SizedBox(height: 20),
                // _buildTextField(descriptionController, 'Description', 'Enter description', required: true,initialValue: widget.product?.description),
                _buildTextField(productPriceController, 'Product Price', 'Enter product price', inputType: TextInputType.number, required: true,initialValue: widget.product?.product_price.toString()),
                _buildTextField(priceAfterDiscountController, 'Price After Discount', 'Enter price after discount', inputType: TextInputType.number, required: false,initialValue: widget.product?.price_after_discount.toString()),
                _buildTextField(productCodeController, 'Product Code', 'Enter product code', required: false,initialValue: widget.product?.product_code),
                _buildTextField(openingQtyController, 'Opening Quantity', 'Enter opening quantity', inputType: TextInputType.number, required: false,initialValue: widget.product?.opening_qty.toString()),
                _buildTextField(vatController, 'VAT', 'Enter VAT', inputType: TextInputType.number, required: false,initialValue: widget.product?.vat.toString()),
                _buildTextField(productWeightController, 'Product Weight', 'Enter product weight', inputType: TextInputType.number, required: false,initialValue: widget.product?.product_weight.toString()),
                _buildTextField(salesDiscountController, 'Sales Discount', 'Enter sales discount', inputType: TextInputType.number, required: false,initialValue: widget.product?.sales_discount.toString()),
                _buildTextField(quantityController, 'Quantity', 'Enter quantity', required: false,initialValue: widget.product?.quantity),

                SizedBox(height: 20),
                _buildMainImageSection(),
                SizedBox(height: 20),
                _buildMoreImagesSection(),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      // Process the form data
                      // For example, save the new item to the database
                      ScaffoldMessenger.of(context)
                          .showSnackBar(SnackBar(content: Text('Processing Data')));
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ColorConstant.logoSecondColor,
                    padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    textStyle: TextStyle(fontSize: 18),
                  ),
                  child: Text('Submit', style: TextStyle(color: Colors.white)),
                ),
                SizedBox(height: 20),

              ],
            ),
          ),
        ),
      );
    });
  }

  Widget _buildTextField(TextEditingController controller, String label, String hint,
      {TextInputType inputType = TextInputType.text, bool required = true,String? initialValue}) {
    if(initialValue.toString()!="null"){
      controller.text=initialValue??'';

    }else{
      controller.text='';

    }
    return Padding(
      padding: EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          labelStyle: TextStyle(color: ColorConstant.gray500,),
          hintStyle: TextStyle(color: ColorConstant.gray500,),

          focusColor: ColorConstant.logoFirstColor,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30.0),
          ),
          filled: true,
          fillColor: ColorConstant.whiteA700,
        ),
        keyboardType: inputType,
        validator: required
            ? (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $label';
          }
          return null;
        }
            : null,
      ),
    );
  }

  Widget _buildMainImageSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Main Image',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: MainColor),
        ),
        SizedBox(height: 10),
        mainImage == null
            ? ElevatedButton(
          onPressed: _pickMainImage,

          style: ElevatedButton.styleFrom(
            backgroundColor: ColorConstant.logoSecondColor,
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          ),
          child: Text('Main Image', style: TextStyle(color: Colors.white)),
        )
            : Column(
          children: [
            Image.file(mainImage!, height: 200),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _changeMainImage,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                  child: Text('Change', style: TextStyle(color: Colors.white)),
                ),
                ElevatedButton(
                  onPressed: _removeMainImage,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: Text('Remove', style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMoreImagesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'More Images',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: MainColor),
        ),
        SizedBox(height: 10),
        ElevatedButton(
          onPressed: _pickMoreImages,
          style: ElevatedButton.styleFrom(
            backgroundColor: ColorConstant.logoSecondColor,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          ),
          child: const Text('More Images', style: TextStyle(color: Colors.white),),
        ),
        SizedBox(height: 10),
        moreImages.isNotEmpty
            ? GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 8.0,
            mainAxisSpacing: 8.0,
          ),
          itemCount: moreImages.length,
          itemBuilder: (context, index) {
            return Stack(
              children: [
                Image.file(moreImages[index], fit: BoxFit.cover),
                Positioned(
                  top: 0,
                  right: 0,
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _changeImage(index),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _removeImage(index),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        )
            : Container(),
      ],
    );
  }
}
