import 'dart:convert';
import 'dart:ffi';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:iq_mall/screens/Filter_Products_screen/widgets/Listview.dart';
import 'package:iq_mall/screens/Filter_Products_screen/widgets/sidemenu.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/utils/ShConstant.dart';
import 'package:iq_mall/widgets/CommonWidget.dart';
import 'package:get/get.dart';
import 'package:iq_mall/widgets/custom_image_view.dart';
import 'package:progressive_image/progressive_image.dart';

import '../../../Product_widget/Product_widget.dart';
import '../../../main.dart';
import '../../../models/HomeData.dart';
import '../controller/my_store_controller.dart';
import 'package:iq_mall/utils/ShImages.dart';

import 'my_store_products_listview.dart';

class MyStoreScreen extends GetView<MyStoreController> {
  MyStoreScreen({super.key});

  final dynamic unescape = HtmlUnescape();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: controller.scaffoldKey,
        backgroundColor: Colors.white,
        // drawer: CustomDrawer(),
        appBar: AppBar(
          elevation: 1,
          toolbarHeight: getSize(50),
          backgroundColor: Colors.white,
          title: Obx(() => Text(unescape.convert(controller.title.value))),
          leading: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: const Icon(
              Icons.arrow_back_ios,
              color: Colors.black,
            ),
          ),
          // actions: [
          //   AnimatedSwitcher(
          //     duration: const Duration(milliseconds: 800),
          //     transitionBuilder: (Widget child, Animation<double> animation) {
          //       return ScaleTransition(scale: animation, child: child);
          //     },
          //     child: Padding(
          //       padding: const EdgeInsets.only(left: 12.0, right: 25, bottom: 5),
          //       child: Row(
          //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //         children: [
          //           InkWell(
          //             splashColor: Colors.transparent,
          //             focusColor: Colors.transparent,
          //             highlightColor: Colors.transparent,
          //             onTap: () {
          //               _showBottomSheet(context);
          //             },
          //             child: Icon(Icons.filter_list),
          //           ),
          //
          //           InkWell(
          //             splashColor: Colors.transparent,
          //             focusColor: Colors.transparent,
          //             highlightColor: Colors.transparent,
          //             onTap: () {
          //               if(controller.selectedValueInt.value<2){
          //                 controller.selectedValueInt.value++;
          //               }
          //               else{
          //                 controller.selectedValueInt.value=0;;
          //
          //               }
          //               controller.loader.value = true;
          //               controller.selectedValue?.value =  controller.selectedValueInt.value==0?"newest": controller.selectedValueInt.value==1?"lowestToHighest":"highestToLowest";
          //               controller.page.value = 1;
          //               controller.loading.value = true;
          //               controller.Products?.clear();
          //               controller.Products?.clear();
          //               controller.getProducts(1).then((value) => controller.loader.value = false);
          //             },
          //             child: Obx(() {
          //               return
          //                 controller.selectedValueInt.value!=2?
          //                 SizedBox(
          //                   width: getHorizontalSize(60),
          //                   height: getSize(50),
          //                   child: Padding(
          //                     padding: const EdgeInsets.all(4.0),
          //                     child: Row(
          //                       mainAxisAlignment: MainAxisAlignment.end,
          //                     children: [
          //                       Icon(controller.selectedValueInt.value==0?Icons.arrow_downward:Icons.arrow_upward,color: Colors.red,size: getSize(16),),
          //                       Text("Price",style: TextStyle(color: Colors.red),),
          //                     ],
          //                                           ),
          //                   ),
          //                 ):SizedBox(
          //                   width: getHorizontalSize(60),
          //                   height: getSize(50),
          //
          //                   child: Padding(
          //                     padding: const EdgeInsets.all(8.0),
          //                     child: CustomImageView(
          //                       width: getSize(30),
          //                       height: getSize(30),
          //                       color: Colors.red,
          //                       svgPath: AssetPaths.newest,
          //                     ),
          //                   ),
          //                 );
          //             }),
          //           ),
          //
          //           // ElevatedButton(
          //           //   onPressed: () {
          //           //     _showBottomSheet(context);
          //           //     // scaffoldKey.currentState?.openDrawer();
          //           //   },
          //           //   style: ElevatedButton.styleFrom(
          //           //     primary: sh_light_grey,
          //           //     shape: RoundedRectangleBorder(
          //           //       borderRadius: BorderRadius.circular(25.0),
          //           //     ),
          //           //   ),
          //           //   child: Row(
          //           //     children: [
          //           //       Icon(Icons.filter_list),
          //           //       SizedBox(width: 8.0),
          //           //       Text('Filter'.tr,style: TextStyle(fontSize: getFontSize(18))),
          //           //     ],
          //           //   ),
          //           // ),
          //           // LayoutBuilder(
          //           //   builder: (BuildContext context, BoxConstraints constraints) {
          //           //     // Define the maximum width.
          //           //     double maxWidth = getHorizontalSize(200);
          //           //
          //           //     // Sample texts to measure. Replace with your actual dropdown items.
          //           //     final List<String> sampleTexts = [
          //           //       'Newest',
          //           //       '^',
          //           //       'Highest to Lowest price',
          //           //     ];
          //           //
          //           //     double calculateTextWidth(String text) {
          //           //       final textPainter = TextPainter(
          //           //         text: TextSpan(text: text, style: TextStyle(fontSize: getFontSize(13))),
          //           //         maxLines: 1,
          //           //         textDirection: TextDirection.ltr,
          //           //       );
          //           //       textPainter.layout(minWidth: 0, maxWidth: double.infinity);
          //           //       return textPainter.width;
          //           //     }
          //           //
          //           //     // Calculate the maximum text width.
          //           //     double textWidth = sampleTexts.map(calculateTextWidth).reduce(max);
          //           //
          //           //     // Add extra padding or other element widths.
          //           //     double totalWidth = textWidth + 20; // Adjust 20 for padding or other elements.
          //           //
          //           //     // Ensure the total width does not exceed the maximum width.
          //           //     totalWidth = min(totalWidth, maxWidth);
          //           //
          //           //     return Obx(
          //           //           () =>
          //           //           Container(
          //           //             constraints: BoxConstraints(minWidth: Get.width / 3, maxWidth: Get.width / 2),
          //           //             height: getSize(50),
          //           //             width: getHorizontalSize(200),
          //           //             decoration: BoxDecoration(
          //           //               borderRadius: BorderRadius.circular(25.0),
          //           //               border: Border.all(color: Colors.white.withOpacity(0.5)),
          //           //               color: sh_light_grey, // Use sh_light_grey here
          //           //               boxShadow: [
          //           //                 BoxShadow(
          //           //                   color: Colors.grey.shade300,
          //           //                   blurRadius: 1,
          //           //                   offset: const Offset(1, 2),
          //           //                 ),
          //           //               ],
          //           //             ),
          //           //             padding: getPadding(left: 16),
          //           //             alignment: Alignment.bottomCenter,
          //           //             child: DropdownButtonHideUnderline(
          //           //               child: Theme(
          //           //                 data: Theme.of(context).copyWith(
          //           //                   canvasColor: sh_light_grey, // Dropdown background color
          //           //                   popupMenuTheme: PopupMenuThemeData(
          //           //                     shape: RoundedRectangleBorder(
          //           //                       borderRadius: BorderRadius.circular(25),
          //           //                     ),
          //           //                   ),
          //           //                 ),
          //           //                 child: DropdownButton<String>(
          //           //                   value: controller.selectedValue?.value,
          //           //                   items: [
          //           //                     DropdownMenuItem(
          //           //                       value: 'newest',
          //           //                       child: Text(
          //           //                         'Newest'.tr,
          //           //                         style: TextStyle(color: Colors.black87, fontSize: getFontSize(13)), // Text color
          //           //                       ),
          //           //                     ),
          //           //                     DropdownMenuItem(
          //           //                       value: 'lowestToHighest',
          //           //                       child: Text(
          //           //                         'Lowest to Highest Price'.tr,
          //           //                         style: TextStyle(color: Colors.black87),
          //           //                       ),
          //           //                     ),
          //           //                     DropdownMenuItem(
          //           //                       value: 'highestToLowest',
          //           //                       child: Text(
          //           //                         'Highest to Lowest Price'.tr,
          //           //                         style: const TextStyle(color: Colors.black87),
          //           //                       ),
          //           //                     ),
          //           //                   ],
          //           //                   onChanged: (value) {
          //           //                     controller.loader.value = true;
          //           //                     controller.selectedValue?.value = value!;
          //           //                     controller.page.value = 1;
          //           //                     controller.loading.value = true;
          //           //                     controller.Products?.clear();
          //           //                     controller.Products?.clear();
          //           //                     controller.getProducts(1).then((value) => controller.loader.value = false);
          //           //                     // ... Your existing onChanged logic ...
          //           //                   },
          //           //                   hint: const Text(
          //           //                     'Sorting Options',
          //           //                     style: TextStyle(color: Colors.black54), // Hint text style
          //           //                   ),
          //           //                   icon: const Icon(
          //           //                     Icons.arrow_drop_down_sharp,
          //           //                     color: Colors.black, // Icon color
          //           //                   ),
          //           //                   style: TextStyle(color: Colors.black),
          //           //                   // Selected item style
          //           //                   isExpanded: true,
          //           //                   dropdownColor: sh_light_grey,
          //           //                   elevation: 16,
          //           //                   // Shadow elevation
          //           //                   borderRadius: BorderRadius.circular(15),
          //           //                   // Border radius of dropdown
          //           //                   padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), // Inner padding
          //           //                 ),
          //           //               ),
          //           //             ),
          //           //           ),
          //           //     );
          //           //   },
          //           // ),
          //         ],
          //       ),
          //     ),
          //   )
          // ],
          iconTheme: const IconThemeData(color: sh_textColorPrimary),
          actionsIconTheme: const IconThemeData(color: sh_textColorPrimary),
        ),
        body: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          controller: controller.scrollController,

          shrinkWrap: true,
          slivers: [
            Obx(
                  () {
                // var categories = globalController.homeDataList.value.categories!.where((category) => category.parent.toString() == controller.category.value.toString()).toList();
                // var categories = globalController.homeDataList.value.categories!.toList();
                RxList<Category> categories = globalController.homeDataList.value.categories!.toList().obs;

                return categories.isNotEmpty
                    ?
                TweenAnimationBuilder<double>(
                  duration: const Duration(milliseconds: 800),
                  curve: Curves.fastEaseInToSlowEaseOut,
                  tween: Tween<double>(begin: 0.0, end: controller.pinnedTopPad.value),
                  builder: (context, value, child) {
                    // print(value);
                    if (value > 30 && !controller.animateSubCategories.value) {
                      controller.animateSubCategories.value = true;
                    } else if (value < 30) {
                      controller.animateSubCategories.value = false;
                    }

                    // print("valueeee: ${(Get.height / Get.width) / 1.5}");
                    return SliverAppBar(
                      pinned: true,
                      leading: SizedBox.fromSize(),
                      leadingWidth: 0,

                      expandedHeight: !controller.animateSubCategories.value ? getSize(133 - value) : getSize(60),
                      collapsedHeight: !controller.animateSubCategories.value ? getSize(133 - value) : getSize(60),
                      backgroundColor: ColorConstant.whiteA700,
                      flexibleSpace: DecoratedBox(
                        decoration: BoxDecoration(color: ColorConstant.whiteA700),
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 800),
                          transitionBuilder: (Widget child, Animation<double> animation) {
                            return ScaleTransition(scale: animation, child: child);
                          },
                          child: Container(
                            alignment: Alignment.centerLeft,
                            height: categories.isEmpty
                                ? 0
                                : !controller.animateSubCategories.value
                                ? getSize(133 - value)
                                : getSize(60),
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,

                              padding: getPadding(all: 0),

                              itemCount:categories.length,
                              itemBuilder: (BuildContext context, int index) {
                                var categories = globalController.homeDataList.value.categories!.toList();
                                var unescape = HtmlUnescape();
                                var text = unescape.convert(categories[index].categoryName);
                                return GestureDetector(
                                    onTap: () {
                                      var f = {
                                        "categories": [
                                          categories[index].id.toString(),
                                        ],
                                      };
                                      String jsonString = jsonEncode(f);

                                      // Get.delete<Filter_ProductsController>();

                                      // Filter_ProductsController _controller = Get.find();
                                      // _controller.onInit();
                                      // Get.to(
                                      //   () => Filter_Productsscreen(),
                                      //   arguments: {
                                      //     'title': categories[index].categoryName.toString(),
                                      //     'id': int.parse(categories[index].id.toString()),
                                      //     'type': jsonString,
                                      //   },
                                      // );
                                      controller.page.value=1;
                                      controller.getProducts(controller.page.value);
                                      // controller.category.value = categories[index].id.toString();
                                      // controller.type = jsonString;
                                      // controller.title.value = categories[index].categoryName.toString();
                                      // controller.selectedCategoryIds = int.parse(categories[index].id.toString());
                                    },
                                    child: Padding(
                                      padding: getPadding(left: 8.0, right: 8, top: 8),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          // mediaWidget(
                                          //   convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
                                          //   AssetPaths.placeholder,
                                          //   height: getSize(78),
                                          //   width: getSize(76),
                                          //   isCategory: true,
                                          //   fit: BoxFit.contain,
                                          // ),
                                          AnimatedSwitcher(
                                              duration: const Duration(milliseconds: 800),
                                              transitionBuilder: (Widget child, Animation<double> animation) {
                                                return ScaleTransition(scale: animation, child: child);
                                              },
                                              child: Obx(
                                                    () => !controller.animateSubCategories.value
                                                    ? ClipRRect(
                                                  borderRadius: const BorderRadius.all(Radius.circular(50)),
                                                  child: ProgressiveImage(
                                                    key: UniqueKey(),

                                                    placeholder: const AssetImage(AssetPaths.placeholderCircle),
                                                    // size: 1.87KB
                                                    thumbnail: CachedNetworkImageProvider(
                                                      convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
                                                    ),
                                                    blur: 0,
                                                    // size: 1.29MB
                                                    image: CachedNetworkImageProvider(convertToThumbnailUrl(categories[index].main_image ?? "", isBlurred: false) ?? ''),
                                                    height: getSize(78 - value),
                                                    width: getSize(76 - value),

                                                    fit: BoxFit.cover,
                                                    fadeDuration: Duration(milliseconds: 200),
                                                  ),
                                                )
                                                    : SizedBox(),
                                              )),

                                          // Container(
                                          //   height: getSize(83),
                                          //   width: getSize(80),
                                          //   decoration: BoxDecoration(
                                          //     borderRadius: BorderRadius.circular(5), // Adjust the value as needed
                                          //     image: DecorationImage(
                                          //       image: getAvatarImageProvider(categories[index].main_image, AssetPaths.placeholder),
                                          //     ),
                                          //   ),
                                          // ),
                                          const SizedBox(height: spacing_control),
                                          value < 30
                                              ? SizedBox(
                                              width: getSize(76 - (value / 2)),
                                              child: Text(
                                                text,
                                                maxLines: 2,
                                                softWrap: true,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                  overflow: TextOverflow.visible,
                                                  color: Colors.black,
                                                  fontSize: getFontSize(15),
                                                ),
                                              ))
                                              : Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(5),
                                              border: Border.all(color: ColorConstant.logoSecondColor, width: 1),
                                            ),
                                            padding: getPadding(all: 5),
                                            child: Text(
                                              text,
                                              maxLines: 1,
                                              softWrap: true,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                overflow: TextOverflow.visible,
                                                color: Colors.black,
                                                fontSize: getFontSize(15),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ));
                              },
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                )
                    : SliverToBoxAdapter(child: SizedBox());
              },
            ),
            // SliverToBoxAdapter(
            //   child: Obx(() {
            //     var categories = globalController.homeDataList.value.categories!.where((category) => category.parent.toString() == controller.category.value.toString()).toList();
            //     return Padding(
            //       // padding: const EdgeInsets.only(top: 20.0),
            //       padding: const EdgeInsets.only(top: 0.0),
            //       child: SizedBox(
            //         height: categories.isEmpty ? 0 : getSize(133),
            //         child: CustomScrollView(
            //           scrollDirection: Axis.horizontal,
            //           physics: const ScrollPhysics(),
            //           shrinkWrap: true,
            //           slivers: <Widget>[
            //             SliverPadding(
            //               padding: const EdgeInsets.only(left: 1.0, right: 1.0),
            //               sliver: SliverGrid(
            //                 gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            //                   mainAxisSpacing: 1,
            //                   childAspectRatio: getScreenRatio() > 1 ? (Get.height / Get.width) / 1.5 : (Get.height / Get.width) / 0.9,
            //                   crossAxisSpacing: 2.0,
            //                   crossAxisCount: 1,
            //                 ),
            //                 delegate: SliverChildBuilderDelegate(
            //                   (BuildContext context, int index) {
            //                     var categories = globalController.homeDataList.value.categories!.where((category) => category.parent == int.parse(controller.category.value)).toList();
            //                     var unescape = HtmlUnescape();
            //                     var text = unescape.convert(categories[index].categoryName);
            //                     print("textsdasdas");
            //                     print(text);
            //                     return GestureDetector(
            //                         onTap: () {
            //                           var f = {
            //                             "categories": [
            //                               categories[index].id.toString(),
            //                             ],
            //                           };
            //                           String jsonString = jsonEncode(f);
            //
            //                           // Get.delete<Filter_ProductsController>();
            //
            //                           // Filter_ProductsController _controller = Get.find();
            //                           // _controller.onInit();
            //                           // Get.to(
            //                           //   () => Filter_Productsscreen(),
            //                           //   arguments: {
            //                           //     'title': categories[index].categoryName.toString(),
            //                           //     'id': int.parse(categories[index].id.toString()),
            //                           //     'type': jsonString,
            //                           //   },
            //                           // );
            //
            //                           Get.toNamed(AppRoutes.Filter_products, arguments: {
            //                             'title': categories[index].categoryName.toString(),
            //                             'id': int.parse(categories[index].id.toString()),
            //                             'type': jsonString,
            //                           }, parameters: {
            //                             'tag': "${int.parse(categories[index].id.toString())}:${categories[index].categoryName.toString()}"
            //                           });
            //                           // controller.category.value = categories[index].id.toString();
            //                           // controller.type = jsonString;
            //                           // controller.title.value = categories[index].categoryName.toString();
            //                           // controller.selectedCategoryIds = int.parse(categories[index].id.toString());
            //                         },
            //                         child: Padding(
            //                           padding: getPadding(left: 8.0, right: 8, top: 8),
            //                           child: Column(
            //                             mainAxisAlignment: MainAxisAlignment.start,
            //                             children: <Widget>[
            //                               // mediaWidget(
            //                               //   convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
            //                               //   AssetPaths.placeholder,
            //                               //   height: getSize(78),
            //                               //   width: getSize(76),
            //                               //   isCategory: true,
            //                               //   fit: BoxFit.contain,
            //                               // ),
            //                               ClipRRect(
            //                                 borderRadius: const BorderRadius.all(Radius.circular(50)),
            //                                 child: ProgressiveImage(
            //                                   key: UniqueKey(),
            //
            //                                   placeholder: const AssetImage(AssetPaths.placeholderCircle),
            //                                   // size: 1.87KB
            //                                   thumbnail: CachedNetworkImageProvider(
            //                                     convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
            //                                   ),
            //                                   blur: 0,
            //                                   // size: 1.29MB
            //                                   image: CachedNetworkImageProvider(convertToThumbnailUrl(categories[index].main_image ?? "", isBlurred: false) ?? ''),
            //                                   height: getSize(78),
            //                                   width: getSize(76),
            //
            //                                   fit: BoxFit.cover,
            //                                   fadeDuration: Duration(milliseconds: 200),
            //                                 ),
            //                               ),
            //                               // Container(
            //                               //   height: getSize(83),
            //                               //   width: getSize(80),
            //                               //   decoration: BoxDecoration(
            //                               //     borderRadius: BorderRadius.circular(5), // Adjust the value as needed
            //                               //     image: DecorationImage(
            //                               //       image: getAvatarImageProvider(categories[index].main_image, AssetPaths.placeholder),
            //                               //     ),
            //                               //   ),
            //                               // ),
            //                               const SizedBox(height: spacing_control),
            //                               Flexible(
            //                                 child: Text(
            //                                   text,
            //                                   maxLines: 2,
            //                                   softWrap: true,
            //                                   textAlign: TextAlign.start,
            //                                   style: TextStyle(
            //                                     overflow: TextOverflow.visible,
            //                                     color: Colors.black,
            //                                     fontSize: getFontSize(15),
            //                                   ),
            //                                 ),
            //                               ),
            //                             ],
            //                           ),
            //                         ));
            //                   },
            //                   childCount: globalController.homeDataList.value.categories!.where((category) => category.parent.toString() == controller.category.value.toString()).length,
            //                 ),
            //               ),
            //             ),
            //           ],
            //         ),
            //       ),
            //     );
            //   }),
            // ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.only(left: 25.0, bottom: 10, top: 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(bottom: 3.0),
                      child: Text(
                        'Products'.tr,
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                    Row(
                      children: [
                        Obx(() => Text('${controller.count.value.toString()} results    ')),
                        Obx(() => Text(
                          unescape.convert(controller.title.value),
                          style: TextStyle(color: Colors.grey[600]),
                        )),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.only(top: 8, bottom: 20),
                child: ListView(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  children: [
                    Obx(() => !controller.loader.value
                        ? MyStoreCustomListView(
                      controller: controller,
                    )
                        : Progressor_indecator()),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(child: Obx(() => !controller.loadmore.value ? Container() : Align(alignment: Alignment.center, child: Progressor_indecator())))
          ],
        ));
  }

}
