import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:iq_mall/screens/Home_screen_fragment/controller/Home_screen_fragment_controller.dart';
import 'package:iq_mall/screens/SignIn_screen/controller/SignIn_controller.dart';
import 'package:iq_mall/screens/Wishlist_screen/controller/Wishlist_controller.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/utils/ShConstant.dart';
import 'package:iq_mall/widgets/ShWidget.dart';
import 'package:iq_mall/main.dart';
import 'package:iq_mall/screens/HomeScreenPage/ShHomeScreen.dart';
import 'package:iq_mall/utils/ShImages.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import '../../../cores/math_utils.dart';
import '../../../utils/validation_functions.dart';
import '../../../widgets/custom_button.dart';
import '../../../widgets/custom_image_view.dart';
import '../../../widgets/custom_text_form_field.dart';
import '../../tabs_screen/tabs_view_screen.dart';
import 'package:flutter/services.dart';

class SignInForm extends StatelessWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController emailController;
  final FocusNode emailFocusNode;
  final FocusNode passwordFocusNode;
  final TextEditingController passwordController;
  final bool obscureText;
  final VoidCallback onForgotPassword;
  final VoidCallback onSignIn;
  final VoidCallback onSignUp;
  final SignInController controller;
  final bool isIOS;
  final Function(BuildContext) onAppleSignIn;
  final Function(BuildContext) onGoogleSignIn;

  SignInForm({
    required this.formKey,
    required this.emailFocusNode,
    required this.passwordFocusNode,
    required this.emailController,
    required this.passwordController,
    required this.obscureText,
    required this.onForgotPassword,
    required this.onSignIn,
    required this.onSignUp,
    required this.isIOS,
    required this.onAppleSignIn,
    required this.onGoogleSignIn,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Container(
        height: Get.height,
        alignment: Alignment.bottomCenter,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: getPadding(top: 10.0),
                  child: Center(
                      child: CustomImageView(
                    // svgUrl: prefs!.getString('main_image')!,
                    svgPath: AssetPaths.signInIllustration,
                    width: getSize(250),
                    height: getSize(250),
                  )),
                ),
                SizedBox(
                  height: getVerticalSize(30),
                ),
                CustomTextFormField(
                  controller: emailController,
                  textInputAction: TextInputAction.next,
                  focusNode: emailFocusNode,
                  textInputType: TextInputType.number,
                  width: 320,
                  autofocus: false,
                  hintText: 'Phone number',
                  prefix: CodePicker(context),
                  variant: TextFormFieldVariant.OutlineGray300,
                  shape: TextFormFieldShape.RoundedBorder10,
                  padding: TextFormFieldPadding.PaddingT4,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'fill phone number please'.tr;
                    }
                    if (value.length < 8) {
                      return 'Phone number must be of 8 digits'.tr;
                    }
                    return null;
                  },
                ),
                const SizedBox(
                  height: spacing_standard_new,
                ),
                Obx(
                  () => CustomTextFormField(
                    controller: passwordController,
                    focusNode: passwordFocusNode,
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.visiblePassword,
                    width: 320,
                    isObscureText: controller.obscureText.value,
                    autofocus: false,
                    hintText: 'Password',
                    prefix: const Padding(
                      padding: EdgeInsets.only(left: 8.0),
                      child: Icon(Icons.lock),
                    ),
                    suffix: IconButton(
                        onPressed: () {
                          controller.obscureText.value = !controller.obscureText.value;
                        },
                        icon: Icon(
                          !controller.obscureText.value ? Icons.remove_red_eye : Icons.visibility_off,
                          color: MainColor,
                          size: 18,

                        )),
                    variant: TextFormFieldVariant.OutlineGray300,
                    shape: TextFormFieldShape.RoundedBorder10,
                    padding: TextFormFieldPadding.PaddingT4,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Fill password please'.tr;
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: getPadding(top: 12.0),
                  child: InkWell(
                    onTap: onForgotPassword,
                    child: SizedBox(width: getHorizontalSize(250), height: getSize(50), child: Center(child: Text('Forget password?'.tr))),
                  ),
                ),
                Obx(() => MyCustomButton(
                      height: getVerticalSize(50),
                      text: "Sign In".tr,
                      fontSize: 20,
                      borderRadius: 10,
                      width: 320,
                      buttonColor: ColorConstant.logoSecondColor,
                  borderColor: Colors.transparent,

                      isExpanded: controller.loggin_in.value,
                      onTap: onSignIn,
                    )),
                Obx(() => IgnorePointer(
                      ignoring: controller.loggin_in.value,
                      child: MyCustomButton(
                        height: getVerticalSize(50),
                        text: "Sign Up".tr,
                        fontSize: 20,
                        borderRadius: 10,
                        textColor: Colors.white,
                        width: 320,
                        buttonColor: ColorConstant.logoSecondColor,

                        padding: ButtonPadding.PaddingNone,
                        borderColor: Colors.transparent,
                        variant: ButtonVariant.outLineBlackFillWhite,
                        isExpanded: false,
                        onTap: onSignUp,
                      ),
                    )),
                !isIOS
                    ? Container()
                    : Padding(
                        padding: const EdgeInsets.only(top: 18.0),
                        child: SignInWithAppleButton(
                          style: SignInWithAppleButtonStyle.black,
                          onPressed: () async {
                            final credential = await SignInWithApple.getAppleIDCredential(
                              scopes: [
                                AppleIDAuthorizationScopes.email,
                                AppleIDAuthorizationScopes.fullName,
                              ],
                            );
                            controller.emailFocusNode.unfocus();
                            controller.passwordFocusNode.unfocus();
                            onAppleSignIn(context);
                          },
                        ),
                      ),
                Padding(
                  padding: getPadding(top: 12.0),
                  child: SizedBox(
                    width: 320,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // InkWell(
                        //   onTap: () {
                        //     FacebookAuth.instance.login(permissions: ["public_profile", "email"]).then((value) async {
                        //       if (value.status == LoginStatus.success) {
                        //         // The user is logged in
                        //         await FacebookAuth.instance.getUserData().then((userData) async {
                        //           controller.userObj = userData;
                        //           final AccessToken? accessToken = await FacebookAuth.instance.accessToken!;
                        //           String? facebookAccessToken = accessToken?.token;
                        //           // Call your method to handle the login with the user data
                        //           controller.socialmedialogin('facebook', controller.userObj, facebookAccessToken);
                        //         });
                        //       } else if (value.status == LoginStatus.cancelled) {
                        //         // The user cancelled the login
                        //         print('Facebook login cancelled');
                        //       } else {
                        //         // Facebook login failed
                        //         print('Facebook login failed: ${value.message}');
                        //       }
                        //     }).catchError((e) {
                        //       // Handle errors here
                        //       print('Facebook login error: $e');
                        //     });
                        //   },
                        //   child: CustomImageView(
                        //     svgPath: AssetPaths.FacebookIcon,
                        //     width: getSize(
                        //       50,
                        //     ),
                        //   ),
                        // ),
                        InkWell(
                          highlightColor: Colors.transparent,
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          onTap: () async {
                            controller.emailFocusNode.unfocus();
                            controller.passwordFocusNode.unfocus();
                            onGoogleSignIn(context);
                          },
                          child: CustomImageView(
                            svgPath: AssetPaths.GoogleImage,
                            width: getSize(
                              50,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Platform.isIOS
                    ? Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SignInWithAppleButton(
                          style: SignInWithAppleButtonStyle.whiteOutlined,
                          onPressed: () async {
                            final credential = await SignInWithApple.getAppleIDCredential(
                              scopes: [
                                AppleIDAuthorizationScopes.email,
                                AppleIDAuthorizationScopes.fullName,
                              ],
                            );
                            final String? userIdentifier = credential.identityToken;
                            final String userIdentifier2 = credential.authorizationCode;
                            print(userIdentifier);
                            print(userIdentifier2);
                            print(credential);
                          },
                        ),
                      )
                    : Container(),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: InkWell(
                    splashColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () {
                      prefs?.setString('logged_in', 'false');
                      LoadingDrawer.value = false;
                      if (Get.isRegistered<Home_screen_fragmentController>()) {
                        Get.back();
                      } else {
                        Get.offNamed(AppRoutes.tabsRoute);
                      }
                    },
                    child: Container(
                      color: Colors.transparent,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(''),
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: Text(
                                  'Skip'.tr,
                                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward,
                                size: 12,
                                color: MainColor,
                              )
                            ],
                          ),
                          const Text(''),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
