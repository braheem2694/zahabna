import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:iq_mall/screens/Stores_details/widgets/slider_item_widget.dart';
import 'package:iq_mall/screens/Stores_details/widgets/store_category_widget.dart';
import 'package:iq_mall/screens/Stores_screen/widgets/my_store_widget.dart';
import 'package:iq_mall/widgets/custom_image_view.dart';
import 'package:iq_mall/widgets/ui.dart';
import 'package:photo_view/photo_view.dart';
import 'package:uuid/uuid.dart';

import '../../cores/math_utils.dart';
import '../../main.dart';
import '../../models/CardsCategories.dart';
import '../../models/Stores.dart';
import '../../models/category.dart';
import '../../utils/ShColors.dart';
import '../../utils/ShImages.dart';
import '../../widgets/ShWidget.dart';
import '../../widgets/image_widget.dart';
import '../Stores_screen/widgets/work_time_widget.dart';
import 'controller/store_detail_controller.dart';
import 'models/MainSlider.dart';
import 'package:smooth_page_indicator/src/effects/scrolling_dots_effect.dart';
import 'package:smooth_page_indicator/src/smooth_page_indicator.dart';

class StoreDetails extends StatelessWidget {
  StoreDetailController controller = Get.put(StoreDetailController());

  StoreDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFf5f5f5),
      appBar: AppBar(
        leading: Ui.backArrowIcon(iconColor: Colors.black),
        shadowColor: Colors.black,
        elevation: 0.5,
        title: Text(controller.store.value.store_name ?? ''),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 8, bottom: getBottomPadding() + getSize(45)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(
              width: double.maxFinite,
              child: Column(
                children: [
                  Obx(
                    () => controller.loading.value
                        ? SizedBox(height: getVerticalSize(200), child: Ui.circularIndicator(width: 40, height: 40, color: ColorConstant.logoFirstColor))
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: CarouselSlider.builder(
                              options: CarouselOptions(
                                height: getVerticalSize(180),
                                initialPage: 0,
                                autoPlay: false,
                                viewportFraction: 1,
                                animateToClosest: true,
                                enlargeCenterPage: true,
                                enableInfiniteScroll: false,
                                scrollDirection: Axis.horizontal,
                                onPageChanged: (index, reason) {
                                  controller.sliderIndex.value = index;
                                },
                              ),
                              itemCount: controller.storeImages.length,
                              itemBuilder: (context, index, realIndex) {
                                MainSlider model = controller.storeImages[index];

                                return GestureDetector(
                                  behavior: HitTestBehavior.translucent,
                                  onTap: () {
                                    Uuid uuid = Uuid();
                                    String userID = uuid.v4();
                                    // Get.toNamed(AppRoutes.newsDetails, arguments: model, parameters: {"tag": "$userID${model.id}", "fromKey": 'news_hor'});
                                  },
                                  child: sliderItem(
                                    model,
                                  ),
                                );
                              },
                            ),
                          ),
                  ),
                  Padding(
                    padding: getPadding(bottom: 5.0, left: 10, top: 10),
                    child: Obx(
                      () => controller.loading.value
                          ? SizedBox()
                          : controller.storeImages.length > 1
                              ? Container(
                                  height: getVerticalSize(9),
                                  margin: getPadding(bottom: 5),
                                  child: AnimatedSmoothIndicator(
                                    activeIndex: controller.sliderIndex.value,
                                    count: controller.storeImages.length > 5 ? 5 : controller.storeImages.length,
                                    axisDirection: Axis.horizontal,
                                    effect: ScrollingDotsEffect(
                                      spacing: 7,
                                      activeDotColor: ColorConstant.logoSecondColor,
                                      dotColor: ColorConstant.logoFirstColor,
                                      dotHeight: 6,
                                      dotWidth: 6,
                                    ),
                                  ),
                                )
                              : SizedBox(),
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: getPadding(bottom: 12.0),
              child: SizedBox(
                  height: Get.height * 0.15,
                  child: Obx(() {
                    return controller.loading.value
                        ? SizedBox()
                        : ListView.builder(
                            padding: getPadding(left: 8, top: 11),
                            scrollDirection: Axis.horizontal,
                            physics: const BouncingScrollPhysics(),
                            itemCount: controller.categories.length,
                            itemBuilder: (context, index) {
                              Category model = controller.categories[index];
                              return Padding(
                                padding: getPadding(right: 10.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () {},
                                  child: Stack(
                                    alignment: Alignment.topCenter,
                                    children: [
                                      storeCategory(model: model),
                                    ],
                                  ),
                                ),
                              );
                            });
                  })),
            ),
            Padding(
              padding: getPadding(left: 12.0, right: 12),
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: ColorConstant.black900.withOpacity(0.15),
                    blurRadius: 4.0,
                    spreadRadius: 0.0,
                    offset: const Offset(0, 3.0),
                  )
                ], color: Colors.white, borderRadius: BorderRadius.circular(5)),
                padding: getPadding(all: 8),
                child: Row(
                  children: [
                    Icon(
                      Icons.location_on,
                      color: ColorConstant.logoSecondColor,
                      size: getSize(25),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      controller.store.value.address.toString(),
                      style: TextStyle(fontSize: getFontSize(18)),
                    )
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Obx(() {
              return Padding(
                padding: getPadding(left: 12.0, right: 12, top: 10, bottom: 20),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5),
                  child: ExpansionPanelList(
                    dividerColor: ColorConstant.whiteA700,
                    elevation: 2,
                    expansionCallback: (int index, bool isExpanded) {
                      controller.toggleExpand(isExpanded);
                    },
                    children: List<ExpansionPanel>.generate(1, (int mainIndex) {
                      return ExpansionPanel(
                        canTapOnHeader: true,
                        backgroundColor: ColorConstant.whiteA700,
                        headerBuilder: (BuildContext context, bool isExpanded) {
                          return Padding(
                            padding: getPadding(left: 8.0),
                            child: SizedBox(
                              width: getHorizontalSize(344),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Icon(
                                    Icons.calendar_month,
                                    color: ColorConstant.logoSecondColor,
                                    size: getSize(25),
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  RichText(
                                      text: TextSpan(children: [
                                        TextSpan(text: "Open", style: TextStyle(fontSize: getFontSize(18), color: ColorConstant.logoFirstColor)),
                                      ]),
                                      textAlign: TextAlign.left),
                                ],
                              ),
                            ),
                          );
                        },
                        body: ListView(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          children: [
                            Padding(
                              padding: getPadding(bottom: 12.0),
                              child: SizedBox(
                                  height: Get.height * 0.15,
                                  child: Obx(() {
                                    return controller.loading.value
                                        ? SizedBox()
                                        : ListView.builder(
                                            padding: getPadding(left: 8, top: 11),
                                            scrollDirection: Axis.horizontal,
                                            physics: const BouncingScrollPhysics(),
                                            itemCount: 7,
                                            itemBuilder: (context, index) {
                                              WorkDay model = WorkDay(id: 0, endingTime: "16:00", startingTime: "08:00", name: "Monday");
                                              return Padding(
                                                padding: getPadding(right: 10.0),
                                                child: InkWell(
                                                  splashColor: Colors.transparent,
                                                  focusColor: Colors.transparent,
                                                  highlightColor: Colors.transparent,
                                                  onTap: () {},
                                                  child: Stack(
                                                    alignment: Alignment.topCenter,
                                                    children: [
                                                      storeWorkTime(model: model),
                                                    ],
                                                  ),
                                                ),
                                              );
                                            });
                                  })),
                            ),
                          ],
                        ),
                        isExpanded: controller.isExpanded.value,
                      );
                    }).toList(),
                  ),
                ),
              );
            }),
            Padding(
              padding: getPadding(left: 12.0, right: 12),
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: ColorConstant.black900.withOpacity(0.15),
                    blurRadius: 4.0,
                    spreadRadius: 0.0,
                    offset: const Offset(0, 3.0),
                  )
                ], color: Colors.white, borderRadius: BorderRadius.circular(5)),
                padding: getPadding(all: 8),
                child: Row(
                  children: [
                    Icon(
                      Icons.phone_android,
                      color: ColorConstant.logoSecondColor,
                      size: getSize(25),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      controller.store.value.phone_number.toString(),
                      style: TextStyle(fontSize: getFontSize(18)),
                    )
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: getPadding(left: 12.0, right: 12),
              child: Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                    color: ColorConstant.black900.withOpacity(0.15),
                    blurRadius: 4.0,
                    spreadRadius: 0.0,
                    offset: const Offset(0, 3.0),
                  )
                ], color: Colors.white, borderRadius: BorderRadius.circular(5)),
                padding: getPadding(all: 8),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          "About Store",
                          style: TextStyle(fontSize: getFontSize(18), color: ColorConstant.logoSecondColor),
                        )
                      ],
                    ),
                    Padding(
                      padding: getPadding(top: 12),
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(color: ColorConstant.gray400, width: 1), borderRadius: BorderRadius.circular(5)),
                        padding: getPadding(all: 5),
                        width: Get.width,
                        child: Text(
                          // controller.store.value.description.toString(),
                          "this is the text that describes the store",

                          style: TextStyle(fontSize: getFontSize(18)),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: Padding(
          padding: getPadding(bottom: getBottomPadding()),
          child: FloatingActionButton(
            onPressed: () {
              Get.toNamed(AppRoutes.myStore, arguments: {'store': controller.store.value});
            },
            shape: CircleBorder(

            ),

            backgroundColor: ColorConstant.logoSecondColor,

            child: Icon(Icons.category_rounded, color: ColorConstant.logoFirstColor, size: getSize(25)),
          )
          // Obx(() =>
          //     SpeedDial(
          //       useRotationAnimation: true,
          //       visible: true,
          //       backgroundColor: Button_color,
          //       spaceBetweenChildren: 5,
          //       spacing: 10,
          //       gradient: LinearGradient(
          //         begin: Alignment.bottomLeft,
          //         end: Alignment.bottomRight,
          //         colors: [
          //           ColorConstant.logoSecondColor.withOpacity(0.4),
          //           ColorConstant.logoSecondColor.withOpacity(0.6),
          //           ColorConstant.logoSecondColor.withOpacity(0.9),
          //         ],
          //       ),
          //       animationDuration: Duration(milliseconds: 300),
          //       animationCurve: Curves.easeInOut,
          //       curve: Curves.easeInOut,
          //       // the type of animation curve you want
          //
          //       activeBackgroundColor: Button_color,
          //       overlayColor: Colors.white,
          //
          //       // Set the overlay color to transparent
          //       overlayOpacity: 0.5,
          //       renderOverlay: false,
          //       // Set the overlay opacity to 0
          //       activeChild: Icon(Icons.close, color: Colors.white),
          //       child: Icon(Icons.edit, color: Colors.white),
          //       animationAngle: 3.15,
          //
          //       openCloseDial: controller.myValue,
          //       children: [
          //         SpeedDialChild(
          //           child: Icon(Icons.edit, color: Colors.white, size: getSize(20)),
          //           backgroundColor: ColorConstant.logoSecondColor,
          //           shape: CircleBorder(),
          //           label: 'Edit shop'.tr,
          //           labelStyle: TextStyle(fontSize: getFontSize(12), color: Colors.white),
          //           labelBackgroundColor: MainColor,
          //           onTap: () {
          //
          //           },
          //         ),
          //         SpeedDialChild(
          //           child: const Icon(
          //             Icons.category_rounded,
          //             color: Colors.white,
          //           ),
          //           backgroundColor: ColorConstant.logoFirstColor.withOpacity(0.8),
          //           label:
          //           'All Items',
          //           labelStyle: TextStyle(fontSize: getFontSize(12), color: Colors.white),
          //           labelBackgroundColor: MainColor,
          //           shape: const CircleBorder(),
          //           onTap: () {
          //             Get.toNamed(AppRoutes.myStore, arguments: {'store': controller.store.value});
          //           },
          //         ),
          //       ],
          //     )),
          ),
    );
  }
}
