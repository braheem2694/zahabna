import 'package:flutter/foundation.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import '../../../main.dart';
import '../../../models/HomeData.dart';
import '../../../models/Stores.dart';
import '../../../models/category.dart' as cat;
import '../../../utils/ShColors.dart';
import '../../../widgets/ShWidget.dart';
import '../../../widgets/ui.dart';
import '../../OrderSummaryScreen/widgets/PaymentMethodsWidets/PaymentMethodsWidget.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/material/scaffold.dart';
import 'package:flutter/src/widgets/scroll_controller.dart';
import 'package:flutter/src/animation/curves.dart';
import 'package:flutter/src/material/colors.dart';

import '../models/MainSlider.dart';


class StoreDetailController extends GetxController {
  RxBool loading = true.obs;
  RxBool loadMore = false.obs;
  RxBool isScroll = false.obs;
  RxInt offset = 0.obs;
  RxInt page = 1.obs;
  RxString count = "0".obs;
  RxList<Product> products= <Product>[].obs;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  int previousNbOfImages = 0;
  int nbOfImages = 0;
  int countImages = 0;
  ScrollController scrollController =  ScrollController();
  late RxList<MainSlider> storeImages = <MainSlider>[].obs;
   Rx<StoreClass> store = StoreClass().obs;
  Rx<int> sliderIndex = 0.obs;
  RxInt sectionIndex = 0.obs;
  RxBool isExpanded = true.obs;
  Map args = {};
  RxList<cat.Category> categories = <cat.Category>[].obs;
  final myValue = ValueNotifier<bool>(false); // Initial value is false

  @override
  void onInit() {
    args = Get.arguments;
    store.value=args["store"];
    storeImages.addAll(args["store"].images);
    storeImages.add(MainSlider(mainImage: "https://jewelrycms.beeflex.net/uploads/141/1/YsD1fHl7Rh.png"));
    storeImages.add(MainSlider(mainImage: "https://jewelrycms.beeflex.net/uploads/141/1/YsD1fHl7Rh.png"));
    storeImages.add(MainSlider(mainImage: "https://jewelrycms.beeflex.net/uploads/141/1/YsD1fHl7Rh.png"));
    loading.value=false;
    getCategoriesFromApi();

    super.onInit();
  }
  void toggleExpand(bool newValue) {
    isExpanded.value=newValue;
  }
  getCategoriesFromApi() async {
    loading.value = true;
    Map<String, dynamic> response = await api.getData({
      'storeId': store.value.id,
      'get_children': 'true',
    }, "products/get-categories");

    if (response.isNotEmpty) {
      if (response['categories'] is List) {
        categories =List<cat.Category>.from(response["categories"].map((x) => cat.Category.fromJson(x))).obs;
        loading.value = false;
        return categories;
      } else {
        loading.value = false;
        print('Expected a List but got something else');
        return false;
      }
    } else {
      loading.value = false;
    }
  }


}
