import 'package:cached_network_image/cached_network_image.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:iq_mall/Product_widget/Product_widget.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/screens/ProductDetails_screen/controller/ProductDetails_screen_controller.dart';
import 'package:iq_mall/screens/ProductDetails_screen/widgets/BottomButtons .dart';
import 'package:iq_mall/screens/ProductDetails_screen/widgets/ProductInfo.dart';
import 'package:iq_mall/screens/ProductDetails_screen/widgets/SliderImages.dart';
import 'package:flutter/material.dart';
import 'package:iq_mall/screens/ProductDetails_screen/widgets/add_to_cart_button.dart';
import 'package:iq_mall/screens/ProductDetails_screen/widgets/variants.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/widgets/slider.dart';
import 'package:iq_mall/utils/ShConstant.dart';
import 'package:iq_mall/widgets/ShWidget.dart';
import 'package:iq_mall/widgets/CommonWidget.dart';
import 'package:get/get.dart';
import 'package:html/parser.dart';
import 'package:iq_mall/widgets/ui.dart';
import 'package:progressive_image/progressive_image.dart';
import '../../main.dart';
import '../../models/HomeData.dart';
import '../../routes/app_routes.dart';
import '../../utils/ShImages.dart';
import '../../widgets/image_widget.dart';

class ProductDetails_screen extends StatefulWidget {

  final Product? product;
  final bool? fromCart;
  final String? productSlug;

  const ProductDetails_screen({super.key,  this.product,  this.fromCart,  this.productSlug});

  @override
  State<ProductDetails_screen> createState() => _ProductDetails_screenState();
}

class _ProductDetails_screenState extends State<ProductDetails_screen> {


  ProductDetails_screenController controller =  Get.put(ProductDetails_screenController());



  @override
  void initState() {

    controller.arguments = {
      'product': widget.product, 'from_cart':widget.fromCart, "product_slug":widget.productSlug,
      // "imageProvider": images,
    };
    controller.onReady();
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {

    controller.dispose();
    // TODO: implement dispose
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {

    return WillPopScope(
      onWillPop: () async {
        globalController.isLiked.value = controller.product.value?.is_liked == 1 ? true : false;
        Get.back(result: controller.product.value);
        return Future.value(true);
      },
      child: Scaffold(
          backgroundColor: Colors.white,
          body: Obx(
            () => controller.fromBanner.value
                ? Progressor_indecator()
                : controller.product.value == null
                    ? const SizedBox()
                    : Padding(
                      padding:  EdgeInsets.only(top: 24),
                      child: IgnorePointer(
                          ignoring: controller.freez.value,
                          child: Stack(
                            alignment: Alignment.bottomLeft,
                            children: <Widget>[
                              Column(
                                children: [
                                  Row(
                                    children: [
                                      Padding(
                                        padding: getPadding(left: 8.0),
                                        child: GestureDetector(
                                          onTap: () async {
                                            Get.back(result: controller.product.value);
                                          },
                                          child: const Icon(
                                            Icons.arrow_back,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(left: 16.0),
                                        child: Text(
                                          'Product Details'.tr,
                                          style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
                                        ),
                                      ),
                                      const Expanded(child: SizedBox()),
                                      IconButton(
                                        icon: const Icon(
                                          Icons.share,
                                          color: Colors.black,
                                        ),
                                        onPressed: () async {
                                          await FlutterShare.share(
                                            title: prefs!.getString('store_name').toString(),
                                            linkUrl: "https://iqmall.net/iqmall/product-details/${controller.product.value!.slug}",
                                            chooserTitle: prefs!.getString('store_name').toString(),
                                          );
                                        },
                                      )
                                    ],
                                  ),
                                  
                                  Expanded(
                                    child: SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                    
                                          GestureDetector(onTap: () {
                                            if (controller.product.value?.more_images?.isNotEmpty ?? false) {
                                              Get.to(() => slider(list: controller.imagesInfo, product: controller.product, index: 0), routeName: '/slider');
                                            }
                                          }, child: Obx(
                                            () {
                                              return SliderImages(
                                                newImages: controller.imagesInfo ?? [],
                                                product: controller.product.value,
                                              );
                                            },
                                          )),
                                          Obx(
                                            () => controller.loading.value
                                                ? Padding(
                                                    padding: getPadding(top: 8.0),
                                                    child: Ui.circularIndicator(color: MainColor),
                                                  )
                                                : ProductInfo(),
                                          ),
                                    
                                          Obx(() => controller.variants.isNotEmpty && !controller.loading.value
                                              ? Variants(
                                                  productVariations: controller.variants,
                                                )
                                              : const SizedBox()),
                                          Obx(
                                            () => controller.loading.value
                                                ? Container()
                                                : controller.product.value?.express_delivery == 1
                                                    ? Padding(
                                                        padding: const EdgeInsets.only(left: 18.0),
                                                        child: Row(
                                                          children: [
                                                            mediaWidget(
                                                              prefs!.getString('express_delivery_img')!,
                                                              AssetPaths.placeholder,
                                                              width: 50,
                                                              height: 50,
                                                              isProduct: false,
                                                              fromKey: "filter",
                                                              fit: BoxFit.cover,
                                                            ),
                                                            Padding(
                                                              padding: const EdgeInsets.only(left: 12.0),
                                                              child: Text('Express Delivery'.tr),
                                                            ),
                                                          ],
                                                        ),
                                                      )
                                                    : Container(),
                                          ),
                                          controller.product.value?.description.toString() == 'null' || controller.product.value?.description.toString() == ''
                                              ? const SizedBox()
                                              : Padding(
                                                  padding: const EdgeInsets.all(8.0),
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: SelectableText(parse(controller.product.value?.description).body!.text),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                          // Padding(
                                          //   padding: const EdgeInsets.only(left: 15.0),
                                          //   child: ReviewsSection(),
                                          // ),
                                          Obx(
                                            () => controller.similaritiesloading.value
                                                ? Container()
                                                : controller.Similarproducts == null || controller.Similarproducts!.isEmpty
                                                    ? const SizedBox()
                                                    : Padding(
                                                        padding: const EdgeInsets.only(top: 8.0),
                                                        child: horizontalHeading(
                                                          'Similar products'.tr,
                                                          callback: () {
                                                            // Ensure product and category_id are not null before using
                                                            // if (controller.product.value?.r_flash_id != null) {
                                                            //   Get.toNamed(AppRoutes.View_All_Products, arguments: {
                                                            //     'title': 'Similar products'.tr,
                                                            //     'id': controller.product..value?.r_flash_id.toString(),
                                                            //     'type': 'category',
                                                            //   });
                                                            // }
                                                          },
                                                        ),
                                                      ),
                                          ),
                                          Obx(() => controller.similaritiesloading.value
                                              ? Container()
                                              : controller.Similarproducts!.isEmpty
                                                  ? Container(
                                                      height: 100,
                                                    )
                                                  : Padding(
                                                      padding: const EdgeInsets.only(bottom: 90.0),
                                                      child: ListView(
                                                        physics: const NeverScrollableScrollPhysics(),
                                                        shrinkWrap: true,
                                                        children: [
                                                          Container(
                                                            height: getVerticalSize(310),
                                                            width: MediaQuery.of(context).size.width,
                                                            margin: const EdgeInsets.only(top: spacing_standard_new),
                                                            child: ListView.builder(
                                                                scrollDirection: Axis.horizontal,
                                                                itemCount: controller.Similarproducts?.length,
                                                                shrinkWrap: true,
                                                                padding: const EdgeInsets.only(right: spacing_standard_new),
                                                                itemBuilder: (context, index) {
                                                                  return Padding(
                                                                    padding: const EdgeInsets.only(right: 8.0, left: 8),
                                                                    child: ProductWidget(
                                                                      product: controller.Similarproducts![index],
                                                                    ),
                                                                  );
                                                                }),
                                                          ),
                                                        ],
                                                      ),
                                                    ))
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Obx(() => controller.product.value != null
                                  ? Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Padding(
                                        padding: getPadding(left: 0.0, right: 0, bottom: 0),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Obx(() => AddToCartButtons(
                                                  product: controller.updatePriceInAddToCart.value ? controller.product.value! : controller.product.value!,
                                                  onTap: () {
                                                    ProductDetails_screenController controller = Get.find();

                                                    if (controller.addingToCard.value) {
                                                      toaster(Get.context!, 'Please wait while processing the request'.tr);
                                                    } else {
                                                      if (controller.loading.value) {
                                                        toaster(Get.context!, 'Please wait to load the quantity'.tr);
                                                      } else {
                                                        controller.addingToCard.value = true;

                                                        controller.AddToCart(controller.product.value, '1').then((value) {
                                                          // controller.product.value?.quantity = (int.parse(controller.product.value!.quantity!) + 1).toString();
                                                          controller.addingToCard.value = false;
                                                        });
                                                      }
                                                    }
                                                  },
                                                )),
                                          ],
                                        ),
                                      ),
                                    )
                                  : const SizedBox()),
                              Obx(() => controller.freez.value
                                  ? Center(
                                      child: Progressor_indecator(),
                                    )
                                  : const SizedBox())
                            ],
                          ),
                        ),
                    ),
          )),
    );
  }
}
