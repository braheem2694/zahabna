import 'dart:convert';
import 'dart:ffi';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:iq_mall/screens/Filter_Products_screen/widgets/CustomBottomSheet.dart';
import 'package:iq_mall/screens/Filter_Products_screen/widgets/Listview.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/utils/ShConstant.dart';
import 'package:iq_mall/widgets/CommonWidget.dart';
import 'package:get/get.dart';
import 'package:progressive_image/progressive_image.dart';

import '../../Product_widget/Product_widget.dart';
import '../../widgets/image_widget.dart';
import '../Home_screen_fragment/controller/Home_screen_fragment_controller.dart';
import '../Home_screen_fragment/widgets/CategoriesWidget.dart';
import 'controller/Filter_Products_controller.dart';
import 'package:iq_mall/utils/ShImages.dart';

class Filter_Productsscreen extends StatelessWidget {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final Filter_ProductsController controller = Get.put(Filter_ProductsController());

  // @override
  // void initState() {
  //   args = Get.arguments;
  //   Get.create<Filter_ProductsController>(() => Filter_ProductsController(), tag: "${args["id"]}:${args["title"]}");
  //   controller = Get.find(tag: "${args["id"]}:${args["title"]}");
  //   controller.onInit();
  //
  //   // TODO: implement initState
  //   super.initState();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        drawer: CustomDrawer(),
        appBar: AppBar(
          elevation: 1,
          backgroundColor: Colors.white,
          title: Obx(() => Text(controller.title.value)),
          leading: GestureDetector(
            onTap: () {
              Get.back();
            },
            child: const Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
          ),
          iconTheme: const IconThemeData(color: sh_textColorPrimary),
          actionsIconTheme: const IconThemeData(color: sh_textColorPrimary),
        ),
        body: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          controller: controller.scrollController,
          shrinkWrap: true,
          children: [
            Obx(() {
              var categories = homeDataList.value.categories!.where((category) => category.parent.toString() == controller.category.value.toString()).toList();
              return Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: SizedBox(
                    height: categories.isEmpty ? 0 : getSize(133),
                    child: ListView.builder(
                      itemCount: homeDataList.value.categories!.where((category) => category.parent.toString() == controller.category.value.toString()).length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, int index) {
                        var unescape = HtmlUnescape();
                        var text = unescape.convert(categories[index].categoryName);
                        return GestureDetector(
                            onTap: () {
                              var f = {
                                "categories": [
                                  categories[index].id.toString(),
                                ],
                              };
                              String jsonString = jsonEncode(f);

                              // Get.delete<Filter_ProductsController>();

                              // Filter_ProductsController _controller = Get.find();
                              // _controller.onInit();
                              Get.to(
                                () => Filter_Productsscreen(),
                                arguments: {
                                  'title': categories[index].categoryName.toString(),
                                  'id': int.parse(categories[index].id.toString()),
                                  'type': jsonString,
                                },
                                preventDuplicates: false,
                              );

                              // Get.toNamed(AppRoutes.Filter_products, arguments: {
                              //   'title': categories[index].categoryName.toString(),
                              //   'id': int.parse(categories[index].id.toString()),
                              //   'type': jsonString,
                              // },preventDuplicates: false);
                              // controller.category.value = categories[index].id.toString();
                              // controller.type = jsonString;
                              // controller.title.value = categories[index].categoryName.toString();
                              // controller.selectedCategoryIds = int.parse(categories[index].id.toString());
                            },
                            child: Padding(
                              padding: getPadding(left: 8.0, right: 8),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  // mediaWidget(
                                  //   convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
                                  //   AssetPaths.placeholder,
                                  //   height: getSize(78),
                                  //   width: getSize(76),
                                  //   isCategory: true,
                                  //   fit: BoxFit.contain,
                                  // ),
                                  ClipRRect(
                                    borderRadius: const BorderRadius.all(Radius.circular(50)),
                                    child: ProgressiveImage(
                                      key: UniqueKey(),

                                      placeholder: const AssetImage(AssetPaths.placeholderCircle),
                                      // size: 1.87KB
                                      thumbnail: CachedNetworkImageProvider(
                                        convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
                                      ),
                                      blur: 0,
                                      // size: 1.29MB
                                      image: CachedNetworkImageProvider(convertToThumbnailUrl(categories[index].main_image ?? "", isBlurred: false) ?? ''),
                                      height: getSize(78),
                                      width: getSize(76),

                                      fit: BoxFit.contain,
                                      fadeDuration: Duration(milliseconds: 200),
                                    ),
                                  ),
                                  // Container(
                                  //   height: getSize(83),
                                  //   width: getSize(80),
                                  //   decoration: BoxDecoration(
                                  //     borderRadius: BorderRadius.circular(5), // Adjust the value as needed
                                  //     image: DecorationImage(
                                  //       image: getAvatarImageProvider(categories[index].main_image, AssetPaths.placeholder),
                                  //     ),
                                  //   ),
                                  // ),
                                  const SizedBox(height: spacing_control),
                                  Container(
                                    alignment: Alignment.center,
                                    width: getSize(80),
                                    child: Text(
                                      text,
                                      maxLines: 2,
                                      softWrap: true,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        overflow: TextOverflow.visible,
                                        color: Colors.black,
                                        fontSize: getFontSize(15),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ));
                      },
                    )
                    // CustomScrollView(
                    //   scrollDirection: Axis.horizontal,
                    //   physics: const ScrollPhysics(),
                    //   shrinkWrap: true,
                    //   slivers: <Widget>[
                    //     SliverPadding(
                    //       padding: const EdgeInsets.only(left: 1.0, right: 1.0),
                    //       sliver: SliverGrid(
                    //         gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    //           mainAxisSpacing: 1,
                    //           childAspectRatio: 1.5,
                    //           crossAxisSpacing: 2.0,
                    //           crossAxisCount: 1,
                    //         ),
                    //         delegate: SliverChildBuilderDelegate(
                    //           (BuildContext context, int index) {
                    //             var categories = homeDataList.value.categories!.where((category) => category.parent == int.parse(controller.category.value)).toList();
                    //             var unescape = HtmlUnescape();
                    //             var text = unescape.convert(categories[index].categoryName);
                    //             print("textsdasdas");
                    //             print(text);
                    //             return GestureDetector(
                    //                 onTap: () {
                    //                   var f = {
                    //                     "categories": [
                    //                       categories[index].id.toString(),
                    //                     ],
                    //                   };
                    //                   String jsonString = jsonEncode(f);
                    //
                    //                   // Get.delete<Filter_ProductsController>();
                    //
                    //                   // Filter_ProductsController _controller = Get.find();
                    //                   // _controller.onInit();
                    //                   Get.to(
                    //                     () => Filter_Productsscreen(),
                    //                     arguments: {
                    //                       'title': categories[index].categoryName.toString(),
                    //                       'id': int.parse(categories[index].id.toString()),
                    //                       'type': jsonString,
                    //                     },
                    //                     preventDuplicates: false,
                    //                   );
                    //
                    //                   // Get.toNamed(AppRoutes.Filter_products, arguments: {
                    //                   //   'title': categories[index].categoryName.toString(),
                    //                   //   'id': int.parse(categories[index].id.toString()),
                    //                   //   'type': jsonString,
                    //                   // },preventDuplicates: false);
                    //                   // controller.category.value = categories[index].id.toString();
                    //                   // controller.type = jsonString;
                    //                   // controller.title.value = categories[index].categoryName.toString();
                    //                   // controller.selectedCategoryIds = int.parse(categories[index].id.toString());
                    //                 },
                    //                 child: Padding(
                    //                   padding: getPadding(left: 8.0, right: 8),
                    //                   child: Column(
                    //                     mainAxisAlignment: MainAxisAlignment.start,
                    //                     children: <Widget>[
                    //                       // mediaWidget(
                    //                       //   convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
                    //                       //   AssetPaths.placeholder,
                    //                       //   height: getSize(78),
                    //                       //   width: getSize(76),
                    //                       //   isCategory: true,
                    //                       //   fit: BoxFit.contain,
                    //                       // ),
                    //                       ClipRRect(
                    //                         borderRadius: const BorderRadius.all(Radius.circular(50)),
                    //                         child: ProgressiveImage(
                    //                           key: UniqueKey(),
                    //
                    //                           placeholder: const AssetImage(AssetPaths.placeholderCircle),
                    //                           // size: 1.87KB
                    //                           thumbnail: CachedNetworkImageProvider(
                    //                             convertToThumbnailUrl(categories[index].main_image ?? '', isBlurred: true),
                    //                           ),
                    //                           blur: 0,
                    //                           // size: 1.29MB
                    //                           image: CachedNetworkImageProvider(convertToThumbnailUrl(categories[index].main_image ?? "", isBlurred: false) ?? ''),
                    //                           height: getSize(78),
                    //                           width: getSize(76),
                    //
                    //                           fit: BoxFit.contain,
                    //                           fadeDuration: Duration(milliseconds: 200),
                    //                         ),
                    //                       ),
                    //                       // Container(
                    //                       //   height: getSize(83),
                    //                       //   width: getSize(80),
                    //                       //   decoration: BoxDecoration(
                    //                       //     borderRadius: BorderRadius.circular(5), // Adjust the value as needed
                    //                       //     image: DecorationImage(
                    //                       //       image: getAvatarImageProvider(categories[index].main_image, AssetPaths.placeholder),
                    //                       //     ),
                    //                       //   ),
                    //                       // ),
                    //                       const SizedBox(height: spacing_control),
                    //                       Flexible(
                    //                         child: Text(
                    //                           text,
                    //                           maxLines: 2,
                    //                           softWrap: true,
                    //                           textAlign: TextAlign.start,
                    //                           style: TextStyle(
                    //                             overflow: TextOverflow.visible,
                    //                             color: Colors.black,
                    //                             fontSize: getFontSize(15),
                    //                           ),
                    //                         ),
                    //                       ),
                    //                     ],
                    //                   ),
                    //                 ));
                    //           },
                    //           childCount: homeDataList.value.categories!.where((category) => category.parent.toString() == controller.category.value.toString()).length,
                    //         ),
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    ),
              );
            }),
            Padding(
              padding: const EdgeInsets.only(left: 25.0, bottom: 10, top: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 3.0),
                    child: Text(
                      'Products'.tr,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Row(
                    children: [
                      Obx(() => Text('${controller.count.value.toString()} results')),
                      Obx(() => Text(
                            "     ${controller.title.value}",
                            style: TextStyle(color: Colors.grey[600]),
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 12.0, right: 25, bottom: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  LayoutBuilder(
                    builder: (BuildContext context, BoxConstraints constraints) {
                      // Define the maximum width.
                      const double maxWidth = 200;

                      // Sample texts to measure. Replace with your actual dropdown items.
                      final List<String> sampleTexts = [
                        'Newest',
                        'Price: Lowest to Highest',
                        'Price: Highest to Lowest',
                      ];

                      double calculateTextWidth(String text) {
                        final textPainter = TextPainter(
                          text: TextSpan(text: text, style: TextStyle(fontSize: getFontSize(13))),
                          maxLines: 1,
                          textDirection: TextDirection.ltr,
                        );
                        textPainter.layout(minWidth: 0, maxWidth: double.infinity);
                        return textPainter.width;
                      }

                      // Calculate the maximum text width.
                      double textWidth = sampleTexts.map(calculateTextWidth).reduce(max);

                      // Add extra padding or other element widths.
                      double totalWidth = textWidth + 20; // Adjust 20 for padding or other elements.

                      // Ensure the total width does not exceed the maximum width.
                      totalWidth = min(totalWidth, maxWidth);

                      return Obx(
                        () => Container(
                          height: getSize(50),
                          width: totalWidth,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25.0),
                            border: Border.all(color: Colors.white.withOpacity(0.5)),
                            color: sh_light_grey, // Use sh_light_grey here
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade300,
                                blurRadius: 1,
                                offset: const Offset(1, 2),
                              ),
                            ],
                          ),
                          padding: getPadding(left: 16),
                          alignment: Alignment.bottomCenter,
                          child: DropdownButtonHideUnderline(
                            child: Theme(
                              data: Theme.of(context).copyWith(
                                canvasColor: sh_light_grey, // Dropdown background color
                                popupMenuTheme: PopupMenuThemeData(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(25),
                                  ),
                                ),
                              ),
                              child: DropdownButton<String>(
                                value: controller.selectedValue?.value,
                                items: [
                                  DropdownMenuItem(
                                    value: 'newest',
                                    child: Text(
                                      'Newest'.tr,
                                      style: TextStyle(color: Colors.black87, fontSize: getFontSize(13)), // Text color
                                    ),
                                  ),
                                  DropdownMenuItem(
                                    value: 'lowestToHighest',
                                    child: Text(
                                      'Price: Lowest to Highest'.tr,
                                      style: TextStyle(color: Colors.black87),
                                    ),
                                  ),
                                  DropdownMenuItem(
                                    value: 'highestToLowest',
                                    child: Text(
                                      'Price: Highest to Lowest'.tr,
                                      style: TextStyle(color: Colors.black87),
                                    ),
                                  ),
                                ],
                                onChanged: (value) {
                                  controller.selectedValue?.value = value!;
                                  controller.page.value = 1;
                                  controller.loading.value = true;
                                  controller.Products?.value.clear();
                                  controller.Products?.clear();
                                  controller.getProducts(controller.page.value);
                                  // ... Your existing onChanged logic ...
                                },
                                hint: const Text(
                                  'Sorting Options',
                                  style: TextStyle(color: Colors.black54), // Hint text style
                                ),
                                icon: const Icon(
                                  Icons.arrow_drop_down_sharp,
                                  color: Colors.black, // Icon color
                                ),
                                style: TextStyle(color: Colors.black),
                                // Selected item style
                                isExpanded: true,
                                dropdownColor: sh_light_grey,
                                elevation: 16,
                                // Shadow elevation
                                borderRadius: BorderRadius.circular(15),
                                // Border radius of dropdown
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), // Inner padding
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 20),
              child: Obx(() => !controller.loader.value
                  ? CustomListView(
                      controller: controller,
                      key: UniqueKey(),
                    )
                  : Progressor_indecator()),
            ),
            Obx(() => !controller.loadmore.value ? Container() : Align(alignment: Alignment.center, child: Progressor_indecator()))
          ],
        ));
  }
}
