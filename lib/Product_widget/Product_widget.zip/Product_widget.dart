import 'dart:math';
import 'dart:typed_data';
import 'package:animated_react_button/animated_react_button.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:file/src/interface/file.dart';
import 'package:html/parser.dart';
import 'package:iq_mall/cores/math_utils.dart';
import 'package:iq_mall/routes/app_routes.dart';
import 'package:iq_mall/widgets/LikeButton.dart';
import 'package:iq_mall/utils/ShImages.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:iq_mall/utils/ShColors.dart';
import 'package:iq_mall/widgets/ShWidget.dart';
import 'package:get/get.dart';
import 'dart:async';
import 'package:iq_mall/main.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:progressive_image/progressive_image.dart';
import '../models/HomeData.dart';
import '../screens/Cart_List_screen/controller/Cart_List_controller.dart';
import '../screens/Filter_Products_screen/controller/Filter_Products_controller.dart';
import '../screens/ProductDetails_screen/ProductDetails_screen.dart';
import '../screens/ProductDetails_screen/controller/ProductDetails_screen_controller.dart';
import '../screens/Wishlist_screen/controller/Wishlist_controller.dart';
import '../widgets/add_to_cart.dart';
import '../widgets/image_new_widget.dart';
import '../widgets/image_widget.dart';
import 'package:iq_mall/models/functions.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:path_provider/path_provider.dart' as path_provider;

RxBool recheck = false.obs;

class ProductWidget extends StatefulWidget {
  static String? tag = '/ShProductDetail';
  final Product product;
  final String? fromKey;

  ProductWidget({required this.product, this.fromKey});

  @override
  ProductWidgetState createState() => ProductWidgetState();
}

class ProductWidgetState extends State<ProductWidget> {
  final random = Random();

  RxBool refreshing = false.obs;
  RxBool isLiked = false.obs;
  RxBool isReallyLiked = false.obs;
  RxInt imageCount = 0.obs;
  int count = 0;

  List<CachedNetworkImageProvider> images = <CachedNetworkImageProvider>[];

  var key = UniqueKey();

  @override
  void initState() {
    // TODO: implement initState
    // if(widget.fromKey=="filter"){
    //   _getBytesFromCachedImage(CachedNetworkImageProvider(widget.product.main_image!));
    //
    // }

    isLiked.value = widget.product.is_liked == 0 ? false : true;
    isReallyLiked.value = widget.product.is_liked == 0 ? false : true;
    super.initState();
  }


  // updateFetchedImages(){
  //   final CountService countService = Get.put(CountService());
  //   int newCount = countService.getCount() + 1;
  //   print("currentCount: ${newCount}");
  //   countService.updateCount(newCount);
  // }

  // Future<Uint8List> _getBytesFromCachedImage(CachedNetworkImageProvider imageProvider) async {
  //   final imageStream = imageProvider.resolve(ImageConfiguration());
  //   final Completer<Uint8List> completer = Completer();
  //   ImageStreamListener? listener;
  //
  //   try {
  //     listener = ImageStreamListener((ImageInfo image, bool synchronousCall) {
  //       if (!completer.isCompleted) {
  //         updateFetchedImages();
  //
  //         image.image.toByteData().then((ByteData? byteData) {
  //           if (byteData != null) {
  //             completer.complete(byteData.buffer.asUint8List());
  //
  //             globalController.updateImageFetchingNumber();
  //           } else {
  //             completer.completeError(Exception("ByteData is null"));
  //           }
  //         });
  //         imageStream.removeListener(listener!); // Remove the listener after completion
  //       }
  //     }, onError: (Object exception, StackTrace? stackTrace) {
  //
  //       completer.completeError(exception, stackTrace);
  //       imageStream.removeListener(listener!);
  //
  //       // Remove the listener in case of an error
  //     });
  //     imageStream.addListener(listener);
  //   } catch (e) {}
  //   return completer.future;
  // }

  void _showBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isDismissible: true,
      enableDrag: true,

      isScrollControlled: true, // Set this to true to make the sheet full-screen.
      builder: (BuildContext context) {

        Get.put(ProductDetails_screenController());
        // Return the screen you want to show as a bottom sheet
        return ProductDetails_screen(
          product: widget.product,
          fromCart: false,
          productSlug: null,
        );
      },
    )?.then((product) {
      refreshing.value = true;

      // Get.delete<ProductDetails_screenController>();

      Future.delayed(const Duration(milliseconds: 350)).then((value) {
        isLiked.value = globalController.isLiked.value;

        refreshing.value = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    imageCount.value =
        (widget.product.more_images?.length ?? 0 + (widget.product.main_image != null ? 1 : 0)) < 4 ? (widget.product.more_images?.length ?? 0 + (widget.product.main_image != null ? 1 : 0)) : 4;
    return InkWell(
      key: ValueKey(widget.product.product_id),
      onTap: () async {
        // Assuming you have a controller named MyController
        if (Get.isRegistered<ProductDetails_screenController>()) {
          await Get.delete<ProductDetails_screenController>();
          print("MyController is initialized");
        }
        // images.clear();
        // images.add(CachedNetworkImageProvider(widget.product.main_image!));
        //
        // for(int i=0; i<widget.product.more_images!.length;i++){
        //
        //   images.add(CachedNetworkImageProvider(widget.product.more_images![i].file_path));
        //
        // }
        globalController.updateProductLike(widget.product.is_liked == 1 ? true : false);


        _showBottomSheet(context);
        // Get.toNamed(
        //   AppRoutes.Productdetails_screen,
        //   preventDuplicates: false,
        //   arguments: {
        //     'product': widget.product, 'from_cart': false, "product_slug": null, "key": key,
        //     // "imageProvider": images,
        //   },
        // )?.then((product) {
        //   refreshing.value = true;
        //
        //   // Get.delete<ProductDetails_screenController>();
        //
        //   Future.delayed(const Duration(milliseconds: 200)).then((value) {
        //     isLiked.value = globalController.isLiked.value;
        //
        //     refreshing.value = false;
        //   });
        // });
      },
      child: Container(
        height: getVerticalSize(310),
        width: getSize(180),
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(8.0),
            topRight: Radius.circular(8.0),
            bottomRight: Radius.circular(8.0),
            bottomLeft: Radius.circular(8.0),
          ),
          border: Border.all(color: Colors.grey[200]!),
          color: Colors.white,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5.0),
                    color: Colors.grey[200],
                  ),
                  alignment: Alignment.topCenter,
                  height: getVerticalSize(220), // set height

                  child: Obx(() =>
                  // imageCount.value == 0
                  //     ?
                      // CustomImageWidget(
                      //         blurImageUrl: convertToThumbnailUrl(widget.product.main_image.toString(), isBlurred: true),
                      //         thumbImageUrl:
                      //             convertToThumbnailUrl(widget.product.main_image.toString(), isBlurred: false),
                      //         height: getVerticalSize(180),
                      //         width: getSize(240),
                      //         cacheThumb: true,
                      //         fit: BoxFit.cover,
                      //       )

                      // ClipRRect(
                      //   borderRadius: const BorderRadius.only(
                      //     topLeft: Radius.circular(8),
                      //     topRight: Radius.circular(8),
                      //   ),
                      //   child: CachedNetworkImage(
                      //     imageUrl: convertToThumbnailUrl(widget.product.main_image ?? "", isBlurred: false) ?? '',
                      //     cacheManager: CustomCacheManager.instance, // Use your custom cache manager here
                      //     placeholder: (context, url) => Image.asset(
                      //       AssetPaths.placeholder, // Placeholder image path
                      //       fit: BoxFit.cover,
                      //     ),
                      //     errorWidget: (context, url, error) => Icon(Icons.error),
                      //     fit: BoxFit.cover,
                      //     // Other CachedNetworkImage properties...
                      //   ),
                      // )

                      ClipRRect(
                          borderRadius: const BorderRadius.only(topLeft: Radius.circular(8), topRight: Radius.circular(8), bottomLeft: Radius.circular(0), bottomRight: Radius.circular(0)),
                          child: ProgressiveImage(
                            placeholder: const AssetImage(AssetPaths.placeholder),
                            // size: 1.87KB
                            thumbnail: CachedNetworkImageProvider(
                              convertToThumbnailUrl(widget.product.main_image ?? '', isBlurred: true),
                              scale: 1,


                              cacheManager: CacheManager(
                                Config(
                                  widget.product.product_id.toString(),
                                  stalePeriod: Duration(seconds: 10), // Adjust based on how long you want items to stay in the cache
                                  maxNrOfCacheObjects: 50,

                                  // Maximum number of images to keep in cache
                                  // You can add other configurations like fileService or repo here
                                ),
                              ),
                            ),
                            blur: 1,
                            // size: 1.29MB
                            image: CachedNetworkImageProvider(
                              convertToThumbnailUrl(widget.product.main_image ?? "", isBlurred: false) ?? '',
                              scale: 1,

                              cacheManager: CacheManager(
                                Config(
                                  widget.product.product_id.toString(),
                                  stalePeriod: Duration(seconds: 10), // Adjust based on how long you want items to stay in the cache
                                  maxNrOfCacheObjects: 50,

                                  // Maximum number of images to keep in cache
                                  // You can add other configurations like fileService or repo here
                                ),
                              ),
                              errorListener: (p0) {},
                              // maxWidth: int.parse(getHorizontalSize(180).round().toString()),
                              // maxHeight: int.parse(getVerticalSize(220).round().toString()),
                            ),
                            height: getVerticalSize(220),
                            width: Get.width,
                            fit: BoxFit.cover,
                            fadeDuration: const Duration(milliseconds: 200),
                            key: Key(widget.product.product_id.toString()),
                          ),
                        )
                      // : SizedBox(
                      //     child: Swiper(
                      //       key: UniqueKey(),
                      //       pagination: imageCount.value > 1
                      //           ? imageCount.value > 4
                      //               ? SwiperPagination(
                      //                   alignment: Alignment.bottomCenter,
                      //                   margin: getMargin(bottom: 3),
                      //                   builder: DotSwiperPaginationBuilder(
                      //                     activeColor: MainColor,
                      //
                      //                     space: 4,
                      //
                      //                     activeSize: getSize(7),
                      //                     size: getSize(7),
                      //                     // Color for the active dot
                      //                     color: Colors.grey, // Color for the inactive dots
                      //                   ),
                      //                 )
                      //               : SwiperPagination(
                      //                   alignment: Alignment.bottomCenter,
                      //                   margin: getMargin(bottom: 3),
                      //                   builder: DotSwiperPaginationBuilder(
                      //                     activeColor: MainColor,
                      //                     space: 4,
                      //
                      //                     activeSize: getSize(7),
                      //                     size: getSize(7),
                      //                     // Color for the active dot
                      //                     color: Colors.grey, // Color for the inactive dots
                      //                   ),
                      //                 )
                      //           : null,
                      //       loop: true,
                      //       itemCount: imageCount.value.abs(),
                      //       itemBuilder: (BuildContext context, int index) {
                      //         String? imageUrl;
                      //         if (index == 0) {
                      //           imageUrl = widget.product.main_image;
                      //         } else {
                      //           imageUrl = widget.product.more_images?[index].file_path;
                      //         }
                      //
                      //         return
                      //             //   CustomImageWidget(
                      //             //   blurImageUrl: convertToThumbnailUrl(imageUrl.toString(), isBlurred: true),
                      //             //   thumbImageUrl: convertToThumbnailUrl(imageUrl.toString(), isBlurred: false),
                      //             //   cacheThumb: true,
                      //             //   height: getVerticalSize(180),
                      //             //   width: getSize(240),
                      //             //   fit: BoxFit.cover,
                      //             // );
                      //
                      //             ClipRRect(
                      //           borderRadius: BorderRadius.only(topLeft: Radius.circular(5), topRight: Radius.circular(5), bottomLeft: Radius.circular(0), bottomRight: Radius.circular(0)),
                      //           child:
                      //
                      //               // CachedNetworkImage(
                      //               //   height: getVerticalSize(180),
                      //               //   width: getSize(240),
                      //               //   fit: BoxFit.cover,
                      //               //   imageUrl: convertToThumbnailUrl(imageUrl ?? '', isBlurred: false),
                      //               //   placeholder: (context, url) {
                      //               //     return CachedNetworkImage(
                      //               //         imageUrl: convertToThumbnailUrl(imageUrl ?? '', isBlurred: true),
                      //               //         placeholderFadeInDuration: const Duration(milliseconds: 100),
                      //               //         placeholder: (context, url) {
                      //               //           return Image.asset(
                      //               //             AssetPaths.placeholder,
                      //               //             width: Get.size.width,
                      //               //             height: Get.size.height,
                      //               //             fit: BoxFit.cover,
                      //               //           );
                      //               //         });
                      //               //   },
                      //               //   errorWidget: (context, s, a) {
                      //               //     return Center(
                      //               //       child: Image.asset(
                      //               //         AssetPaths.placeholder,
                      //               //         width: Get.size.width,
                      //               //         height: Get.size.height,
                      //               //         fit: BoxFit.cover,
                      //               //       ),
                      //               //     );
                      //               //   },
                      //               // )
                      //
                      //               ProgressiveImage(
                      //             key: Key(widget.product.product_id.toString()),
                      //
                      //             placeholder: const AssetImage(AssetPaths.placeholder),
                      //             // size: 1.87KB
                      //             thumbnail: CachedNetworkImageProvider(convertToThumbnailUrl(imageUrl ?? '', isBlurred: true),
                      //                 cacheManager: CacheManager(
                      //                   Config(
                      //                     widget.product.product_id.toString(),
                      //                     stalePeriod: const Duration(days: 5),
                      //                     maxNrOfCacheObjects: 100,
                      //                   ),
                      //                 )),
                      //             blur: 0,
                      //             // size: 1.29MB
                      //             image: CachedNetworkImageProvider(
                      //               convertToThumbnailUrl(imageUrl ?? '', isBlurred: false),
                      //               cacheManager: CacheManager(
                      //                 Config(
                      //                   widget.product.product_id.toString(),
                      //                   stalePeriod: const Duration(days: 5),
                      //                   maxNrOfCacheObjects: 100,
                      //                 ),
                      //               ),
                      //             ),
                      //             height: getVerticalSize(220),
                      //             width: getHorizontalSize(200),
                      //
                      //             fit: BoxFit.cover,
                      //             fadeDuration: Duration(milliseconds: 200),
                      //           ),
                      //         );
                      //         //   mediaWidget(
                      //         //     convertToThumbnailUrl(imageUrl ?? '', isBlurred: false),
                      //         //   AssetPaths.placeholder,
                      //         //   height: getVerticalSize(180),
                      //         //   isProduct: true,
                      //         //   width: getSize(240),
                      //         //   fit: BoxFit.cover,
                      //         // );
                      //
                      //         //   CachedNetworkImage(
                      //         //   height: 160,
                      //         //   width: MediaQuery.of(context).size.width,
                      //         //   fit: BoxFit.cover,
                      //         //   imageUrl: convertToThumbnailUrl(imageUrl, isBlurred: false),
                      //         //   placeholder: (context, url) {
                      //         //     return CachedNetworkImage(
                      //         //       imageUrl: convertToThumbnailUrl(imageUrl, isBlurred: true),
                      //         //       placeholderFadeInDuration: const Duration(milliseconds: 100),
                      //         //     );
                      //         //   },
                      //         //   errorWidget: (context, s, a) {
                      //         //     return CachedNetworkImage(
                      //         //       height: 160,
                      //         //       width: MediaQuery.of(context).size.width,
                      //         //       fit: BoxFit.cover,
                      //         //       imageUrl: imageUrl,
                      //         //       errorWidget: (context, s, a) {
                      //         //         return Center(
                      //         //           child: Image.asset(
                      //         //             AssetPaths.placeholder,
                      //         //             width: Get.size.width,
                      //         //             height: Get.size.height,
                      //         //             fit: BoxFit.cover,
                      //         //           ),
                      //         //         );
                      //         //       },
                      //         //     );
                      //         //   },
                      //         // );
                      //       },
                      //     ),
                      //   )
                  ),
                ),
                Positioned(
                    top: 5, // Adjust the value as needed for spacing from the top
                    right: 5,
                    child: AddToCartButton(product: widget.product)),
              ],
            ),
            Padding(
              padding: getPadding(left: 4.0, right: 8, top: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  widget.product.price_after_discount != null
                      ? Text(
                          sign.toString() + widget.product.price_after_discount.toString(),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: price_color,
                            fontSize: getFontSize(15),
                            decoration: TextDecoration.none,
                          ),
                        )
                      : Container(),
                  Padding(
                    padding: getPadding(left: 4.0),
                    child: Text(
                      sign.toString() + widget.product.product_price.toString(),
                      style: TextStyle(
                        fontWeight: widget.product.price_after_discount == null || widget.product.price_after_discount.toString() == 'null' ? FontWeight.bold : FontWeight.normal,
                        color: widget.product.price_after_discount != null ? discount_price_color : price_color,
                        fontSize: widget.product.price_after_discount != null || widget.product.price_after_discount.toString() == 'null' ? getFontSize(14) : getFontSize(12),
                        decoration: widget.product.price_after_discount != null ? TextDecoration.lineThrough : TextDecoration.none,
                      ),
                    ),
                  ),
                  const Expanded(child: SizedBox()),
                  prefs!.getString("token").toString() == 'null'
                      ? Container()
                      : Padding(
                          padding: getPadding(right: 0),
                          child: Obx(
                            () => refreshing.value
                                ? IconButton(
                                    iconSize: getSize(30),
                                    icon: Obx(() => Icon(
                                          isLiked.value ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                          size: getSize(30),
                                        )),
                                    color: ColorConstant.logoSecondColor,
                                    onPressed: () {
                                      isLiked.value = !isLiked.value;

                                      function.setFavorite(widget.product, false, isLiked.value).then((value) {
                                        widget.product.is_liked = isLiked.value ? 1 : 0;
                                        WishlistController _controller = Get.find();
                                        _controller.GetFavorite();
                                      });
                                    },
                                  )
                                : IconButton(
                                    iconSize: getSize(30),
                                    icon: Obx(() => Icon(
                                          isLiked.value ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                          size: getSize(30),
                                        )),
                                    color: ColorConstant.logoSecondColor,
                                    onPressed: () {
                                      isLiked.value = !isLiked.value;

                                      function.setFavorite(widget.product, false, isLiked.value).then((value) {
                                        widget.product.is_liked = isLiked.value ? 1 : 0;
                                        WishlistController _controller = Get.find();
                                        _controller.GetFavorite().then((value) {
                                          if (!value) {
                                            isLiked.value = !isLiked.value;
                                          }
                                        });
                                      });
                                    },
                                  ),
                          ),
                        )
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0, right: 8, top: 0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    widget.product.product_name,
                    style: TextStyle(color: Colors.black, fontSize: getFontSize(12)),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String? progImages(String? image, fromKey) {
  List<String> newImageList = [];

  String? newImage = "";
  if (fromKey == "blur") {
    newImageList = image!.split("/");
    newImageList.insert(newImageList.length - 1, "blures");
  } else if (fromKey == "thumbnails") {
    newImageList = image!.split("/");
    newImageList.insert(newImageList.length - 1, "thumbnails");
  }

  for (int i = 0; i < newImageList.length; i++) {
    newImage ??= newImageList[i];
    newImage += "/${newImageList[i]}";
  }
  return newImage;
}

String convertToThumbnailUrl(String originalUrl, {bool isBlurred = false}) {
  // Find the last dot to get the file extension
  int lastDot = originalUrl.lastIndexOf('.');

  if (lastDot != -1) {
    // Get the URL without the extension and the extension separately
    String urlWithoutExtension = originalUrl.substring(0, lastDot);
    String extension = originalUrl.substring(lastDot);

    // Choose the appropriate suffix based on whether it's a blurred thumbnail or not
    String suffix = isBlurred ? '_blr' : '_tmb';
    return '${urlWithoutExtension}$suffix$extension';
  } else {
    // Handle URLs without an extension, if needed
    return originalUrl;
  }
}

