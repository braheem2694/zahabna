import 'package:flutter_html/flutter_html.dart';
import 'package:iq_mall/screens/HomeScreenPage/ShHomeScreen.dart';
import 'package:flutter/material.dart';
import 'package:iq_mall/screens/TermsAndConditions_screen/controller/TermsAndConditions_controller.dart';

import 'package:iq_mall/widgets/CommonWidget.dart';
import 'package:get/get.dart';

import '../../cores/math_utils.dart';
import '../../getxController.dart';
import '../../main.dart';

class TermsAndConditionsscreen extends GetView<TermsAndConditionsController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar('Terms and Conditions'.tr),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            "This application serves as an electronic showcase for jewelry stores and does not act as a commercial intermediary or a party to any sales or purchase transactions conducted through it. All interactions between users and stores rely solely on personal trust and the merchant’s reputation in the market. It is the user’s responsibility to verify the quality and authenticity of the products and services before making any transaction. Our company disclaims any responsibility for the authenticity, quality, or compliance of the products and services offered by the stores. Accordingly, we shall not be held liable, under any circumstances, for transactions made through the application or for any disputes arising between users and stores, or between users and any third party, including but not limited to delivery, shipping, or transport companies. Furthermore, we assume no liability for any direct or indirect, material or moral damages resulting from the use of the application or from commercial relationships between the aforementioned parties. By accepting these terms, you acknowledge that you waive any legal action against the application, its owners, or its developers, for any reason whatsoever. You also agree that this application is governed by the laws of the Republic of Lebanon and that any dispute arising from its use shall fall under the exclusive jurisdiction of the Court of First Instance of the South. Our company reserves the right to modify these terms at any time without prior notice. Continued use of the application after any modification shall be deemed as express acceptance of the new terms."
                .tr, // ✅ Translation now updates correctly
            style: TextStyle(fontWeight: FontWeight.normal, fontSize: getFontSize(16)),
          ),
        ),
      ),
    );
  }
}
