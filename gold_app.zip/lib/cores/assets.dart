import 'package:intl/intl.dart';
import 'package:iq_mall/main.dart';

// String? con = "https://cms.lebanonjewelry.net/v1_0_0-";
// String? conVersion = "https://cms.lebanonjewelry.net/";

String? con = "https://cms.zahabna.com/v1_0_0-";
String? conVersion = "https://cms.zahabna.com/";
String? applink = "https://cms.zahabna.com";
var formatter = NumberFormat('#,###,###.##');

final datefromater = new DateFormat('dd-MM-yyyy hh:mm');
