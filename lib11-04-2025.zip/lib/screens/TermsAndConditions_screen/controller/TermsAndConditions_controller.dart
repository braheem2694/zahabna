import 'package:get/get.dart';
class TermsAndConditionsController extends GetxController {

  @override
  void onInit() {
    super.onInit();
  }
}

