// import 'package:get/get.dart';
// import 'package:iq_mall/screens/notifications_screen/controller/notification_controller.dart';
//
// import '../../Cart_List_screen/controller/Cart_List_controller.dart';
// import '../../Home_screen_fragment/controller/Home_screen_fragment_controller.dart';
// import '../../Wishlist_screen/controller/Wishlist_controller.dart';
// import '../../categories_screen/controller/categories_controller.dart';
//
//
// class HomeMainFragment extends Bindings {
//   @override
//   void dependencies() {
//     Get.lazyPut(() => Home_screen_fragmentController());
//     Get.lazyPut(() => WishlistController());
//     Get.lazyPut(() => Cart_ListController());
//     Get.lazyPut(() => CategoriesController());
//   }
//
//
// }
