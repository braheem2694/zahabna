

import 'package:get/get.dart';

import '../controller/tabs_controller.dart';


class TabsBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<TabsController>(
            () => TabsController()
    );

  }
}